import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  AlertTriangle,
  X,
  Bell,
  ShieldAlert,
  GitFork,
  Activity,
  CheckCircle2,
  Info,
  ChevronRight,
  Trash2,
  Sparkles,
} from 'lucide-react';

export type AlertSeverity = 'critical' | 'warning' | 'info';
export type AlertType = 'drift' | 'pipeline_failure' | 'pii_breach' | 'security' | 'system';

export interface AlertItem {
  id: string;
  type: AlertType;
  severity: AlertSeverity;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  source: string;
  actionLabel?: string;
}

interface AlertCenterContextType {
  alerts: AlertItem[];
  addAlert: (alert: Omit<AlertItem, 'id' | 'timestamp' | 'read'>) => void;
  removeAlert: (id: string) => void;
  clearAllAlerts: () => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  unreadCount: number;
  isAlertCenterOpen: boolean;
  setIsAlertCenterOpen: (open: boolean) => void;
  toasts: AlertItem[];
  dismissToast: (id: string) => void;
}

const AlertCenterContext = createContext<AlertCenterContextType | undefined>(undefined);

const INITIAL_DEMO_ALERTS: AlertItem[] = [
  {
    id: 'alert-drift-1',
    type: 'drift',
    severity: 'critical',
    title: 'Critical Covariate Shift Detected',
    message: 'Feature transaction_amount_usd exceeded PSI threshold (0.284 > 0.25). Auto-retrain pipeline flagged.',
    timestamp: new Date(Date.now() - 1000 * 60 * 12).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    read: false,
    source: 'Monitoring Engine (Evidently AI)',
    actionLabel: 'Investigate Drift',
  },
  {
    id: 'alert-pipeline-2',
    type: 'pipeline_failure',
    severity: 'critical',
    title: 'Kubeflow Training DAG Execution Failed',
    message: 'Step 04 (quality_gate) exited with code 1 in run run-9942. CUDA Out of Memory on Node gpu-node-03.',
    timestamp: new Date(Date.now() - 1000 * 60 * 45).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    read: false,
    source: 'LangGraph Orchestrator',
    actionLabel: 'View DAG Logs',
  },
  {
    id: 'alert-pii-3',
    type: 'pii_breach',
    severity: 'critical',
    title: 'PII Data Sanitization Breach Warning',
    message: 'Unencrypted SSN/Tax-ID patterns detected in LLM prompt memory buffer. Sentinel blocked payload dispatch.',
    timestamp: new Date(Date.now() - 1000 * 60 * 90).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    read: true,
    source: 'Security Sentinel Engine',
    actionLabel: 'Inspect Buffer',
  },
];

export const AlertCenterProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [alerts, setAlerts] = useState<AlertItem[]>(INITIAL_DEMO_ALERTS);
  const [toasts, setToasts] = useState<AlertItem[]>([]);
  const [isAlertCenterOpen, setIsAlertCenterOpen] = useState<boolean>(false);

  const addAlert = (newAlertData: Omit<AlertItem, 'id' | 'timestamp' | 'read'>) => {
    const alertId = `alert-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const fullAlert: AlertItem = {
      ...newAlertData,
      id: alertId,
      timestamp: nowStr,
      read: false,
    };

    setAlerts((prev) => [fullAlert, ...prev]);

    // Show floating toast
    setToasts((prev) => [fullAlert, ...prev].slice(0, 5)); // Keep max 5 active toasts

    // Auto dismiss non-critical toasts after 6s
    if (fullAlert.severity !== 'critical') {
      setTimeout(() => {
        dismissToast(alertId);
      }, 6000);
    }
  };

  const removeAlert = (id: string) => {
    setAlerts((prev) => prev.filter((a) => a.id !== id));
    dismissToast(id);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const clearAllAlerts = () => {
    setAlerts([]);
    setToasts([]);
  };

  const markAsRead = (id: string) => {
    setAlerts((prev) => prev.map((a) => (a.id === id ? { ...a, read: true } : a)));
  };

  const markAllAsRead = () => {
    setAlerts((prev) => prev.map((a) => ({ ...a, read: true })));
  };

  const unreadCount = alerts.filter((a) => !a.read).length;

  return (
    <AlertCenterContext.Provider
      value={{
        alerts,
        addAlert,
        removeAlert,
        clearAllAlerts,
        markAsRead,
        markAllAsRead,
        unreadCount,
        isAlertCenterOpen,
        setIsAlertCenterOpen,
        toasts,
        dismissToast,
      }}
    >
      {children}
      <FloatingToastContainer />
      <AlertCenterDrawer />
    </AlertCenterContext.Provider>
  );
};

export const useAlertCenter = () => {
  const context = useContext(AlertCenterContext);
  if (!context) {
    throw new Error('useAlertCenter must be used within an AlertCenterProvider');
  }
  return context;
};

/* Floating Toast Component */
export const FloatingToastContainer: React.FC = () => {
  const { toasts, dismissToast, markAsRead, setIsAlertCenterOpen } = useAlertCenter();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col space-y-3 max-w-sm sm:max-w-md w-full pointer-events-none">
      {toasts.map((toast) => {
        const isCritical = toast.severity === 'critical';
        const isWarning = toast.severity === 'warning';

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto p-4 rounded-2xl border shadow-2xl backdrop-blur-md transition-all transform translate-y-0 animate-in slide-in-from-bottom-5 font-mono text-xs ${
              isCritical
                ? 'bg-rose-950/90 border-rose-500/80 text-rose-100 shadow-rose-900/50'
                : isWarning
                ? 'bg-amber-950/90 border-amber-500/80 text-amber-100 shadow-amber-900/50'
                : 'bg-slate-900/90 border-indigo-500/80 text-indigo-100 shadow-indigo-900/50'
            }`}
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                {toast.type === 'drift' ? (
                  <Activity className="w-5 h-5 text-amber-400 shrink-0 animate-pulse" />
                ) : toast.type === 'pipeline_failure' ? (
                  <GitFork className="w-5 h-5 text-rose-400 shrink-0" />
                ) : toast.type === 'pii_breach' ? (
                  <ShieldAlert className="w-5 h-5 text-red-400 shrink-0 animate-bounce" />
                ) : (
                  <Bell className="w-5 h-5 text-indigo-400 shrink-0" />
                )}

                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold uppercase text-[10px] tracking-wider text-slate-300">
                      [{toast.severity.toUpperCase()}]
                    </span>
                    <span className="text-[10px] text-slate-400">{toast.timestamp}</span>
                  </div>
                  <h4 className="font-bold text-white text-sm mt-0.5">{toast.title}</h4>
                </div>
              </div>

              <button
                onClick={() => dismissToast(toast.id)}
                className="p-1 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="mt-2 text-slate-300 text-[11px] leading-relaxed line-clamp-2">{toast.message}</p>

            <div className="mt-3 pt-2 border-t border-white/10 flex items-center justify-between text-[10px]">
              <span className="text-slate-400 truncate max-w-[180px]">{toast.source}</span>
              <button
                onClick={() => {
                  markAsRead(toast.id);
                  dismissToast(toast.id);
                  setIsAlertCenterOpen(true);
                }}
                className="text-indigo-300 hover:text-white font-bold flex items-center gap-1 uppercase tracking-wider"
              >
                <span>{toast.actionLabel || 'View in Center'}</span>
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
};

/* Alert Center Drawer Modal */
export const AlertCenterDrawer: React.FC = () => {
  const {
    alerts,
    removeAlert,
    clearAllAlerts,
    markAsRead,
    markAllAsRead,
    unreadCount,
    isAlertCenterOpen,
    setIsAlertCenterOpen,
  } = useAlertCenter();

  const [activeFilter, setActiveFilter] = useState<'all' | 'critical' | 'drift' | 'pii' | 'pipeline'>('all');

  if (!isAlertCenterOpen) return null;

  const filteredAlerts = alerts.filter((a) => {
    if (activeFilter === 'critical') return a.severity === 'critical';
    if (activeFilter === 'drift') return a.type === 'drift';
    if (activeFilter === 'pii') return a.type === 'pii_breach';
    if (activeFilter === 'pipeline') return a.type === 'pipeline_failure';
    return true;
  });

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex justify-end">
      <div className="bg-slate-900 border-l border-slate-800 w-full max-w-lg h-full p-6 flex flex-col justify-between shadow-2xl text-slate-100 font-mono animate-in slide-in-from-right-10">
        {/* Header */}
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center">
                <ShieldAlert className="w-5 h-5 text-rose-400" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  System Alert Center
                  {unreadCount > 0 && (
                    <span className="px-2 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-bold">
                      {unreadCount} Unread
                    </span>
                  )}
                </h3>
                <p className="text-[11px] text-slate-400">Real-time MLOps security, drift, and pipeline telemetry</p>
              </div>
            </div>

            <button
              onClick={() => setIsAlertCenterOpen(false)}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1.5 flex-wrap text-[11px]">
            {[
              { id: 'all', label: `All (${alerts.length})` },
              { id: 'critical', label: 'Critical Only' },
              { id: 'drift', label: 'Model Drift' },
              { id: 'pii', label: 'PII Breaches' },
              { id: 'pipeline', label: 'Pipeline Failures' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setActiveFilter(f.id as any)}
                className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                  activeFilter === f.id
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Action Row */}
          <div className="flex items-center justify-between text-[11px] pt-1">
            <button
              onClick={markAllAsRead}
              className="text-indigo-400 hover:text-indigo-300 font-bold flex items-center gap-1"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Mark All as Read</span>
            </button>

            <button
              onClick={clearAllAlerts}
              className="text-rose-400 hover:text-rose-300 font-bold flex items-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear All Alerts</span>
            </button>
          </div>
        </div>

        {/* Alerts List */}
        <div className="flex-1 overflow-y-auto my-4 space-y-3 pr-1">
          {filteredAlerts.length === 0 ? (
            <div className="text-center py-16 text-slate-500 space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
              <p className="font-bold text-slate-300 text-xs">All Systems Nominal</p>
              <p className="text-[11px]">No active alerts found matching current filter.</p>
            </div>
          ) : (
            filteredAlerts.map((alert) => (
              <div
                key={alert.id}
                onClick={() => markAsRead(alert.id)}
                className={`p-4 rounded-xl border transition-all cursor-pointer relative space-y-2 ${
                  !alert.read
                    ? alert.severity === 'critical'
                      ? 'bg-rose-950/40 border-rose-500/60 shadow-md'
                      : 'bg-indigo-950/40 border-indigo-500/60'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                {!alert.read && (
                  <span className="absolute top-3 right-3 w-2 h-2 rounded-full bg-indigo-400 animate-ping" />
                )}

                <div className="flex items-center justify-between text-[10px]">
                  <span
                    className={`font-bold px-2 py-0.5 rounded ${
                      alert.severity === 'critical'
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : 'bg-amber-500/20 text-amber-300'
                    }`}
                  >
                    {alert.severity.toUpperCase()}
                  </span>
                  <span className="text-slate-500">{alert.timestamp}</span>
                </div>

                <h4 className="font-bold text-white text-xs leading-snug">{alert.title}</h4>
                <p className="text-slate-300 text-[11px] leading-relaxed">{alert.message}</p>

                <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-800/80">
                  <span className="truncate">{alert.source}</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      removeAlert(alert.id);
                    }}
                    className="text-slate-500 hover:text-rose-400 font-bold"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer Close */}
        <div className="pt-4 border-t border-slate-800">
          <button
            onClick={() => setIsAlertCenterOpen(false)}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition-colors"
          >
            Close Alert Center
          </button>
        </div>
      </div>
    </div>
  );
};
