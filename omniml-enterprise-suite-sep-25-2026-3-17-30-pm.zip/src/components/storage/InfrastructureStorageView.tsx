import React, { useState } from 'react';
import {
  Database,
  Layers,
  Server,
  HardDrive,
  RefreshCw,
  Search,
  CheckCircle2,
  AlertCircle,
  Zap,
  Terminal,
  Key,
  Trash2,
  Copy,
  Check,
  Download,
  Upload,
  FileCode,
  ShieldCheck,
  Cpu,
  BarChart2,
  Table,
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, BarChart, Bar } from 'recharts';

export const InfrastructureStorageView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'postgres' | 'redis' | 'minio'>('postgres');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // PostgreSQL state
  const [activePoolConnections, setActivePoolConnections] = useState(18);
  const [queryInput, setQueryInput] = useState('SELECT model_name, version, stage, created_at FROM mlflow_registered_models ORDER BY created_at DESC LIMIT 5;');
  const [queryResult, setQueryResult] = useState<any[] | null>([
    { id: 'mdl-9401', model_name: 'Fraud Scoring Model', version: 'v2.1.0', stage: 'Production', created_at: '2026-08-01 14:22:10' },
    { id: 'mdl-9402', model_name: 'Customer Churn Predictor', version: 'v1.4.2', stage: 'Staging', created_at: '2026-07-29 09:15:00' },
    { id: 'mdl-9403', model_name: 'LLM Llama-3-70B Fine-Tuned', version: 'v3.0.0', stage: 'Production', created_at: '2026-07-28 18:40:12' },
  ]);

  // Redis State
  const [redisKeys, setRedisKeys] = useState([
    { key: 'feat:user_10928', ttl: 3540, memoryKb: 1.2, type: 'hash', hits: 1420 },
    { key: 'feat:user_88412', ttl: 3410, memoryKb: 1.4, type: 'hash', hits: 890 },
    { key: 'pred:fraud_session_9401', ttl: 290, memoryKb: 0.8, type: 'string', hits: 54 },
    { key: 'emb:llm_context_cache_99', ttl: 7120, memoryKb: 12.4, type: 'string', hits: 3200 },
  ]);

  // MinIO / S3 State
  const [selectedBucket, setSelectedBucket] = useState('mlops-models-registry');
  const [presignedUrl, setPresignedUrl] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(id);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const handleRunQuery = () => {
    setQueryResult([
      { status: 'EXECUTED_OK', rows_affected: 3, execution_time_ms: 1.84 },
      { id: 'mdl-9401', model_name: 'Fraud Scoring Model', version: 'v2.1.0', stage: 'Production', created_at: '2026-08-01 14:22:10' },
      { id: 'mdl-9402', model_name: 'Customer Churn Predictor', version: 'v1.4.2', stage: 'Staging', created_at: '2026-07-29 09:15:00' },
      { id: 'mdl-9403', model_name: 'LLM Llama-3-70B Fine-Tuned', version: 'v3.0.0', stage: 'Production', created_at: '2026-07-28 18:40:12' },
    ]);
  };

  const handleFlushRedisCache = () => {
    setRedisKeys([]);
    setTimeout(() => {
      setRedisKeys([
        { key: 'feat:user_10928', ttl: 3600, memoryKb: 1.2, type: 'hash', hits: 1 },
        { key: 'pred:fraud_session_9401', ttl: 300, memoryKb: 0.8, type: 'string', hits: 1 },
      ]);
    }, 1000);
  };

  const generatePresignedUrl = (filename: string) => {
    const url = `https://s3.us-east-1.amazonaws.com/mlops-models-registry/${filename}?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIA...&X-Amz-Signature=8f9a2b&X-Amz-Expires=3600`;
    setPresignedUrl(url);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 p-5 rounded-2xl border border-slate-800">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center gap-2">
            <Database className="w-5 h-5 text-indigo-400" />
            Infrastructure & Core Data Storage Hub (PostgreSQL, Redis, MinIO/S3)
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Relational PostgreSQL metadata database, low-latency Redis feature/prediction cache, and MinIO / AWS S3 object storage.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center space-x-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveTab('postgres')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'postgres'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>PostgreSQL Metadata</span>
          </button>

          <button
            onClick={() => setActiveTab('redis')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'redis'
                ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Redis Feature Cache</span>
          </button>

          <button
            onClick={() => setActiveTab('minio')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'minio'
                ? 'bg-teal-600 text-white shadow-md shadow-teal-600/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <HardDrive className="w-3.5 h-3.5" />
            <span>MinIO / S3 Storage</span>
          </button>
        </div>
      </div>

      {/* TAB 1: POSTGRESQL METADATA */}
      {activeTab === 'postgres' && (
        <div className="space-y-6">
          {/* Status Metrics Bar */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-1">
              <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">Database Server</span>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-white font-mono">PostgreSQL v16.3</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  HEALTHY
                </span>
              </div>
            </div>

            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-1">
              <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">Connection Pool</span>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-white font-mono">{activePoolConnections} / 50 Active</span>
                <span className="text-xs text-indigo-400 font-mono font-bold">Drizzle ORM</span>
              </div>
            </div>

            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-1">
              <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">Avg Query Latency</span>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-emerald-400 font-mono">1.4 ms</span>
                <span className="text-xs text-slate-400">p99: 4.2ms</span>
              </div>
            </div>

            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-1">
              <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">Db Size</span>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-white font-mono">14.2 GB</span>
                <span className="text-xs text-slate-400">Disk: 250 GB</span>
              </div>
            </div>
          </div>

          {/* Drizzle ORM Schema & Interactive Query Console */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Drizzle ORM Tables Schema List */}
            <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-white uppercase font-mono flex items-center gap-2">
                  <Table className="w-4 h-4 text-indigo-400" />
                  Drizzle ORM Schema Tables
                </h3>
                <span className="text-[10px] font-mono text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                  drizzle.config.ts
                </span>
              </div>

              <div className="space-y-2 font-mono text-xs">
                {[
                  { name: 'mlflow_registered_models', rows: '1,420 rows', pk: 'id (uuid)' },
                  { name: 'ml_pipeline_runs', rows: '8,920 rows', pk: 'run_id (uuid)' },
                  { name: 'dvc_datasets_catalog', rows: '340 rows', pk: 'id (varchar)' },
                  { name: 'feast_feature_views', rows: '88 rows', pk: 'view_id (varchar)' },
                  { name: 'audit_security_logs', rows: '142,800 rows', pk: 'log_id (uuid)' },
                  { name: 'k8s_deployments_state', rows: '14 rows', pk: 'deployment_id (varchar)' },
                ].map((t) => (
                  <div key={t.name} className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 hover:border-slate-700 transition-all flex items-center justify-between">
                    <div>
                      <span className="text-slate-200 font-bold block">{t.name}</span>
                      <span className="text-[10px] text-slate-500">Primary Key: {t.pk}</span>
                    </div>
                    <span className="text-[10px] text-indigo-400 font-semibold">{t.rows}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* SQL Query Console */}
            <div className="lg:col-span-2 bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-white uppercase font-mono flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-emerald-400" />
                  PostgreSQL Interactive SQL Console & Runner
                </h3>

                <button
                  onClick={handleRunQuery}
                  className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center space-x-1.5 transition-all shadow"
                >
                  <Terminal className="w-3.5 h-3.5" />
                  <span>Execute SQL Query</span>
                </button>
              </div>

              <div className="bg-slate-950 rounded-xl p-3 border border-slate-800 font-mono text-xs">
                <textarea
                  value={queryInput}
                  onChange={(e) => setQueryInput(e.target.value)}
                  rows={3}
                  className="w-full bg-transparent text-slate-200 focus:outline-none resize-none font-mono"
                />
              </div>

              {queryResult && (
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 overflow-x-auto space-y-2 font-mono text-xs">
                  <div className="flex justify-between items-center text-emerald-400 text-[11px] font-bold pb-2 border-b border-slate-900">
                    <span>Query Output (JSON / Table Representation)</span>
                    <span>3 Records Returned in 1.84ms</span>
                  </div>
                  <pre className="text-slate-300 text-[11px] pt-1 max-h-48 overflow-y-auto">
                    {JSON.stringify(queryResult, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: REDIS FEATURE CACHE */}
      {activeTab === 'redis' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-1">
              <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">Redis Cluster Engine</span>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-white font-mono">Redis v7.2 (Standalone)</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  ACTIVE
                </span>
              </div>
            </div>

            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-1">
              <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">Cache Hit Ratio</span>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-rose-400 font-mono">98.42%</span>
                <span className="text-xs text-slate-400">Hits: 1.4M / sec</span>
              </div>
            </div>

            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-1">
              <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">Memory Usage</span>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-white font-mono">4.2 GB / 16 GB</span>
                <span className="text-xs text-cyan-400">volatile-lru</span>
              </div>
            </div>

            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-1">
              <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">Cache Evictions</span>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-emerald-400 font-mono">0 Evictions</span>
                <button
                  onClick={handleFlushRedisCache}
                  className="text-[10px] text-rose-400 hover:text-rose-300 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20 font-mono font-bold"
                >
                  Flush Cache
                </button>
              </div>
            </div>
          </div>

          {/* Key Inspector Table */}
          <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono text-rose-400 uppercase font-bold">Low-Latency Online Store</span>
                <h3 className="text-sm font-bold text-white font-mono">Active Redis Feature & Prediction Keys</h3>
              </div>

              <div className="flex items-center space-x-2 text-xs font-mono">
                <span className="text-slate-400">Total Keys Cached: <strong className="text-white">{redisKeys.length}</strong></span>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="p-3">Redis Key</th>
                    <th className="p-3">Data Type</th>
                    <th className="p-3">TTL (Seconds)</th>
                    <th className="p-3">Memory Size</th>
                    <th className="p-3">Total Cache Hits</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {redisKeys.map((rk) => (
                    <tr key={rk.key} className="hover:bg-slate-800/40 transition-colors">
                      <td className="p-3 text-rose-300 font-bold">{rk.key}</td>
                      <td className="p-3 text-slate-400 uppercase">{rk.type}</td>
                      <td className="p-3 text-amber-400">{rk.ttl}s</td>
                      <td className="p-3 text-cyan-300">{rk.memoryKb} KB</td>
                      <td className="p-3 text-emerald-400">{rk.hits.toLocaleString()} hits</td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => setRedisKeys((prev) => prev.filter((k) => k.key !== rk.key))}
                          className="p-1 rounded hover:bg-slate-800 text-slate-500 hover:text-rose-400 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: MINIO / S3 ARTIFACT STORAGE */}
      {activeTab === 'minio' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-1">
              <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">MinIO S3 Endpoint</span>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-white font-mono">s3.us-east-1.amazonaws.com</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-teal-500/20 text-teal-300 border border-teal-500/30">
                  ONLINE
                </span>
              </div>
            </div>

            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-1">
              <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">Total Storage Used</span>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-teal-400 font-mono">482.4 GB</span>
                <span className="text-xs text-slate-400">3 Buckets</span>
              </div>
            </div>

            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-1">
              <span className="text-[10px] font-mono text-slate-500 uppercase font-bold">MLflow Artifact Sync</span>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-emerald-400 font-mono">Auto-Synced</span>
                <span className="text-xs text-slate-400">TLS 1.3 Encryption</span>
              </div>
            </div>
          </div>

          {/* Buckets & Objects Explorer */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Buckets List */}
            <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
              <h3 className="text-xs font-bold text-white uppercase font-mono flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-teal-400" />
                Active S3 / MinIO Buckets
              </h3>

              <div className="space-y-2 font-mono text-xs">
                {[
                  { id: 'mlops-models-registry', name: 'mlops-models-registry', count: '142 model weights', size: '280 GB' },
                  { id: 'mlops-datasets-dvc', name: 'mlops-datasets-dvc', count: '89 DVC tarballs', size: '140 GB' },
                  { id: 'mlflow-artifacts-store', name: 'mlflow-artifacts-store', count: '1,200 run logs', size: '62.4 GB' },
                ].map((b) => (
                  <div
                    key={b.id}
                    onClick={() => setSelectedBucket(b.id)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer ${
                      selectedBucket === b.id
                        ? 'bg-slate-800 border-teal-500 ring-1 ring-teal-500/40'
                        : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-slate-200 font-bold">{b.name}</span>
                      <span className="text-[10px] text-teal-400">{b.size}</span>
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-1">{b.count}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Objects in Selected Bucket */}
            <div className="lg:col-span-2 bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <span className="text-[10px] font-mono text-teal-400 uppercase font-bold">Bucket Contents</span>
                  <h3 className="text-sm font-bold text-white font-mono">s3://{selectedBucket}/</h3>
                </div>

                <button
                  onClick={() => generatePresignedUrl('fraud_xgboost_champion_v2.1.0.onnx')}
                  className="px-3.5 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center space-x-1.5 transition-all shadow"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Generate Presigned Download URL</span>
                </button>
              </div>

              {presignedUrl && (
                <div className="bg-slate-950 p-3 rounded-xl border border-teal-500/40 text-xs font-mono space-y-1">
                  <div className="flex justify-between items-center text-teal-300 font-bold">
                    <span>Presigned Temporary Access URL (Expires in 1 Hour):</span>
                    <button
                      onClick={() => handleCopy(presignedUrl, 'url')}
                      className="text-[10px] text-slate-400 hover:text-white flex items-center gap-1"
                    >
                      {copiedText === 'url' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>Copy</span>
                    </button>
                  </div>
                  <div className="text-slate-400 truncate text-[10px]">{presignedUrl}</div>
                </div>
              )}

              {/* Files Table */}
              <div className="space-y-2 font-mono text-xs">
                {[
                  { filename: 'fraud_xgboost_champion_v2.1.0.onnx', size: '14.2 MB', modified: '2026-08-01 14:22', hash: 'e3b0c44298fc1c149afbf4c8996fb924' },
                  { filename: 'llama3_70b_quantized_q4_k_m.gguf', size: '38.4 GB', modified: '2026-07-28 18:40', hash: '7c9e66797375f964082264858b2986f3' },
                  { filename: 'customer_churn_lightgbm_v1.4.2.pt', size: '28.1 MB', modified: '2026-07-29 09:15', hash: '4f82087e50085a676451680a65e77e23' },
                  { filename: 'dvc_dataset_credit_card_2026_q2.tar.gz', size: '142.8 MB', modified: '2026-07-20 11:10', hash: 'd41d8cd98f00b204e9800998ecf8427e' },
                ].map((f) => (
                  <div key={f.filename} className="p-3 bg-slate-950 rounded-xl border border-slate-800 hover:border-slate-700 transition-all flex items-center justify-between">
                    <div>
                      <span className="text-slate-200 font-bold block">{f.filename}</span>
                      <span className="text-[10px] text-slate-500">MD5: {f.hash}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-teal-400 font-bold block">{f.size}</span>
                      <span className="text-[10px] text-slate-500">{f.modified}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
