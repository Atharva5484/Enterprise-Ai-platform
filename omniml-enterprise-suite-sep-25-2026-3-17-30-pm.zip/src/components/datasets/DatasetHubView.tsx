import React, { useState } from 'react';
import {
  FolderGit2,
  Upload,
  Database,
  Sliders,
  Sparkles,
  GitBranch,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Play,
  FileSpreadsheet,
  Cloud,
  FileText,
  RefreshCw,
  Plus,
  ArrowRight,
  BarChart2,
  Table,
  Check,
  Layers,
  ChevronRight,
  XCircle,
  Code,
} from 'lucide-react';
import {
  DatasetItem,
  DatasetVersion,
  PreprocessingConfig,
  FeatureEnginePipeline,
  UserRole,
} from '../../types/mlops';
import { FeaturePipelineBuilder } from './FeaturePipelineBuilder';

interface DatasetHubViewProps {
  datasets: DatasetItem[];
  featurePipelines: FeatureEnginePipeline[];
  onAddDataset: (dataset: DatasetItem) => void;
  onUpdateDataset: (updated: DatasetItem) => void;
  onUpdatePipeline: (updated: FeatureEnginePipeline) => void;
  onExecutePipeline: (pipelineId: string) => void;
  onOpenCopilotWithContext: (prompt: string) => void;
  userRole: UserRole;
}

export const DatasetHubView: React.FC<DatasetHubViewProps> = ({
  datasets,
  featurePipelines,
  onAddDataset,
  onUpdateDataset,
  onUpdatePipeline,
  onExecutePipeline,
  onOpenCopilotWithContext,
  userRole,
}) => {
  const isViewer = userRole === 'Viewer';
  const [activeSubTab, setActiveSubTab] = useState<'catalog' | 'upload' | 'versioning' | 'profiling' | 'feature_builder'>('catalog');
  const [selectedDatasetId, setSelectedDatasetId] = useState<string>(datasets[0]?.id || '');
  const [aiAnalysisMarkdown, setAiAnalysisMarkdown] = useState<string | null>(null);
  const [isProfilingWithAI, setIsProfilingWithAI] = useState(false);

  // Upload Form State
  const [uploadName, setUploadName] = useState('');
  const [uploadFormat, setUploadFormat] = useState<'CSV' | 'JSON' | 'Parquet' | 'S3 Connection'>('CSV');
  const [s3Bucket, setS3Bucket] = useState('');
  const [s3Region, setS3Region] = useState('us-east-1');
  const [s3Uri, setS3Uri] = useState('');
  const [isUploading, setIsUploading] = useState(false);

  // Preprocessing State
  const [preprocessConfig, setPreprocessConfig] = useState<PreprocessingConfig>({
    imputationStrategy: 'Median',
    scalingMethod: 'StandardScaler',
    encodingMethod: 'OneHotEncoder',
    removeOutliers: true,
    iqrMultiplier: 1.5,
  });
  const [isPreprocessing, setIsPreprocessing] = useState(false);
  const [preprocessDone, setPreprocessDone] = useState(false);

  const activeDataset = datasets.find((d) => d.id === selectedDatasetId) || datasets[0];
  const activePipeline = featurePipelines[0];

  const handleCreateDatasetUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (isViewer) return;
    setIsUploading(true);

    setTimeout(() => {
      const newDataset: DatasetItem = {
        id: `ds-${Date.now()}`,
        name: uploadName || (uploadFormat === 'S3 Connection' ? 's3_ingested_warehouse_data' : 'uploaded_dataset_v1'),
        description: uploadFormat === 'S3 Connection' ? `Ingested from AWS S3 ${s3Uri}` : 'Uploaded local data asset.',
        format: uploadFormat,
        sizeMb: Number((Math.random() * 200 + 20).toFixed(1)),
        rowCount: Math.floor(Math.random() * 500000) + 50000,
        columnCount: 14,
        source: uploadFormat === 'S3 Connection' ? s3Uri : `local_uploads/${uploadName || 'data.csv'}`,
        dvcHash: Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
        gitTag: 'v1.0.0-ingested',
        createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
        updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
        owner: 'Platform Team',
        s3Config: uploadFormat === 'S3 Connection' ? { bucket: s3Bucket, region: s3Region, accessKeyId: 'AKIA...SECRET', uri: s3Uri } : undefined,
        versions: [
          {
            versionTag: 'v1.0.0-ingested',
            dvcHash: Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
            gitCommitHash: Math.random().toString(36).substring(2, 10),
            createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
            createdBy: 'Platform User',
            rowCount: 250000,
            sizeMb: 120,
            commitMessage: 'Initial DVC tracked ingest release',
            isLatest: true,
          },
        ],
        profile: {
          totalRows: 250000,
          totalColumns: 14,
          memorySizeMb: 120,
          missingCellsPercent: 1.2,
          duplicateRows: 12,
          columns: [
            { columnName: 'id', dataType: 'STRING', nullCount: 0, nullPercentage: 0, distinctCount: 250000, sampleValues: ['ID-1', 'ID-2'] },
            { columnName: 'feature_val', dataType: 'FLOAT', nullCount: 300, nullPercentage: 0.12, distinctCount: 89000, min: 0.1, max: 8900.0, mean: 142.5, sampleValues: [12.4, 99.1] },
          ],
          qualityGates: [
            { ruleName: 'completeness_primary_key', description: 'Primary Key must have zero missing values.', severity: 'ERROR', status: 'PASSED', metric: 'null_ratio', value: '0.0%' },
          ],
          recommendedActions: ['Apply Median Imputation on feature_val', 'Standardize numeric features using StandardScaler'],
        },
        previewData: [
          { id: 'ID-1', feature_val: 12.4, category: 'A', status: 'ACTIVE' },
          { id: 'ID-2', feature_val: 99.1, category: 'B', status: 'ACTIVE' },
        ],
      };

      onAddDataset(newDataset);
      setSelectedDatasetId(newDataset.id);
      setIsUploading(false);
      setActiveSubTab('catalog');
    }, 1000);
  };

  const handleRunAiProfile = async () => {
    if (!activeDataset) return;
    try {
      setIsProfilingWithAI(true);
      const res = await fetch('/api/datasets/ai-profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          datasetName: activeDataset.name,
          columnMetrics: activeDataset.profile.columns,
          sampleData: activeDataset.previewData,
        }),
      });

      const data = await res.json();
      if (data.analysisMarkdown) {
        setAiAnalysisMarkdown(data.analysisMarkdown);
      }
    } catch (err) {
      console.error('AI Profiling failed:', err);
    } finally {
      setIsProfilingWithAI(false);
    }
  };

  const handleRunPreprocessing = () => {
    if (!activeDataset) return;
    setIsPreprocessing(true);

    setTimeout(() => {
      setIsPreprocessing(false);
      setPreprocessDone(true);

      const updatedProfile = {
        ...activeDataset.profile,
        missingCellsPercent: 0.0,
        duplicateRows: 0,
        recommendedActions: ['Dataset fully preprocessed and standardized.'],
      };

      const newVersion: DatasetVersion = {
        versionTag: `v${activeDataset.versions.length + 1}.0.0-preprocessed`,
        dvcHash: Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
        gitCommitHash: Math.random().toString(36).substring(2, 10),
        createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
        createdBy: 'Preprocessing Engine',
        rowCount: activeDataset.rowCount,
        sizeMb: activeDataset.sizeMb * 0.95,
        commitMessage: `Applied ${preprocessConfig.imputationStrategy} Imputation & ${preprocessConfig.scalingMethod} scaling`,
        isLatest: true,
      };

      const updatedDataset: DatasetItem = {
        ...activeDataset,
        profile: updatedProfile,
        gitTag: newVersion.versionTag,
        dvcHash: newVersion.dvcHash,
        versions: [newVersion, ...activeDataset.versions.map((v) => ({ ...v, isLatest: false }))],
      };

      onUpdateDataset(updatedDataset);
    }, 1200);
  };

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-6 text-slate-100">
      {/* Viewer Warning Banner if Role is Viewer */}
      {isViewer && (
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3 text-amber-300 text-xs flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              <strong>Read-Only Access Mode (Viewer Role):</strong> Uploading datasets, committing DVC versions, and executing feature engineering pipelines require Data Scientist or Admin permissions.
            </span>
          </div>
        </div>
      )}

      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-teal-500/20 text-teal-300 border border-teal-500/30 uppercase">
              DVC & Git Tracked
            </span>
            <span className="text-xs text-slate-400">| Data Ingestion & Quality Hub</span>
          </div>
          <h1 className="text-xl font-extrabold text-white tracking-tight flex items-center gap-2 mt-1">
            <FolderGit2 className="w-6 h-6 text-teal-400" />
            Dataset Catalog, DVC Versioning & Feature Engineering
          </h1>
        </div>

        {/* SubTab Navigation */}
        <div className="flex items-center bg-slate-900 p-1 rounded-xl border border-slate-800 space-x-1">
          <button
            onClick={() => setActiveSubTab('catalog')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeSubTab === 'catalog'
                ? 'bg-teal-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Dataset Catalog ({datasets.length})
          </button>
          <button
            onClick={() => setActiveSubTab('upload')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeSubTab === 'upload'
                ? 'bg-teal-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Ingest & AWS S3
          </button>
          <button
            onClick={() => setActiveSubTab('profiling')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeSubTab === 'profiling'
                ? 'bg-teal-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Profiling & Preprocessing
          </button>
          <button
            onClick={() => setActiveSubTab('versioning')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeSubTab === 'versioning'
                ? 'bg-teal-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            DVC & Git Lineage
          </button>
          <button
            onClick={() => setActiveSubTab('feature_builder')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeSubTab === 'feature_builder'
                ? 'bg-teal-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Feature Pipeline Builder
          </button>
        </div>
      </div>

      {/* SubTab: Dataset Catalog */}
      {activeSubTab === 'catalog' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {datasets.map((ds) => {
              const isSelected = ds.id === selectedDatasetId;
              return (
                <div
                  key={ds.id}
                  onClick={() => setSelectedDatasetId(ds.id)}
                  className={`p-5 rounded-2xl border transition-all cursor-pointer space-y-3 ${
                    isSelected
                      ? 'bg-slate-900 border-teal-500 ring-1 ring-teal-500/50 shadow-xl'
                      : 'bg-slate-900/60 border-slate-800 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                      {ds.format}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">DVC: {ds.dvcHash.substring(0, 8)}...</span>
                  </div>

                  <div>
                    <h3 className="font-bold text-white text-sm truncate">{ds.name}</h3>
                    <p className="text-xs text-slate-400 line-clamp-2 mt-1">{ds.description}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] font-mono bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    <div>
                      <span className="text-slate-500 block text-[9px]">ROW COUNT</span>
                      <span className="text-slate-200 font-bold">{ds.rowCount.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[9px]">SIZE</span>
                      <span className="text-teal-300 font-bold">{ds.sizeMb} MB</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                    <span>Tag: <strong className="text-emerald-400 font-mono">{ds.gitTag}</strong></span>
                    <span>{ds.versions.length} DVC Releases</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Active Dataset Inspection Detail */}
          {activeDataset && (
            <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div>
                  <div className="flex items-center space-x-2">
                    <h2 className="text-lg font-bold text-white">{activeDataset.name}</h2>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      {activeDataset.gitTag}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 font-mono mt-0.5">{activeDataset.source}</p>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setActiveSubTab('profiling')}
                    className="px-3.5 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-semibold text-xs flex items-center space-x-1.5 shadow transition-all"
                  >
                    <BarChart2 className="w-3.5 h-3.5" />
                    <span>View Quality Profiling</span>
                  </button>
                  <button
                    onClick={() => setActiveSubTab('feature_builder')}
                    className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center space-x-1.5 border border-slate-700 transition-all"
                  >
                    <Sliders className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Build Feature Pipeline</span>
                  </button>
                </div>
              </div>

              {/* Data Preview Table */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                  Sample Ingest Data Rows (Head 5)
                </span>
                <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950">
                  <table className="w-full text-left text-xs text-slate-300">
                    <thead className="bg-slate-900 text-[10px] font-mono text-slate-400 uppercase border-b border-slate-800">
                      <tr>
                        {Object.keys(activeDataset.previewData[0] || {}).map((col) => (
                          <th key={col} className="p-3">
                            {col}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 font-mono">
                      {activeDataset.previewData.map((row, idx) => (
                        <tr key={idx} className="hover:bg-slate-900/40">
                          {Object.values(row).map((val: any, vIdx) => (
                            <td key={vIdx} className="p-3">
                              {typeof val === 'number' ? val.toLocaleString() : String(val)}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SubTab: Ingest & AWS S3 Connector */}
      {activeSubTab === 'upload' && (
        <div className="max-w-3xl mx-auto bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-6">
          <div className="border-b border-slate-800 pb-4">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Upload className="w-5 h-5 text-teal-400" />
              Ingest Dataset Asset or Connect AWS S3 Bucket
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Supports local file drop (CSV, Excel, JSON, Parquet) and enterprise AWS S3 object store connections.
            </p>
          </div>

          <form onSubmit={handleCreateDatasetUpload} className="space-y-4">
            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1">Dataset Asset Name</label>
              <input
                type="text"
                placeholder="e.g. quarterly_customer_retention_2026"
                value={uploadName}
                onChange={(e) => setUploadName(e.target.value)}
                className="w-full bg-slate-950 px-3.5 py-2.5 rounded-xl border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-teal-500"
                required
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1 font-mono">Source Format & Storage Type</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(['CSV', 'JSON', 'Parquet', 'S3 Connection'] as const).map((fmt) => (
                  <button
                    key={fmt}
                    type="button"
                    onClick={() => setUploadFormat(fmt)}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all flex items-center justify-center space-x-1.5 ${
                      uploadFormat === fmt
                        ? 'bg-teal-600/20 text-teal-300 border-teal-500'
                        : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    {fmt === 'S3 Connection' ? <Cloud className="w-3.5 h-3.5 text-cyan-400" /> : <FileText className="w-3.5 h-3.5" />}
                    <span>{fmt}</span>
                  </button>
                ))}
              </div>
            </div>

            {uploadFormat === 'S3 Connection' ? (
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <span className="text-xs font-bold text-teal-300 flex items-center gap-1.5">
                  <Cloud className="w-4 h-4 text-cyan-400" /> AWS S3 Storage Connector Config
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">S3 Bucket Name</label>
                    <input
                      type="text"
                      placeholder="nexusml-warehouse-us-east"
                      value={s3Bucket}
                      onChange={(e) => setS3Bucket(e.target.value)}
                      className="w-full bg-slate-900 px-3 py-2 rounded-lg border border-slate-800 text-xs text-slate-200 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">AWS Region</label>
                    <input
                      type="text"
                      placeholder="us-east-1"
                      value={s3Region}
                      onChange={(e) => setS3Region(e.target.value)}
                      className="w-full bg-slate-900 px-3 py-2 rounded-lg border border-slate-800 text-xs text-slate-200 focus:outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 block mb-1">S3 Object URI</label>
                  <input
                    type="text"
                    placeholder="s3://nexusml-warehouse-us-east/data/fraud_v2.parquet"
                    value={s3Uri}
                    onChange={(e) => setS3Uri(e.target.value)}
                    className="w-full bg-slate-900 px-3 py-2 rounded-lg border border-slate-800 text-xs font-mono text-cyan-300 focus:outline-none"
                  />
                </div>
              </div>
            ) : (
              <div className="border-2 border-dashed border-slate-800 bg-slate-950/60 p-8 rounded-2xl text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-slate-800 flex items-center justify-center mx-auto text-teal-400">
                  <FileSpreadsheet className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-200">Drag and drop dataset file here</p>
                  <p className="text-[11px] text-slate-400">Supports .csv, .xlsx, .json, .parquet up to 5GB</p>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={isUploading || isViewer}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold text-xs shadow-lg transition-all disabled:opacity-50"
            >
              {isUploading ? 'Registering & Initializing DVC Tracked Hash...' : 'Register Dataset & Commit to DVC'}
            </button>
          </form>
        </div>
      )}

      {/* SubTab: Profiling, Quality Gates & Preprocessing */}
      {activeSubTab === 'profiling' && activeDataset && (
        <div className="space-y-6">
          {/* Top Control Header */}
          <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <span className="text-[10px] font-mono text-teal-400 uppercase font-bold">Data Profiling & Quality Engine</span>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <BarChart2 className="w-4 h-4 text-teal-400" />
                {activeDataset.name} (Quality Score: 98.2%)
              </h2>
            </div>

            <button
              onClick={handleRunAiProfile}
              disabled={isProfilingWithAI}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-bold text-xs flex items-center space-x-2 shadow transition-all disabled:opacity-50"
            >
              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
              <span>{isProfilingWithAI ? 'Gemini AI Analyzing Schema...' : 'Run Gemini AI Quality Audit'}</span>
            </button>
          </div>

          {/* Gemini AI Markdown Analysis Output */}
          {aiAnalysisMarkdown && (
            <div className="bg-slate-900 p-5 rounded-2xl border border-indigo-500/40 space-y-2">
              <span className="text-xs font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-yellow-300" />
                Gemini Automated Data Cleanliness & Feature Recommendations
              </span>
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-300 font-sans leading-relaxed whitespace-pre-wrap">
                {aiAnalysisMarkdown}
              </div>
            </div>
          )}

          {/* Profile Metrics Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
              <span className="text-[10px] text-slate-500 uppercase block font-mono">Total Rows</span>
              <span className="text-lg font-bold text-white font-mono">{activeDataset.profile.totalRows.toLocaleString()}</span>
            </div>
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
              <span className="text-[10px] text-slate-500 uppercase block font-mono">Missing Cells Ratio</span>
              <span className="text-lg font-bold text-amber-400 font-mono">{activeDataset.profile.missingCellsPercent}%</span>
            </div>
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
              <span className="text-[10px] text-slate-500 uppercase block font-mono">Duplicates</span>
              <span className="text-lg font-bold text-emerald-400 font-mono">{activeDataset.profile.duplicateRows}</span>
            </div>
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
              <span className="text-[10px] text-slate-500 uppercase block font-mono">DVC Commit Tag</span>
              <span className="text-lg font-bold text-teal-300 font-mono">{activeDataset.gitTag}</span>
            </div>
          </div>

          {/* Automated Preprocessing Engine Controls */}
          <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-4">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Sliders className="w-4 h-4 text-teal-400" />
              Automated Data Preprocessing Engine
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Null Imputation Strategy</label>
                <select
                  value={preprocessConfig.imputationStrategy}
                  onChange={(e) => setPreprocessConfig({ ...preprocessConfig, imputationStrategy: e.target.value as any })}
                  className="w-full bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 text-xs text-slate-200 focus:outline-none"
                >
                  <option value="Median">Median Imputation</option>
                  <option value="Mean">Mean Imputation</option>
                  <option value="Mode">Mode Imputation</option>
                  <option value="Drop Rows">Drop Missing Rows</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Feature Scaling Method</label>
                <select
                  value={preprocessConfig.scalingMethod}
                  onChange={(e) => setPreprocessConfig({ ...preprocessConfig, scalingMethod: e.target.value as any })}
                  className="w-full bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 text-xs text-slate-200 focus:outline-none"
                >
                  <option value="StandardScaler">StandardScaler (Z-Score)</option>
                  <option value="MinMaxScaler">MinMaxScaler (0-1)</option>
                  <option value="RobustScaler">RobustScaler (IQR)</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Categorical Encoding</label>
                <select
                  value={preprocessConfig.encodingMethod}
                  onChange={(e) => setPreprocessConfig({ ...preprocessConfig, encodingMethod: e.target.value as any })}
                  className="w-full bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 text-xs text-slate-200 focus:outline-none"
                >
                  <option value="OneHotEncoder">OneHotEncoder (Sparse/Dense)</option>
                  <option value="OrdinalEncoder">OrdinalEncoder</option>
                  <option value="TargetEncoder">TargetEncoder</option>
                </select>
              </div>
            </div>

            <button
              onClick={handleRunPreprocessing}
              disabled={isPreprocessing || isViewer}
              className="px-5 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center space-x-2 shadow transition-all disabled:opacity-50"
            >
              {isPreprocessing ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
              <span>{isPreprocessing ? 'Executing Preprocessing Pipeline...' : 'Run Preprocessing & Tag DVC Version'}</span>
            </button>

            {preprocessDone && (
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  Successfully preprocessed dataset! Imputed null cells, applied {preprocessConfig.scalingMethod}, and tagged new DVC release version in Git lineage.
                </span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SubTab: DVC & Git Version Lineage */}
      {activeSubTab === 'versioning' && activeDataset && (
        <div className="space-y-6">
          <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-teal-400 uppercase font-bold">DVC & Git Metadata Provenance</span>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <GitBranch className="w-4 h-4 text-teal-400" />
                Dataset Version History & Lineage Graph
              </h2>
            </div>
            <span className="text-xs font-mono text-slate-400">Current Hash: <strong className="text-teal-300">{activeDataset.dvcHash}</strong></span>
          </div>

          <div className="space-y-3">
            {activeDataset.versions.map((ver, idx) => (
              <div key={ver.versionTag} className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-teal-400" />
                    <h4 className="text-xs font-bold text-white font-mono">{ver.versionTag}</h4>
                    {ver.isLatest && (
                      <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        LATEST HEAD
                      </span>
                    )}
                  </div>

                  <span className="text-[11px] text-slate-400 font-mono">{ver.createdAt}</span>
                </div>

                <p className="text-xs text-slate-300">{ver.commitMessage}</p>

                <div className="flex items-center justify-between text-[11px] font-mono bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-slate-400">
                  <span>dvc md5: <strong className="text-teal-300">{ver.dvcHash}</strong></span>
                  <span>git commit: <strong className="text-indigo-300">{ver.gitCommitHash}</strong></span>
                  <span>rows: <strong className="text-slate-200">{ver.rowCount.toLocaleString()}</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SubTab: Feature Engineering Pipeline Builder */}
      {activeSubTab === 'feature_builder' && (
        <FeaturePipelineBuilder
          datasets={datasets}
          pipeline={activePipeline}
          onUpdatePipeline={onUpdatePipeline}
          onExecutePipeline={onExecutePipeline}
          onOpenCopilotWithContext={onOpenCopilotWithContext}
        />
      )}
    </div>
  );
};
