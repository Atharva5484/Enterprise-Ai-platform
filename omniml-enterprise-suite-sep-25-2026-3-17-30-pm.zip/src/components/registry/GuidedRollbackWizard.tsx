import React, { useState } from 'react';
import {
  RotateCcw,
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
  TrendingDown,
  TrendingUp,
  Cpu,
  Layers,
  ShieldCheck,
  Zap,
  Play,
  RefreshCw,
  X,
  Activity,
  GitCommit,
  Clock,
  Server,
  Sliders,
  Sparkles,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';
import { RegisteredModel, ModelVersion, ModelStage, UserRole } from '../../types/mlops';

interface GuidedRollbackWizardProps {
  model: RegisteredModel;
  currentVersion: ModelVersion;
  allVersions: ModelVersion[];
  userRole: UserRole;
  onConfirmRollback: (targetVersionId: string, strategy: string, reason: string) => void;
  onClose: () => void;
}

// Mock Drift History comparison data over time for active vs target candidate
const MOCK_DRIFT_COMPARE_DATA = [
  { day: 'Day -7', currentVersionDrift: 0.08, targetVersionDrift: 0.04 },
  { day: 'Day -6', currentVersionDrift: 0.09, targetVersionDrift: 0.05 },
  { day: 'Day -5', currentVersionDrift: 0.12, targetVersionDrift: 0.04 },
  { day: 'Day -4', currentVersionDrift: 0.18, targetVersionDrift: 0.05 },
  { day: 'Day -3', currentVersionDrift: 0.24, targetVersionDrift: 0.06 },
  { day: 'Day -2', currentVersionDrift: 0.29, targetVersionDrift: 0.05 },
  { day: 'Today', currentVersionDrift: 0.34, targetVersionDrift: 0.06 },
];

export const GuidedRollbackWizard: React.FC<GuidedRollbackWizardProps> = ({
  model,
  currentVersion,
  allVersions,
  userRole,
  onConfirmRollback,
  onClose,
}) => {
  // Select an older version that is not the current version (default to first alternative version or fallback)
  const candidateVersions = allVersions.filter((v) => v.id !== currentVersion.id);
  const [targetVersion, setTargetVersion] = useState<ModelVersion>(
    candidateVersions[0] || currentVersion
  );

  const [activeStep, setActiveStep] = useState<number>(1);
  const [rollbackStrategy, setRollbackStrategy] = useState<'canary' | 'rolling' | 'instant'>('canary');
  const [canaryPercentage, setCanaryPercentage] = useState<number>(10);
  const [rollbackReason, setRollbackReason] = useState<string>(
    'Upstream schema mutation causing data drift & latency spike in active version v' + currentVersion.version
  );

  // Safety checks
  const [checkArtifactSignature, setCheckArtifactSignature] = useState<boolean>(true);
  const [checkHealthProbes, setCheckHealthProbes] = useState<boolean>(true);
  const [checkSchemaCompat, setCheckSchemaCompat] = useState<boolean>(true);

  // Execution state
  const [isExecutingRollback, setIsExecutingRollback] = useState<boolean>(false);
  const [executionProgress, setExecutionProgress] = useState<number>(0);
  const [executionLogs, setExecutionLogs] = useState<string[]>([]);
  const [rollbackSuccess, setRollbackSuccess] = useState<boolean>(false);

  // Compute metric deltas
  const accuracyDelta = (targetVersion.accuracy - currentVersion.accuracy) * 100;
  const f1Delta = (targetVersion.f1Score - currentVersion.f1Score) * 100;
  const latencyDelta = targetVersion.latencyMs - currentVersion.latencyMs;
  const psiDelta = targetVersion.psiScore - currentVersion.psiScore;

  // Handle trigger rollback execution simulation
  const handleTriggerRollback = () => {
    setIsExecutingRollback(true);
    setExecutionProgress(10);
    setExecutionLogs(['[INFO] Initiating admin model rollback process...']);

    setTimeout(() => {
      setExecutionProgress(30);
      setExecutionLogs((prev) => [
        ...prev,
        `[GOVERNANCE] Signed rollback auth check passed for user role: ${userRole}`,
        `[K8S] Validated model artifact SHA256 digest: sha256:e3b0c44298fc...`,
      ]);
    }, 800);

    setTimeout(() => {
      setExecutionProgress(60);
      setExecutionLogs((prev) => [
        ...prev,
        `[TRAFFIC] Initializing ${rollbackStrategy.toUpperCase()} update strategy (${canaryPercentage}% initial canary batch)...`,
        `[K8S] Spawning target model v${targetVersion.version} pod replicas in namespace 'prod-ml-serving'...`,
      ]);
    }, 1800);

    setTimeout(() => {
      setExecutionProgress(85);
      setExecutionLogs((prev) => [
        ...prev,
        `[PROBES] Readiness and Liveness probes returned HTTP 200 OK across 4/4 pods.`,
        `[GATEWAY] Shifted 100% production ingress traffic to model version v${targetVersion.version}.`,
      ]);
    }, 2800);

    setTimeout(() => {
      setExecutionProgress(100);
      setIsExecutingRollback(false);
      setRollbackSuccess(true);
      setExecutionLogs((prev) => [
        ...prev,
        `[SUCCESS] Model rollback complete! Version v${targetVersion.version} promoted to Production.`,
      ]);
    }, 3800);
  };

  const handleFinalize = () => {
    onConfirmRollback(targetVersion.id, rollbackStrategy, rollbackReason);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-slate-100">
        {/* Header */}
        <div className="p-5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-amber-500/20 border border-amber-500/40 rounded-xl text-amber-400">
              <RotateCcw className="w-5 h-5 animate-spin-slow" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                Guided Model Rollback Wizard
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  ADMIN ONLY
                </span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Model Target: <strong className="text-white">{model.name}</strong> • Current Active:{' '}
                <strong className="text-indigo-400">v{currentVersion.version}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Wizard Stepper Navigation */}
        <div className="px-6 py-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between text-xs font-mono">
          <div
            onClick={() => !isExecutingRollback && setActiveStep(1)}
            className={`flex items-center space-x-2 cursor-pointer ${
              activeStep === 1 ? 'text-indigo-400 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
              activeStep === 1 ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400'
            }`}>
              1
            </span>
            <span>Target & Diff Comparison</span>
          </div>

          <div className="h-0.5 w-12 bg-slate-800" />

          <div
            onClick={() => !isExecutingRollback && setActiveStep(2)}
            className={`flex items-center space-x-2 cursor-pointer ${
              activeStep === 2 ? 'text-indigo-400 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
              activeStep === 2 ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400'
            }`}>
              2
            </span>
            <span>Strategy & Safety Checks</span>
          </div>

          <div className="h-0.5 w-12 bg-slate-800" />

          <div
            className={`flex items-center space-x-2 ${
              activeStep === 3 ? 'text-indigo-400 font-bold' : 'text-slate-400'
            }`}
          >
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
              activeStep === 3 ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400'
            }`}>
              3
            </span>
            <span>Execution & Traffic Shift</span>
          </div>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
          {/* STEP 1: TARGET SELECTION & VERSION COMPARISON DIFF */}
          {activeStep === 1 && (
            <div className="space-y-6">
              {/* Target Version Selector */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                <label className="text-xs font-bold text-white uppercase tracking-wider block">
                  Select Stable Version to Roll Back To
                </label>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {candidateVersions.map((ver) => {
                    const isSelected = targetVersion.id === ver.id;
                    return (
                      <div
                        key={ver.id}
                        onClick={() => setTargetVersion(ver)}
                        className={`p-3 rounded-xl border cursor-pointer transition-all space-y-1.5 ${
                          isSelected
                            ? 'bg-indigo-950/40 border-indigo-500 ring-1 ring-indigo-500/50'
                            : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between font-mono">
                          <span className="font-bold text-white text-sm">v{ver.version}</span>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                            {ver.stage}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400">Created: {ver.createdAt}</p>
                        <div className="flex items-center justify-between text-[11px] font-mono text-slate-300 pt-1 border-t border-slate-800">
                          <span>Acc: {(ver.accuracy * 100).toFixed(1)}%</span>
                          <span>PSI: {ver.psiScore}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Version Comparison Diff Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Metrics Diff Table */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <span className="font-bold text-white uppercase text-[11px]">Performance Metrics Diff</span>
                    <span className="text-[10px] font-mono text-indigo-400">
                      Active v{currentVersion.version} vs Target v{targetVersion.version}
                    </span>
                  </div>

                  <table className="w-full text-left font-mono text-[11px]">
                    <thead>
                      <tr className="text-slate-500 text-[10px] uppercase border-b border-slate-800">
                        <th className="py-1.5">Metric</th>
                        <th className="py-1.5">v{currentVersion.version} (Active)</th>
                        <th className="py-1.5">v{targetVersion.version} (Target)</th>
                        <th className="py-1.5 text-right">Delta</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      <tr>
                        <td className="py-2 text-slate-300">Accuracy / AUC</td>
                        <td className="py-2 text-slate-400">{(currentVersion.accuracy * 100).toFixed(1)}%</td>
                        <td className="py-2 text-emerald-400 font-bold">{(targetVersion.accuracy * 100).toFixed(1)}%</td>
                        <td className={`py-2 text-right font-bold ${accuracyDelta >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                          {accuracyDelta >= 0 ? `+${accuracyDelta.toFixed(1)}%` : `${accuracyDelta.toFixed(1)}%`}
                        </td>
                      </tr>

                      <tr>
                        <td className="py-2 text-slate-300">F1 Score</td>
                        <td className="py-2 text-slate-400">{(currentVersion.f1Score * 100).toFixed(1)}%</td>
                        <td className="py-2 text-emerald-400 font-bold">{(targetVersion.f1Score * 100).toFixed(1)}%</td>
                        <td className={`py-2 text-right font-bold ${f1Delta >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                          {f1Delta >= 0 ? `+${f1Delta.toFixed(1)}%` : `${f1Delta.toFixed(1)}%`}
                        </td>
                      </tr>

                      <tr>
                        <td className="py-2 text-slate-300">P99 Latency</td>
                        <td className="py-2 text-amber-400 font-bold">{currentVersion.latencyMs}ms</td>
                        <td className="py-2 text-cyan-300 font-bold">{targetVersion.latencyMs}ms</td>
                        <td className="py-2 text-right font-bold text-emerald-400">
                          {latencyDelta <= 0 ? `${latencyDelta}ms` : `+${latencyDelta}ms`}
                        </td>
                      </tr>

                      <tr>
                        <td className="py-2 text-slate-300">Population Stability Index (PSI)</td>
                        <td className="py-2 text-amber-400 font-bold">{currentVersion.psiScore} (Drifted)</td>
                        <td className="py-2 text-emerald-400 font-bold">{targetVersion.psiScore} (Stable)</td>
                        <td className="py-2 text-right font-bold text-emerald-400">
                          {psiDelta.toFixed(2)}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* Hyperparameters & Metadata Comparison */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <span className="font-bold text-white uppercase text-[11px]">Artifact & Environment Specs</span>
                    <span className="text-[10px] font-mono text-emerald-400">Signature Valid</span>
                  </div>

                  <div className="space-y-2 text-[11px] font-mono">
                    <div className="flex justify-between p-2 bg-slate-900 rounded border border-slate-800">
                      <span className="text-slate-400">Framework Engine</span>
                      <span className="text-indigo-300 font-bold">{targetVersion.framework}</span>
                    </div>

                    <div className="flex justify-between p-2 bg-slate-900 rounded border border-slate-800">
                      <span className="text-slate-400">Approval Status</span>
                      <span className="text-emerald-400 font-bold">{targetVersion.approvalStatus}</span>
                    </div>

                    <div className="flex justify-between p-2 bg-slate-900 rounded border border-slate-800">
                      <span className="text-slate-400">Security Vulnerabilities</span>
                      <span className="text-emerald-400 font-bold">
                        {targetVersion.vulnerabilitiesCount} CVEs detected
                      </span>
                    </div>

                    <div className="flex justify-between p-2 bg-slate-900 rounded border border-slate-800">
                      <span className="text-slate-400">Training Snapshot URI</span>
                      <span className="text-cyan-300 font-mono truncate max-w-[180px]">s3://ml-snapshots/prod_v21.pt</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Drift History Comparison Visualization */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white uppercase text-[11px] flex items-center gap-2">
                    <Activity className="w-4 h-4 text-purple-400" />
                    Population Stability Drift Comparison (Past 7 Days)
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    Warning Threshold: <strong>0.20 PSI</strong>
                  </span>
                </div>

                <div className="h-[180px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={MOCK_DRIFT_COMPARE_DATA} margin={{ top: 10, right: 20, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                      <XAxis dataKey="day" stroke="#64748b" fontSize={11} />
                      <YAxis stroke="#64748b" fontSize={11} domain={[0, 0.4]} />
                      <Tooltip contentStyle={{ backgroundColor: '#020617', borderColor: '#334155' }} />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="currentVersionDrift"
                        name={`v${currentVersion.version} Active (Drifting)`}
                        stroke="#f59e0b"
                        strokeWidth={2}
                      />
                      <Line
                        type="monotone"
                        dataKey="targetVersionDrift"
                        name={`v${targetVersion.version} Target (Stable)`}
                        stroke="#10b981"
                        strokeWidth={2}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: ROLLBACK STRATEGY & SAFETY CHECKS */}
          {activeStep === 2 && (
            <div className="space-y-6">
              {/* Rollback Strategy Selector */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                <label className="text-xs font-bold text-white uppercase tracking-wider block">
                  Kubernetes Rolling Deployment Strategy
                </label>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div
                    onClick={() => setRollbackStrategy('canary')}
                    className={`p-3.5 rounded-xl border cursor-pointer space-y-2 ${
                      rollbackStrategy === 'canary'
                        ? 'bg-indigo-950/40 border-indigo-500 ring-1 ring-indigo-500/50'
                        : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white">Canary Shift</span>
                      <span className="text-[10px] font-mono text-indigo-400">Safest</span>
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Gradually route traffic ({canaryPercentage}% step size) while monitoring error rates & latency.
                    </p>
                  </div>

                  <div
                    onClick={() => setRollbackStrategy('rolling')}
                    className={`p-3.5 rounded-xl border cursor-pointer space-y-2 ${
                      rollbackStrategy === 'rolling'
                        ? 'bg-indigo-950/40 border-indigo-500 ring-1 ring-indigo-500/50'
                        : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white">Rolling Pod Update</span>
                      <span className="text-[10px] font-mono text-cyan-400">Zero Downtime</span>
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Sequentially replace Kubernetes pods replica by replica in the serving cluster.
                    </p>
                  </div>

                  <div
                    onClick={() => setRollbackStrategy('instant')}
                    className={`p-3.5 rounded-xl border cursor-pointer space-y-2 ${
                      rollbackStrategy === 'instant'
                        ? 'bg-indigo-950/40 border-indigo-500 ring-1 ring-indigo-500/50'
                        : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white">Instant Cutover</span>
                      <span className="text-[10px] font-mono text-amber-400">Immediate</span>
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Instantly switch Envoy gateway ingress routing rules to point to target version.
                    </p>
                  </div>
                </div>

                {rollbackStrategy === 'canary' && (
                  <div className="pt-2">
                    <label className="text-[11px] font-mono text-slate-400">Initial Canary Traffic Batch (%)</label>
                    <div className="flex items-center space-x-3 mt-1">
                      <input
                        type="range"
                        min="5"
                        max="50"
                        value={canaryPercentage}
                        onChange={(e) => setCanaryPercentage(parseInt(e.target.value))}
                        className="w-full accent-indigo-500"
                      />
                      <span className="font-mono text-indigo-300 font-bold text-xs">{canaryPercentage}%</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Justification & Governance Reason */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <label className="text-xs font-bold text-white uppercase tracking-wider block">
                  Mandatory Governance Rollback Audit Log Reason
                </label>
                <textarea
                  value={rollbackReason}
                  onChange={(e) => setRollbackReason(e.target.value)}
                  rows={2}
                  className="w-full bg-slate-900 p-3 rounded-xl border border-slate-800 text-white font-mono text-xs focus:outline-none focus:border-indigo-500"
                  placeholder="Provide incident ID or cause for rollback..."
                />
              </div>

              {/* Safety Pre-flight Verification Checklist */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                <span className="text-xs font-bold text-white uppercase tracking-wider block">
                  Pre-flight Automated Verification Checks
                </span>

                <div className="space-y-2 text-xs font-mono">
                  <label className="flex items-center justify-between p-2.5 bg-slate-900 rounded-lg border border-slate-800 cursor-pointer">
                    <div className="flex items-center space-x-2">
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      <span className="text-slate-200">Validate Cryptographic Artifact Signatures & Checksums</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={checkArtifactSignature}
                      onChange={(e) => setCheckArtifactSignature(e.target.checked)}
                      className="accent-emerald-500 w-4 h-4"
                    />
                  </label>

                  <label className="flex items-center justify-between p-2.5 bg-slate-900 rounded-lg border border-slate-800 cursor-pointer">
                    <div className="flex items-center space-x-2">
                      <Zap className="w-4 h-4 text-cyan-400" />
                      <span className="text-slate-200">Verify Liveness/Readiness Health Probes on Target Version</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={checkHealthProbes}
                      onChange={(e) => setCheckHealthProbes(e.target.checked)}
                      className="accent-emerald-500 w-4 h-4"
                    />
                  </label>

                  <label className="flex items-center justify-between p-2.5 bg-slate-900 rounded-lg border border-slate-800 cursor-pointer">
                    <div className="flex items-center space-x-2">
                      <Layers className="w-4 h-4 text-purple-400" />
                      <span className="text-slate-200">Confirm Online Feature Store Schema Backward Compatibility</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={checkSchemaCompat}
                      onChange={(e) => setCheckSchemaCompat(e.target.checked)}
                      className="accent-emerald-500 w-4 h-4"
                    />
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: EXECUTION & PROGRESS SIMULATION */}
          {activeStep === 3 && (
            <div className="space-y-6">
              <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Server className="w-4 h-4 text-indigo-400" />
                    <span className="font-bold text-white text-xs uppercase">Rolling Update Execution Status</span>
                  </div>
                  <span className="font-mono text-xs font-bold text-indigo-300">{executionProgress}%</span>
                </div>

                {/* Progress Bar */}
                <div className="w-full bg-slate-900 h-2.5 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className="h-full bg-gradient-to-r from-indigo-500 to-emerald-500 transition-all duration-500"
                    style={{ width: `${executionProgress}%` }}
                  />
                </div>

                {/* Console Log Stream */}
                <div className="bg-black/90 p-4 rounded-xl border border-slate-800/80 font-mono text-[11px] space-y-1.5 h-[200px] overflow-y-auto">
                  {executionLogs.map((log, index) => (
                    <p
                      key={index}
                      className={
                        log.includes('SUCCESS')
                          ? 'text-emerald-400 font-bold'
                          : log.includes('GOVERNANCE')
                          ? 'text-purple-300'
                          : log.includes('TRAFFIC')
                          ? 'text-cyan-300'
                          : 'text-slate-300'
                      }
                    >
                      {log}
                    </p>
                  ))}
                  {isExecutingRollback && (
                    <div className="flex items-center space-x-2 text-indigo-400 py-1">
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Reconfiguring Kubernetes pod replicas...</span>
                    </div>
                  )}
                </div>
              </div>

              {rollbackSuccess && (
                <div className="p-4 bg-emerald-950/40 rounded-xl border border-emerald-500/50 flex items-center justify-between text-xs text-emerald-200">
                  <div className="flex items-center space-x-3">
                    <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
                    <div>
                      <strong className="block text-white font-bold">Rollback Successfully Executed!</strong>
                      <span>
                        Target version <strong>v{targetVersion.version}</strong> is now serving 100% of production traffic.
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
          <div>
            {activeStep > 1 && !isExecutingRollback && !rollbackSuccess && (
              <button
                onClick={() => setActiveStep((prev) => prev - 1)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors"
              >
                Back
              </button>
            )}
          </div>

          <div className="flex items-center space-x-3">
            {activeStep === 1 && (
              <button
                onClick={() => setActiveStep(2)}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center space-x-1.5 transition-all shadow"
              >
                <span>Proceed to Strategy & Safety</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            {activeStep === 2 && (
              <button
                onClick={() => {
                  setActiveStep(3);
                  handleTriggerRollback();
                }}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-red-600 hover:from-amber-500 hover:to-red-500 text-white font-bold text-xs flex items-center space-x-2 shadow-lg shadow-red-600/20 transition-all"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Trigger Admin Rolling Update</span>
              </button>
            )}

            {activeStep === 3 && rollbackSuccess && (
              <button
                onClick={handleFinalize}
                className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all shadow"
              >
                Done & Return to Registry
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
