import React, { useState, useEffect } from 'react';
import {
  Layers,
  GitBranch,
  ShieldCheck,
  Sparkles,
  Download,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ExternalLink,
  Code,
  Sliders,
  FileText,
  X,
  Play,
  RotateCcw,
  CheckSquare,
  Square,
  Trash2,
  Archive,
  ArrowUpRight,
  Check,
} from 'lucide-react';
import { RegisteredModel, ModelVersion, ModelStage, UserRole } from '../../types/mlops';
import { GuidedRollbackWizard } from './GuidedRollbackWizard';
import { exportToCSV } from '../../utils/exportUtils';
import { useAlertCenter } from '../../context/AlertCenterContext';

interface ModelRegistryViewProps {
  models: RegisteredModel[];
  onPromoteVersion: (modelId: string, versionId: string, newStage: ModelStage) => void;
  userRole: UserRole;
  onOpenCopilotWithContext: (contextPrompt: string) => void;
  onOpenExportModal?: (context?: string) => void;
}

export const ModelRegistryView: React.FC<ModelRegistryViewProps> = ({
  models,
  onPromoteVersion,
  userRole,
  onOpenCopilotWithContext,
  onOpenExportModal,
}) => {
  const { addAlert } = useAlertCenter();

  const [modelList, setModelList] = useState<RegisteredModel[]>(models);
  const [selectedModelIds, setSelectedModelIds] = useState<string[]>([]);

  useEffect(() => {
    setModelList(models);
  }, [models]);

  const [selectedModel, setSelectedModel] = useState<RegisteredModel>(models[0] || modelList[0]);
  const [selectedVersion, setSelectedVersion] = useState<ModelVersion>(models[0]?.versions[0] || modelList[0]?.versions[0]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterFramework, setFilterFramework] = useState<string>('All');
  const [isGeneratingCard, setIsGeneratingCard] = useState(false);
  const [generatedModelCard, setGeneratedModelCard] = useState<string | null>(null);
  const [showModelCardModal, setShowModelCardModal] = useState(false);
  const [showRollbackWizard, setShowRollbackWizard] = useState(false);

  const filteredModels = modelList.filter((m) => {
    const matchesSearch =
      m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase())) ||
      m.taskType.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFramework =
      filterFramework === 'All' || m.versions.some((v) => v.framework === filterFramework);
    return matchesSearch && matchesFramework;
  });

  const activeSelectedModel = modelList.find((m) => m.id === selectedModel?.id) || filteredModels[0] || modelList[0];

  const toggleSelectModel = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSelectedModelIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    if (selectedModelIds.length === filteredModels.length && filteredModels.length > 0) {
      setSelectedModelIds([]);
    } else {
      setSelectedModelIds(filteredModels.map((m) => m.id));
    }
  };

  const handleBatchPromote = (targetStage: ModelStage) => {
    if (selectedModelIds.length === 0) return;

    setModelList((prev) =>
      prev.map((m) => {
        if (selectedModelIds.includes(m.id)) {
          const updatedVersions = m.versions.map((v, idx) =>
            idx === 0 ? { ...v, stage: targetStage } : v
          );
          if (m.versions[0]) {
            onPromoteVersion(m.id, m.versions[0].id, targetStage);
          }
          return { ...m, versions: updatedVersions, lastUpdated: 'Just now' };
        }
        return m;
      })
    );

    addAlert({
      type: 'system',
      severity: 'info',
      title: `Batch Stage Update (${selectedModelIds.length} Models)`,
      message: `Promoted latest version of ${selectedModelIds.length} selected models to stage '${targetStage}'.`,
      source: 'Model Registry Batch Manager',
      actionLabel: 'Registry Audit',
    });

    setSelectedModelIds([]);
  };

  const handleBatchArchive = () => {
    handleBatchPromote('Archived');
  };

  const handleBatchDelete = () => {
    if (selectedModelIds.length === 0) return;
    const count = selectedModelIds.length;

    setModelList((prev) => prev.filter((m) => !selectedModelIds.includes(m.id)));

    addAlert({
      type: 'system',
      severity: 'warning',
      title: `Batch Archived / Removed (${count} Models)`,
      message: `Removed ${count} selected models from active registry index.`,
      source: 'Model Registry Batch Manager',
    });

    setSelectedModelIds([]);
  };

  // Call server AI endpoint to generate ISO/IEEE Model Card
  const handleGenerateModelCard = async () => {
    try {
      setIsGeneratingCard(true);
      setShowModelCardModal(true);
      const res = await fetch('/api/generate-model-card', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          modelName: selectedModel.name,
          framework: selectedVersion.framework,
          taskType: selectedModel.taskType,
          metrics: {
            accuracy: selectedVersion.accuracy,
            f1Score: selectedVersion.f1Score,
            latencyMs: selectedVersion.latencyMs,
            psiScore: selectedVersion.psiScore,
            vulnerabilitiesCount: selectedVersion.vulnerabilitiesCount,
          },
        }),
      });
      const data = await res.json();
      setGeneratedModelCard(data.modelCardMarkdown || 'Failed to parse model card markdown.');
    } catch (err) {
      console.error(err);
      setGeneratedModelCard('# Error\nFailed to generate AI model card.');
    } finally {
      setIsGeneratingCard(false);
    }
  };

  return (
    <div className="p-6 space-y-6 text-slate-100 max-w-[1600px] mx-auto">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 p-5 rounded-2xl border border-slate-800">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center gap-2">
            <Layers className="w-5 h-5 text-indigo-400" />
            Enterprise Model Registry & Artifact Store
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage model versions, compliance approval gates, lineage trees, and security vulnerability scans.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <input
            type="text"
            placeholder="Search models, tags, tasks..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-slate-950 px-3.5 py-2 rounded-xl text-xs border border-slate-800 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 w-64"
          />

          <select
            value={filterFramework}
            onChange={(e) => setFilterFramework(e.target.value)}
            className="bg-slate-950 px-3 py-2 rounded-xl text-xs border border-slate-800 text-slate-200 focus:outline-none focus:border-indigo-500"
          >
            <option value="All">All Frameworks</option>
            <option value="PyTorch">PyTorch</option>
            <option value="XGBoost">XGBoost</option>
            <option value="HuggingFace">HuggingFace</option>
          </select>

          <button
            onClick={() => {
              if (onOpenExportModal) {
                onOpenExportModal('model_registry');
              } else {
                exportToCSV(
                  models.map((m) => ({
                    id: m.id,
                    name: m.name,
                    taskType: m.taskType,
                    owner: m.owner,
                    versionsCount: m.versions.length,
                    latestVersion: m.versions[0]?.version,
                    latestStage: m.versions[0]?.stage,
                  })),
                  'registered_models_export.csv'
                );
              }
            }}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 border border-indigo-500/30 font-bold text-xs flex items-center space-x-1.5 transition-colors shadow-sm shrink-0"
            title="Export Model Registry Data"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            <span>Export Registry</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Left Model Catalog - Right Detailed Version & Lineage Drawer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Model List (5 Cols) */}
        <div className="lg:col-span-5 space-y-3">
          {/* Multi-Select Batch Actions Header */}
          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 flex items-center justify-between font-mono text-xs">
            <button
              onClick={handleSelectAll}
              className="flex items-center space-x-2 text-slate-300 hover:text-white font-bold transition-colors"
            >
              {selectedModelIds.length === filteredModels.length && filteredModels.length > 0 ? (
                <CheckSquare className="w-4 h-4 text-indigo-400" />
              ) : (
                <Square className="w-4 h-4 text-slate-500" />
              )}
              <span>
                {selectedModelIds.length > 0
                  ? `${selectedModelIds.length} Selected`
                  : 'Select All Models'}
              </span>
            </button>

            {selectedModelIds.length > 0 && (
              <div className="flex items-center space-x-1.5">
                <button
                  onClick={() => handleBatchPromote('Production')}
                  className="px-2.5 py-1 rounded bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold flex items-center gap-1"
                  title="Bulk Promote Selected to Production"
                >
                  <ArrowUpRight className="w-3 h-3 text-emerald-400" />
                  <span>Prod</span>
                </button>

                <button
                  onClick={() => handleBatchPromote('Staging')}
                  className="px-2.5 py-1 rounded bg-amber-600/30 hover:bg-amber-600/50 text-amber-300 border border-amber-500/40 text-[10px] font-bold flex items-center gap-1"
                  title="Bulk Promote Selected to Staging"
                >
                  <span>Staging</span>
                </button>

                <button
                  onClick={handleBatchArchive}
                  className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-[10px] font-bold flex items-center gap-1"
                  title="Bulk Archive Selected"
                >
                  <Archive className="w-3 h-3 text-slate-400" />
                  <span>Archive</span>
                </button>

                <button
                  onClick={handleBatchDelete}
                  className="px-2.5 py-1 rounded bg-rose-600/30 hover:bg-rose-600/50 text-rose-300 border border-rose-500/40 text-[10px] font-bold flex items-center gap-1"
                  title="Bulk Remove Selected"
                >
                  <Trash2 className="w-3 h-3 text-rose-400" />
                </button>
              </div>
            )}
          </div>

          {filteredModels.map((model) => {
            const isSelected = activeSelectedModel?.id === model.id;
            const isChecked = selectedModelIds.includes(model.id);
            const prodVersion = model.versions.find((v) => v.stage === 'Production') || model.versions[0];
            return (
              <div
                key={model.id}
                onClick={() => {
                  setSelectedModel(model);
                  if (model.versions && model.versions[0]) {
                    setSelectedVersion(model.versions[0]);
                  }
                }}
                className={`p-4 rounded-xl border transition-all cursor-pointer relative ${
                  isSelected
                    ? 'bg-slate-900 border-indigo-500/80 ring-1 ring-indigo-500/40 shadow-lg'
                    : isChecked
                    ? 'bg-indigo-950/30 border-indigo-500/50'
                    : 'bg-slate-900/60 border-slate-800/80 hover:bg-slate-900 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start space-x-2.5">
                    <button
                      onClick={(e) => toggleSelectModel(model.id, e)}
                      className="mt-0.5 p-0.5 text-slate-400 hover:text-white transition-colors shrink-0"
                    >
                      {isChecked ? (
                        <CheckSquare className="w-4 h-4 text-indigo-400" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-600 hover:text-slate-400" />
                      )}
                    </button>

                    <div>
                      <h3 className="text-sm font-bold text-white group-hover:text-indigo-300">{model.name}</h3>
                      <p className="text-xs text-slate-400 mt-1 line-clamp-2">{model.description}</p>
                    </div>
                  </div>

                  <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 shrink-0">
                    {model.taskType}
                  </span>
                </div>

                {/* Tags & Compliance Pills */}
                <div className="flex flex-wrap gap-1.5 mt-3">
                  {model.tags.map((tag) => (
                    <span key={tag} className="text-[10px] px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                      #{tag}
                    </span>
                  ))}
                  {model.complianceTags.map((ctag) => (
                    <span key={ctag} className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      ✓ {ctag}
                    </span>
                  ))}
                </div>

                {/* Footer Version Strip */}
                <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-mono">
                  <span>Prod: <strong className="text-emerald-400">{prodVersion.version}</strong></span>
                  <span>Accuracy: <strong className="text-white">{(prodVersion.accuracy * 100).toFixed(1)}%</strong></span>
                  <span>P99: <strong className="text-cyan-300">{prodVersion.latencyMs}ms</strong></span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Column: Selected Model Details, Version Matrix & Lineage (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Header Card for Selected Model */}
          <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400">Selected Registry Item</span>
                <h2 className="text-lg font-bold text-white">{selectedModel.name}</h2>
                <p className="text-xs text-slate-400">Team Owner: {selectedModel.ownerTeam}</p>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={handleGenerateModelCard}
                  className="px-3.5 py-2 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 text-xs font-semibold flex items-center space-x-1.5 transition-all"
                >
                  <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
                  <span>AI Model Card</span>
                </button>

                <button
                  onClick={() =>
                    onOpenCopilotWithContext(
                      `Analyze model registry status for ${selectedModel.name} version ${selectedVersion.version}. Compare metrics and suggest optimal hyperparameter retraining strategy.`
                    )
                  }
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center space-x-1.5 transition-all"
                >
                  <Code className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Ask Copilot</span>
                </button>
              </div>
            </div>

            {/* Version Tabs */}
            <div className="flex items-center space-x-2 border-b border-slate-800 pb-2 overflow-x-auto">
              <span className="text-xs font-bold text-slate-500 mr-2 uppercase">Versions:</span>
              {selectedModel.versions.map((ver) => {
                const isVerSelected = selectedVersion.id === ver.id;
                return (
                  <button
                    key={ver.id}
                    onClick={() => setSelectedVersion(ver)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all flex items-center space-x-1.5 ${
                      isVerSelected
                        ? 'bg-indigo-600 text-white shadow'
                        : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                    }`}
                  >
                    <span>{ver.version}</span>
                    <span
                      className={`text-[9px] px-1.5 py-0.2 rounded uppercase ${
                        ver.stage === 'Production'
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : ver.stage === 'Staging'
                          ? 'bg-amber-500/20 text-amber-300'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {ver.stage}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Selected Version Key Metrics & Gate Checks */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase font-bold">Accuracy / AUC</span>
                <div className="text-base font-extrabold text-white font-mono mt-0.5">
                  {(selectedVersion.accuracy * 100).toFixed(1)}%
                </div>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase font-bold">F1 Score</span>
                <div className="text-base font-extrabold text-white font-mono mt-0.5">
                  {(selectedVersion.f1Score * 100).toFixed(1)}%
                </div>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase font-bold">Inference Latency</span>
                <div className="text-base font-extrabold text-cyan-400 font-mono mt-0.5">
                  {selectedVersion.latencyMs}ms
                </div>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase font-bold">PSI Drift Score</span>
                <div className={`text-base font-extrabold font-mono mt-0.5 ${selectedVersion.psiScore > 0.2 ? 'text-amber-400' : 'text-emerald-400'}`}>
                  {selectedVersion.psiScore}
                </div>
              </div>
            </div>

            {/* Stage Promotion Actions */}
            <div className="p-4 bg-slate-950/80 rounded-xl border border-slate-800/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
              <div>
                <span className="font-semibold text-slate-200">Current Stage: </span>
                <span className="font-mono text-indigo-300 font-bold">{selectedVersion.stage}</span>
                <span className="text-slate-400 ml-3">Approval: <strong className="text-emerald-400">{selectedVersion.approvalStatus}</strong></span>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setShowRollbackWizard(true)}
                  className="px-3 py-1.5 rounded-lg bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/40 font-bold text-xs flex items-center space-x-1.5 transition-all"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Rollback Wizard</span>
                </button>

                {selectedVersion.stage !== 'Production' && (
                  <button
                    onClick={() => onPromoteVersion(selectedModel.id, selectedVersion.id, 'Production')}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow transition-all"
                  >
                    Promote to Production
                  </button>
                )}
                {selectedVersion.stage !== 'Staging' && selectedVersion.stage !== 'Production' && (
                  <button
                    onClick={() => onPromoteVersion(selectedModel.id, selectedVersion.id, 'Staging')}
                    className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs shadow transition-all"
                  >
                    Promote to Staging
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Lineage Tree Visualization */}
          <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
              <GitBranch className="w-4 h-4 text-indigo-400" />
              End-to-End Lineage Tree (Data → Model → Endpoint)
            </h3>

            <div className="flex flex-col md:flex-row items-center justify-between gap-3 p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono">
              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 text-center w-full md:w-1/4">
                <span className="text-[10px] text-slate-500 block uppercase">Data Source</span>
                <span className="font-semibold text-slate-200 block mt-1">Snowflake Raw Batches</span>
                <span className="text-[10px] text-slate-400">14.2M rows</span>
              </div>

              <ArrowRight className="w-4 h-4 text-slate-600 hidden md:block" />

              <div className="p-3 bg-slate-900 rounded-lg border border-indigo-500/30 text-center w-full md:w-1/4">
                <span className="text-[10px] text-indigo-400 block uppercase">Feature Store</span>
                <span className="font-semibold text-white block mt-1">user_txn_realtime</span>
                <span className="text-[10px] text-slate-400">14 Features</span>
              </div>

              <ArrowRight className="w-4 h-4 text-slate-600 hidden md:block" />

              <div className="p-3 bg-indigo-950/40 rounded-lg border border-indigo-500/50 text-center w-full md:w-1/4">
                <span className="text-[10px] text-indigo-300 block uppercase">Model Artifact</span>
                <span className="font-semibold text-indigo-200 block mt-1">{selectedVersion.version}</span>
                <span className="text-[10px] text-emerald-400">{selectedVersion.framework}</span>
              </div>

              <ArrowRight className="w-4 h-4 text-slate-600 hidden md:block" />

              <div className="p-3 bg-slate-900 rounded-lg border border-cyan-500/30 text-center w-full md:w-1/4">
                <span className="text-[10px] text-cyan-400 block uppercase">Serving Gateway</span>
                <span className="font-semibold text-slate-200 block mt-1">prod-fraud-gateway</span>
                <span className="text-[10px] text-cyan-300">18.4k QPS</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal for Generated AI Model Card */}
      {showModelCardModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-3xl w-full max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <FileText className="w-5 h-5 text-indigo-400" />
                <h3 className="font-bold text-white text-sm">ISO/IEEE AI Model Card Generator</h3>
              </div>
              <button
                onClick={() => setShowModelCardModal(false)}
                className="p-1 rounded bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto font-mono text-xs text-slate-200 space-y-4 whitespace-pre-wrap leading-relaxed">
              {isGeneratingCard ? (
                <div className="flex flex-col items-center justify-center py-12 space-y-3">
                  <div className="w-8 h-8 border-3 border-indigo-500 border-t-transparent rounded-full animate-spin" />
                  <span className="text-slate-400 text-xs">Generating ISO compliance audit card with Gemini 3.6...</span>
                </div>
              ) : (
                generatedModelCard
              )}
            </div>

            <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setShowModelCardModal(false)}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold"
              >
                Close Model Card
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Guided Rollback Wizard Modal */}
      {showRollbackWizard && (
        <GuidedRollbackWizard
          model={selectedModel}
          currentVersion={selectedVersion}
          allVersions={selectedModel.versions}
          userRole={userRole}
          onConfirmRollback={(targetVersionId) => {
            onPromoteVersion(selectedModel.id, targetVersionId, 'Production');
            setShowRollbackWizard(false);
          }}
          onClose={() => setShowRollbackWizard(false)}
        />
      )}
    </div>
  );
};
