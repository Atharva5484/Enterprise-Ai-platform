import React, { useState } from 'react';
import {
  Zap,
  Sliders,
  Send,
  Play,
  Activity,
  CheckCircle2,
  Clock,
  Cpu,
  Server,
  Sparkles,
  RefreshCw,
  Code,
} from 'lucide-react';
import { ServingEndpoint } from '../../types/mlops';

interface ModelServingViewProps {
  endpoints: ServingEndpoint[];
  onUpdateTraffic: (endpointId: string, canaryPercent: number) => void;
  onOpenCopilotWithContext: (prompt: string) => void;
}

export const ModelServingView: React.FC<ModelServingViewProps> = ({
  endpoints,
  onUpdateTraffic,
  onOpenCopilotWithContext,
}) => {
  const [selectedEndpoint, setSelectedEndpoint] = useState<ServingEndpoint>(endpoints[0]);
  const [canaryTraffic, setCanaryTraffic] = useState<number>(endpoints[0].canaryTrafficPercent);
  const [inferencePayload, setInferencePayload] = useState<string>(
    JSON.stringify(
      {
        user_id: 10042,
        txn_amount: 1450.0,
        txn_velocity_1h: 4,
        unique_device_ip_count_7d: 5,
        query: 'What are the AML disclosure requirements for cross-border wire transfers over $10,000?',
      },
      null,
      2
    )
  );
  const [inferenceResult, setInferenceResult] = useState<any>(null);
  const [isInferring, setIsInferring] = useState<boolean>(false);

  // Send request to server inference gateway
  const handleRunInference = async () => {
    try {
      setIsInferring(true);
      setInferenceResult(null);
      let parsedPayload = {};
      try {
        parsedPayload = JSON.parse(inferencePayload);
      } catch {
        parsedPayload = { query: inferencePayload };
      }

      const res = await fetch('/api/inference', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          endpointName: selectedEndpoint.name,
          payload: parsedPayload,
        }),
      });

      const data = await res.json();
      setInferenceResult(data);
    } catch (err: any) {
      console.error(err);
      setInferenceResult({ error: 'Inference gateway error', details: err.message });
    } finally {
      setIsInferring(false);
    }
  };

  const handleApplyTraffic = () => {
    onUpdateTraffic(selectedEndpoint.id, canaryTraffic);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 p-5 rounded-2xl border border-slate-800">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center gap-2">
            <Zap className="w-5 h-5 text-cyan-400" />
            Production Model Serving & Traffic Gateway (Triton / vLLM / KServe)
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Canary / Blue-Green deployments, hardware acceleration auto-scaling, and live inference gateway testing.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() =>
              onOpenCopilotWithContext(
                `Suggest optimal auto-scaling HPA rules and Kubernetes replica count for serving endpoint ${selectedEndpoint.name} running on ${selectedEndpoint.hardware}.`
              )
            }
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center space-x-1.5 transition-all border border-slate-700"
          >
            <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
            <span>Optimize Scaling Policy</span>
          </button>
        </div>
      </div>

      {/* Endpoint Cards & Selected Endpoint Traffic Controller */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Endpoint Cards (5 Cols) */}
        <div className="lg:col-span-5 space-y-3">
          {endpoints.map((ep) => {
            const isSelected = selectedEndpoint.id === ep.id;
            return (
              <div
                key={ep.id}
                onClick={() => {
                  setSelectedEndpoint(ep);
                  setCanaryTraffic(ep.canaryTrafficPercent);
                }}
                className={`p-4 rounded-xl border transition-all cursor-pointer space-y-3 ${
                  isSelected
                    ? 'bg-slate-900 border-cyan-500/80 ring-1 ring-cyan-500/40 shadow-lg'
                    : 'bg-slate-900/60 border-slate-800 hover:bg-slate-900'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-mono font-bold text-cyan-400 uppercase">{ep.strategy} Strategy</span>
                    <h3 className="text-sm font-bold text-white">{ep.name}</h3>
                    <p className="text-xs text-slate-400 mt-0.5">{ep.modelName} ({ep.currentVersion})</p>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    {ep.status}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-xs font-mono bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <div>
                    <span className="text-[10px] text-slate-500 block">QPS</span>
                    <span className="text-white font-bold">{ep.qps.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">P99 Latency</span>
                    <span className="text-cyan-300 font-bold">{ep.p99LatencyMs}ms</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">Replicas</span>
                    <span className="text-indigo-300 font-bold">{ep.replicas} pods</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Column: Traffic Control & Live Playground (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Traffic Splitter Slider */}
          <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div>
                <h2 className="text-sm font-bold text-white flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-cyan-400" />
                  Canary & Blue-Green Traffic Splitter
                </h2>
                <p className="text-xs text-slate-400">Endpoint: {selectedEndpoint.name}</p>
              </div>

              <button
                onClick={handleApplyTraffic}
                className="px-3.5 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow transition-all"
              >
                Apply Allocation
              </button>
            </div>

            {/* Slider */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span>Main Version ({selectedEndpoint.currentVersion}): <strong className="text-white">{100 - canaryTraffic}%</strong></span>
                <span>Canary Version ({selectedEndpoint.targetVersion || 'v2.5.0-rc1'}): <strong className="text-cyan-300">{canaryTraffic}%</strong></span>
              </div>

              <input
                type="range"
                min="0"
                max="100"
                value={canaryTraffic}
                onChange={(e) => setCanaryTraffic(Number(e.target.value))}
                className="w-full accent-cyan-400 bg-slate-950 h-2 rounded-lg cursor-pointer"
              />

              <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden flex border border-slate-800">
                <div
                  style={{ width: `${100 - canaryTraffic}%` }}
                  className="bg-indigo-600 h-full flex items-center justify-center text-[9px] font-bold text-white"
                >
                  Main ({100 - canaryTraffic}%)
                </div>
                <div
                  style={{ width: `${canaryTraffic}%` }}
                  className="bg-cyan-400 h-full flex items-center justify-center text-[9px] font-bold text-slate-950"
                >
                  Canary ({canaryTraffic}%)
                </div>
              </div>
            </div>
          </div>

          {/* Live Inference Gateway Playground */}
          <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Send className="w-4 h-4 text-emerald-400" />
                Live Inference Playground Gateway
              </h2>

              <button
                onClick={handleRunInference}
                disabled={isInferring}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center space-x-2 shadow transition-all disabled:opacity-50"
              >
                {isInferring ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Play className="w-3.5 h-3.5 fill-current" />
                )}
                <span>{isInferring ? 'Executing...' : 'Send Inference Payload'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Payload Editor */}
              <div className="space-y-1">
                <label className="text-[11px] font-mono text-slate-400 uppercase font-bold">Payload Request (JSON / Prompt)</label>
                <textarea
                  value={inferencePayload}
                  onChange={(e) => setInferencePayload(e.target.value)}
                  rows={8}
                  className="w-full bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-xs text-slate-200 focus:outline-none focus:border-cyan-500 leading-relaxed"
                />
              </div>

              {/* Response Viewer */}
              <div className="space-y-1">
                <label className="text-[11px] font-mono text-slate-400 uppercase font-bold">Gateway Response & Telemetry</label>
                <div className="w-full bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-xs text-emerald-300 h-[190px] overflow-y-auto leading-relaxed">
                  {isInferring ? (
                    <div className="flex flex-col items-center justify-center h-full text-slate-500 space-y-2">
                      <div className="w-5 h-5 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
                      <span>Sending payload through ingress envoy proxy...</span>
                    </div>
                  ) : inferenceResult ? (
                    <pre>{JSON.stringify(inferenceResult, null, 2)}</pre>
                  ) : (
                    <span className="text-slate-600 italic">
                      Click "Send Inference Payload" to execute real model inference.
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
