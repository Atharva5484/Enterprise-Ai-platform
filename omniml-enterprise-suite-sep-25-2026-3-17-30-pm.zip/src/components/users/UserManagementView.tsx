import React, { useState } from 'react';
import {
  Users,
  ShieldCheck,
  Key,
  UserPlus,
  Search,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  Trash2,
  Lock,
  Mail,
  Shield,
  Zap,
  Globe,
  Plus,
} from 'lucide-react';
import { UserRole } from '../../types/mlops';

interface UserAccount {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  department: string;
  status: 'Active' | 'Pending' | 'Suspended';
  lastActive: string;
  avatarUrl?: string;
}

interface ApiToken {
  id: string;
  name: string;
  tokenPrefix: string;
  createdAt: string;
  expiresAt: string;
  scope: string[];
}

export const UserManagementView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'users' | 'rbac' | 'tokens' | 'sso'>('users');
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedTokenId, setCopiedTokenId] = useState<string | null>(null);

  const [users, setUsers] = useState<UserAccount[]>([
    {
      id: 'usr-1',
      name: 'Adesh Chindhe',
      email: 'adeshchindhe5@gmail.com',
      role: 'MLOps Admin',
      department: 'Platform Engineering',
      status: 'Active',
      lastActive: 'Just now',
    },
    {
      id: 'usr-2',
      name: 'Elena Rostova',
      email: 'elena.rostova@enterprise.ai',
      role: 'Lead Data Scientist',
      department: 'Fraud AI Research',
      status: 'Active',
      lastActive: '12 mins ago',
    },
    {
      id: 'usr-3',
      name: 'Marcus Vance',
      email: 'marcus.vance@enterprise.ai',
      role: 'ML Engineer',
      department: 'Serving & Infrastructure',
      status: 'Active',
      lastActive: '1 hour ago',
    },
    {
      id: 'usr-4',
      name: 'Sarah Chen',
      email: 'sarah.chen@enterprise.ai',
      role: 'Compliance Officer',
      department: 'AI Safety & Audit',
      status: 'Active',
      lastActive: '3 hours ago',
    },
    {
      id: 'usr-5',
      name: 'David Miller',
      email: 'david.miller@enterprise.ai',
      role: 'Data Scientist',
      department: 'Analytics & Risk',
      status: 'Pending',
      lastActive: 'Never',
    },
  ]);

  const [apiTokens, setApiTokens] = useState<ApiToken[]>([
    {
      id: 'tok-1',
      name: 'Kubeflow CI/CD Pipeline Agent Token',
      tokenPrefix: 'mlops_pat_94f8a2...',
      createdAt: '2026-07-01',
      expiresAt: '2027-07-01',
      scope: ['pipelines:write', 'models:read', 'deployments:write'],
    },
    {
      id: 'tok-2',
      name: 'Prometheus Monitoring Metrics Exporter',
      tokenPrefix: 'mlops_pat_83a19b...',
      createdAt: '2026-07-15',
      expiresAt: '2027-01-15',
      scope: ['monitoring:read'],
    },
  ]);

  const [isInviteOpen, setIsInviteOpen] = useState(false);
  const [newEmail, setNewEmail] = useState('');
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState<UserRole>('ML Engineer');

  const filteredUsers = users.filter(
    (u) =>
      u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.role.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedTokenId(id);
    setTimeout(() => setCopiedTokenId(null), 2000);
  };

  const handleInviteUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmail || !newName) return;

    const newUser: UserAccount = {
      id: `usr-${Date.now()}`,
      name: newName,
      email: newEmail,
      role: newRole,
      department: 'AI Engineering',
      status: 'Pending',
      lastActive: 'Invited',
    };

    setUsers([newUser, ...users]);
    setNewEmail('');
    setNewName('');
    setIsInviteOpen(false);
  };

  const handleCreateToken = () => {
    const newToken: ApiToken = {
      id: `tok-${Date.now()}`,
      name: 'New Personal Access Token',
      tokenPrefix: `mlops_pat_${Math.random().toString(36).substring(2, 10)}...`,
      createdAt: new Date().toISOString().substring(0, 10),
      expiresAt: new Date(Date.now() + 365 * 86400000).toISOString().substring(0, 10),
      scope: ['models:read', 'pipelines:read'],
    };
    setApiTokens([newToken, ...apiTokens]);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 p-5 rounded-2xl border border-slate-800">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-400" />
            User Management, Role-Based Access Control (RBAC) & SSO Studio
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage enterprise team permissions, personal access tokens, SSO OAuth integrations (Okta, Azure AD), and granular resource policies.
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center space-x-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveTab('users')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'users'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Users & Members ({users.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('rbac')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'rbac'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>RBAC Matrix</span>
          </button>

          <button
            onClick={() => setActiveTab('tokens')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'tokens'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Key className="w-3.5 h-3.5" />
            <span>API & PAT Tokens</span>
          </button>

          <button
            onClick={() => setActiveTab('sso')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'sso'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>SSO / OAuth</span>
          </button>
        </div>
      </div>

      {/* TAB 1: USER ACCOUNTS DIRECTORY */}
      {activeTab === 'users' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search user name, email, or role..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <button
              onClick={() => setIsInviteOpen(true)}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center space-x-2 shadow-lg shadow-indigo-600/20 transition-all"
            >
              <UserPlus className="w-4 h-4" />
              <span>Invite New Member</span>
            </button>
          </div>

          {/* Invite User Modal */}
          {isInviteOpen && (
            <form onSubmit={handleInviteUser} className="bg-slate-900 border border-indigo-500/40 p-5 rounded-2xl space-y-4">
              <h3 className="text-xs font-bold text-white uppercase font-mono">Invite Team Member to Workspace</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
                <div>
                  <label className="text-slate-400 block mb-1">Full Name</label>
                  <input
                    type="text"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="e.g. Dr. Alex Vance"
                    required
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Corporate Email</label>
                  <input
                    type="email"
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    placeholder="alex.vance@company.com"
                    required
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Assign Role</label>
                  <select
                    value={newRole}
                    onChange={(e) => setNewRole(e.target.value as UserRole)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="MLOps Admin">MLOps Admin</option>
                    <option value="Lead Data Scientist">Lead Data Scientist</option>
                    <option value="ML Engineer">ML Engineer</option>
                    <option value="Compliance Officer">Compliance Officer</option>
                    <option value="Data Scientist">Data Scientist</option>
                    <option value="Viewer">Viewer</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setIsInviteOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-bold text-xs"
                >
                  Send Workspace Invitation
                </button>
              </div>
            </form>
          )}

          {/* User Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="p-4">User</th>
                    <th className="p-4">Department</th>
                    <th className="p-4">Role</th>
                    <th className="p-4">Status</th>
                    <th className="p-4">Last Active</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {filteredUsers.map((u) => (
                    <tr key={u.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="p-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 rounded-full bg-indigo-600/30 text-indigo-300 font-bold flex items-center justify-center border border-indigo-500/40">
                            {u.name.charAt(0)}
                          </div>
                          <div>
                            <span className="text-white font-bold block">{u.name}</span>
                            <span className="text-[11px] text-slate-400">{u.email}</span>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 text-slate-300">{u.department}</td>
                      <td className="p-4">
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                          {u.role}
                        </span>
                      </td>
                      <td className="p-4">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            u.status === 'Active'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          }`}
                        >
                          {u.status}
                        </span>
                      </td>
                      <td className="p-4 text-slate-400">{u.lastActive}</td>
                      <td className="p-4 text-right">
                        <button
                          onClick={() => setUsers((prev) => prev.filter((item) => item.id !== u.id))}
                          className="p-1 rounded hover:bg-slate-800 text-slate-500 hover:text-rose-400 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: RBAC PERMISSIONS MATRIX */}
      {activeTab === 'rbac' && (
        <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-4">
          <div>
            <h3 className="text-xs font-bold text-white uppercase font-mono flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Role-Based Access Control (RBAC) Fine-Grained Permissions
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Configure read, write, deploy, and execute permissions across workspace resources for each team persona.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                <tr>
                  <th className="p-3">Resource Type</th>
                  <th className="p-3 text-center">MLOps Admin</th>
                  <th className="p-3 text-center">Lead Data Scientist</th>
                  <th className="p-3 text-center">ML Engineer</th>
                  <th className="p-3 text-center">Compliance Officer</th>
                  <th className="p-3 text-center">Viewer</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {[
                  { resource: 'Datasets & DVC Catalogs', admin: 'FULL', lead: 'READ / WRITE', mle: 'READ / WRITE', auditor: 'READ ONLY', viewer: 'READ ONLY' },
                  { resource: 'Model Training & MLflow Runs', admin: 'FULL', lead: 'FULL', mle: 'FULL', auditor: 'READ ONLY', viewer: 'READ ONLY' },
                  { resource: 'Model Registry (Promote to Champion)', admin: 'FULL', lead: 'FULL', mle: 'READ / STAGE', auditor: 'READ ONLY', viewer: 'READ ONLY' },
                  { resource: 'Production Deployments & K8s HPA', admin: 'FULL', lead: 'STAGE ONLY', mle: 'FULL', auditor: 'READ ONLY', viewer: 'NONE' },
                  { resource: 'Evidently AI & Alerting Config', admin: 'FULL', lead: 'READ ONLY', mle: 'FULL', auditor: 'READ ONLY', viewer: 'NONE' },
                  { resource: 'System Audit Security Logs', admin: 'FULL', lead: 'READ ONLY', mle: 'READ ONLY', auditor: 'FULL AUDIT', viewer: 'NONE' },
                ].map((row) => (
                  <tr key={row.resource} className="hover:bg-slate-800/40 transition-colors">
                    <td className="p-3 text-white font-bold">{row.resource}</td>
                    <td className="p-3 text-center text-emerald-400 font-bold">{row.admin}</td>
                    <td className="p-3 text-center text-indigo-300 font-semibold">{row.lead}</td>
                    <td className="p-3 text-center text-indigo-300 font-semibold">{row.mle}</td>
                    <td className="p-3 text-center text-cyan-300">{row.auditor}</td>
                    <td className="p-3 text-center text-slate-500">{row.viewer}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: API KEYS & ACCESS TOKENS */}
      {activeTab === 'tokens' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center bg-slate-900 p-5 rounded-2xl border border-slate-800">
            <div>
              <h3 className="text-xs font-bold text-white uppercase font-mono flex items-center gap-2">
                <Key className="w-4 h-4 text-amber-400" />
                Personal Access Tokens (PAT) & Service Account API Keys
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Generate scoped tokens for CI/CD runners, Kubeflow DAGs, and automated model deployment scripts.
              </p>
            </div>

            <button
              onClick={handleCreateToken}
              className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs flex items-center space-x-1.5 shadow"
            >
              <Plus className="w-4 h-4" />
              <span>Generate New PAT Token</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {apiTokens.map((tok) => (
              <div key={tok.id} className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-3 font-mono text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-white font-bold">{tok.name}</span>
                  <button
                    onClick={() => handleCopy(tok.tokenPrefix, tok.id)}
                    className="text-slate-400 hover:text-white flex items-center gap-1 text-[11px]"
                  >
                    {copiedTokenId === tok.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedTokenId === tok.id ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-amber-300 font-bold">
                  {tok.tokenPrefix}
                </div>

                <div className="flex flex-wrap gap-1 pt-1">
                  {tok.scope.map((s) => (
                    <span key={s} className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 text-[10px]">
                      {s}
                    </span>
                  ))}
                </div>

                <div className="flex justify-between text-[10px] text-slate-500 pt-2 border-t border-slate-800">
                  <span>Created: {tok.createdAt}</span>
                  <span>Expires: {tok.expiresAt}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: SSO & ENTERPRISE OAUTH */}
      {activeTab === 'sso' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { id: 'okta', name: 'Okta Enterprise SSO', status: 'CONNECTED', desc: 'SAML 2.0 / OIDC user provisioning active for enterprise.ai domain.', icon: Shield },
            { id: 'azure', name: 'Microsoft Azure AD (Entra)', status: 'CONFIGURED', desc: 'Active Directory group policy syncing enabled for MLOps roles.', icon: Lock },
            { id: 'google', name: 'Google Workspace OAuth 2.0', status: 'ACTIVE', desc: 'OAuth 2.0 authentication enabled for @gmail.com and workspace users.', icon: Globe },
          ].map((sso) => (
            <div key={sso.id} className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <sso.icon className="w-5 h-5 text-indigo-400" />
                  <h4 className="text-xs font-bold text-white font-mono">{sso.name}</h4>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {sso.status}
                </span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed font-mono">{sso.desc}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
