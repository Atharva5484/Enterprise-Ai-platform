import React, { useState } from 'react';
import {
  Sparkles,
  FileText,
  Upload,
  CheckCircle2,
  AlertTriangle,
  Play,
  RefreshCw,
  Search,
  Plus,
  Trash2,
  Layers,
  FileCode,
  Sliders,
  ChevronRight,
  HelpCircle,
  Copy,
  Check,
  BarChart3,
  CheckSquare,
  XCircle,
  ArrowRightLeft,
  Activity,
  Cpu,
  Database,
  Gauge,
  Info,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from 'recharts';
import {
  RagasTestCase,
  RagasEvaluationMetric,
  RagasRetrievedChunk,
} from '../../types/langgraph';
import { useRagevaluation } from '../../hooks/useRagevaluation';

interface RagasEvalModuleProps {
  onOpenCopilotWithContext?: (prompt: string) => void;
}

export interface ModelRetrievalConfig {
  id: string;
  name: string;
  modelName: string;
  retrievalStrategy: string;
  topK: number;
  metrics: {
    faithfulness: number;
    answerRelevance: number;
    contextPrecision: number;
    contextRecall: number;
    overallRagasScore: number;
  };
  latencyMs: number;
  costPer1kDocUSD: number;
}

export const PRESET_CONFIGURATIONS: ModelRetrievalConfig[] = [
  {
    id: 'config-gemini-pro-qdrant',
    name: 'Gemini 1.5 Pro + Qdrant Dense Vector (k=3)',
    modelName: 'Gemini 1.5 Pro',
    retrievalStrategy: 'Dense Vector (Cosine Similarity)',
    topK: 3,
    metrics: {
      faithfulness: 0.99,
      answerRelevance: 0.98,
      contextPrecision: 0.95,
      contextRecall: 0.96,
      overallRagasScore: 0.97,
    },
    latencyMs: 620,
    costPer1kDocUSD: 0.015,
  },
  {
    id: 'config-gemini-flash-hybrid',
    name: 'Gemini 1.5 Flash + Hybrid BM25/Vector (k=5)',
    modelName: 'Gemini 1.5 Flash',
    retrievalStrategy: 'Hybrid Reciprocal Rank Fusion (BM25 + Vector)',
    topK: 5,
    metrics: {
      faithfulness: 0.96,
      answerRelevance: 0.94,
      contextPrecision: 0.88,
      contextRecall: 0.92,
      overallRagasScore: 0.925,
    },
    latencyMs: 240,
    costPer1kDocUSD: 0.002,
  },
  {
    id: 'config-claude-rrf',
    name: 'Claude 3.5 Sonnet + RRF Reranker (k=8)',
    modelName: 'Claude 3.5 Sonnet',
    retrievalStrategy: 'Cross-Encoder Cohere Rerank',
    topK: 8,
    metrics: {
      faithfulness: 0.97,
      answerRelevance: 0.96,
      contextPrecision: 0.92,
      contextRecall: 0.94,
      overallRagasScore: 0.948,
    },
    latencyMs: 780,
    costPer1kDocUSD: 0.024,
  },
  {
    id: 'config-llama3-basic',
    name: 'Llama 3 70B + Basic Vector Search (k=2)',
    modelName: 'Llama-3-70B-Instruct',
    retrievalStrategy: 'Basic Vector Search (k=2)',
    topK: 2,
    metrics: {
      faithfulness: 0.88,
      answerRelevance: 0.85,
      contextPrecision: 0.78,
      contextRecall: 0.82,
      overallRagasScore: 0.832,
    },
    latencyMs: 310,
    costPer1kDocUSD: 0.001,
  },
];

export const RagasEvalModule: React.FC<RagasEvalModuleProps> = ({
  onOpenCopilotWithContext,
}) => {
  const {
    testCases,
    selectedTestCaseId,
    activeTestCase,
    userQuery,
    setUserQuery,
    generatedAnswer,
    setGeneratedAnswer,
    groundTruth,
    setGroundTruth,
    documentName,
    setDocumentName,
    contextChunks,
    isEvaluating,
    evalResult,
    uploadedFileName,
    handleSelectTestCase,
    handleAddChunk,
    handleRemoveChunk,
    handleUpdateChunkText,
    handleFileUpload,
    handleRunRagasEval,
    generateSyntheticTestSet,
  } = useRagevaluation();

  // Tab State: 'workbench' vs 'comparison'
  const [activeTab, setActiveTab] = useState<'workbench' | 'comparison'>('workbench');

  // Comparison State
  const [configAId, setConfigAId] = useState<string>(PRESET_CONFIGURATIONS[0].id);
  const [configBId, setConfigBId] = useState<string>(PRESET_CONFIGURATIONS[1].id);

  const configA = PRESET_CONFIGURATIONS.find((c) => c.id === configAId) || PRESET_CONFIGURATIONS[0];
  const configB = PRESET_CONFIGURATIONS.find((c) => c.id === configBId) || PRESET_CONFIGURATIONS[1];

  // Radar Data transformation
  const radarData = [
    {
      metric: 'Faithfulness',
      [configA.name]: Math.round(configA.metrics.faithfulness * 100),
      [configB.name]: Math.round(configB.metrics.faithfulness * 100),
      fullMark: 100,
    },
    {
      metric: 'Answer Relevance',
      [configA.name]: Math.round(configA.metrics.answerRelevance * 100),
      [configB.name]: Math.round(configB.metrics.answerRelevance * 100),
      fullMark: 100,
    },
    {
      metric: 'Context Precision',
      [configA.name]: Math.round(configA.metrics.contextPrecision * 100),
      [configB.name]: Math.round(configB.metrics.contextPrecision * 100),
      fullMark: 100,
    },
    {
      metric: 'Context Recall',
      [configA.name]: Math.round(configA.metrics.contextRecall * 100),
      [configB.name]: Math.round(configB.metrics.contextRecall * 100),
      fullMark: 100,
    },
    {
      metric: 'Overall RAGAS',
      [configA.name]: Math.round(configA.metrics.overallRagasScore * 100),
      [configB.name]: Math.round(configB.metrics.overallRagasScore * 100),
      fullMark: 100,
    },
  ];

  // Bar Chart Data for Historical Test Case Stability
  const trendBarData = testCases.map((tc) => ({
    name: tc.documentName.length > 20 ? `${tc.documentName.slice(0, 18)}...` : tc.documentName,
    Faithfulness: Math.round((tc.metrics?.faithfulness || 0) * 100),
    'Answer Relevance': Math.round((tc.metrics?.answerRelevance || 0) * 100),
    'Context Precision': Math.round((tc.metrics?.contextPrecision || 0) * 100),
    'Overall Score': Math.round((tc.metrics?.overallRagasScore || 0) * 100),
  }));

  return (
    <div className="space-y-6 text-slate-100">
      {/* Top Banner Header with View Tabs */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 p-5 rounded-2xl border border-slate-800">
        <div>
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-400" />
            RAGAS Framework Automated RAG Evaluation Engine
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Compute <strong>Faithfulness</strong>, <strong>Answer Relevance</strong>, and <strong>Context Precision</strong> metrics for uploaded document queries and vector knowledge bases.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Tab Switcher */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 font-mono text-xs">
            <button
              onClick={() => setActiveTab('workbench')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-colors flex items-center space-x-1.5 ${
                activeTab === 'workbench'
                  ? 'bg-purple-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Evaluation Workbench</span>
            </button>
            <button
              onClick={() => setActiveTab('comparison')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-colors flex items-center space-x-1.5 ${
                activeTab === 'comparison'
                  ? 'bg-purple-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ArrowRightLeft className="w-3.5 h-3.5" />
              <span>Model & Config Radar</span>
            </button>
          </div>

          <button
            onClick={generateSyntheticTestSet}
            className="px-3.5 py-2 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 font-semibold text-xs flex items-center space-x-1.5 transition-colors"
            title="Generate Synthetic Test Case using RAGAS LLM pipeline"
          >
            <Plus className="w-3.5 h-3.5 text-indigo-400" />
            <span>Generate Test Case</span>
          </button>

          {onOpenCopilotWithContext && (
            <button
              onClick={() =>
                onOpenCopilotWithContext(
                  `Explain how RAGAS Faithfulness, Answer Relevance, and Context Precision metrics are mathematically derived and suggest ways to increase Context Precision.`
                )
              }
              className="px-3.5 py-2 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30 font-semibold text-xs flex items-center space-x-1.5 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
              <span>RAGAS Metric Guide</span>
            </button>
          )}
        </div>
      </div>

      {/* VIEW 1: EVALUATION WORKBENCH */}
      {activeTab === 'workbench' && (
        <>
          {/* Main Split Layout: Document / Test Case Inputs (7 Cols) vs RAGAS Results Dashboard (5 Cols) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Left Column: Document Upload & Ad-Hoc Test Workbench (7 Cols) */}
            <div className="lg:col-span-7 bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <span className="text-[10px] font-mono text-purple-400 uppercase font-bold">RAG Workbench</span>
                  <h3 className="text-xs font-bold text-white">Document & Retrieval Test Case Input</h3>
                </div>

                {/* Document File Uploader Button */}
                <label className="px-3 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-xs font-mono text-indigo-300 flex items-center space-x-1.5 cursor-pointer transition-colors">
                  <Upload className="w-3.5 h-3.5 text-indigo-400" />
                  <span>{uploadedFileName ? `Doc: ${uploadedFileName}` : 'Upload Document (.pdf/.txt)'}</span>
                  <input type="file" onChange={handleFileUpload} className="hidden" accept=".pdf,.txt,.json,.csv,.docx" />
                </label>
              </div>

              <div className="space-y-4 text-xs">
                <div>
                  <label className="text-[11px] font-mono text-slate-400 uppercase font-bold">User Query / Prompt</label>
                  <textarea
                    value={userQuery}
                    onChange={(e) => setUserQuery(e.target.value)}
                    rows={2}
                    className="w-full bg-slate-950 p-3 rounded-xl border border-slate-800 text-white font-medium focus:outline-none focus:border-purple-500 mt-1"
                    placeholder="Enter user query..."
                  />
                </div>

                {/* Context Chunks List */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-[11px] font-mono text-slate-400 uppercase font-bold flex items-center gap-1.5">
                      <Layers className="w-3.5 h-3.5 text-purple-400" />
                      Retrieved Context Chunks ({contextChunks.length})
                    </label>
                    <button
                      onClick={handleAddChunk}
                      className="text-[11px] text-purple-400 hover:text-purple-300 font-bold flex items-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Chunk</span>
                    </button>
                  </div>

                  <div className="space-y-2.5 max-h-[220px] overflow-y-auto pr-1">
                    {contextChunks.map((chunk, idx) => (
                      <div key={chunk.id} className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5">
                        <div className="flex items-center justify-between text-[10px] font-mono">
                          <span className="text-purple-400 font-bold">
                            Chunk #{idx + 1} ({chunk.documentTitle})
                          </span>
                          <div className="flex items-center space-x-2">
                            <span className="text-slate-400">Similarity: {(chunk.relevanceScore || 0.9).toFixed(2)}</span>
                            {contextChunks.length > 1 && (
                              <button
                                onClick={() => handleRemoveChunk(chunk.id)}
                                className="text-slate-500 hover:text-red-400"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </div>
                        <textarea
                          value={chunk.content}
                          onChange={(e) => handleUpdateChunkText(chunk.id, e.target.value)}
                          rows={2}
                          className="w-full bg-slate-900/80 p-2 rounded-lg border border-slate-800 font-mono text-[11px] text-slate-300 focus:outline-none focus:border-purple-500"
                        />
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-mono text-slate-400 uppercase font-bold">Generated Candidate Answer</label>
                  <textarea
                    value={generatedAnswer}
                    onChange={(e) => setGeneratedAnswer(e.target.value)}
                    rows={3}
                    className="w-full bg-slate-950 p-3 rounded-xl border border-slate-800 text-purple-200 font-mono focus:outline-none focus:border-purple-500 mt-1 leading-relaxed"
                    placeholder="Enter model generated response..."
                  />
                </div>

                {/* Trigger Button */}
                <button
                  onClick={handleRunRagasEval}
                  disabled={isEvaluating}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center space-x-2 shadow-lg shadow-purple-600/20 transition-all disabled:opacity-50"
                >
                  {isEvaluating ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Play className="w-4 h-4 fill-current" />
                  )}
                  <span>{isEvaluating ? 'Computing RAGAS Metrics with Gemini...' : 'Compute RAGAS Evaluation Metrics'}</span>
                </button>
              </div>
            </div>

            {/* Right Column: RAGAS Evaluation Results Scorecard (5 Cols) */}
            <div className="lg:col-span-5 space-y-4">
              {evalResult?.metrics ? (
                <div className="bg-slate-900 p-5 rounded-2xl border border-purple-500/40 space-y-4 shadow-xl">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div>
                      <span className="text-[10px] font-mono text-purple-400 uppercase font-bold">RAGAS Benchmark Report</span>
                      <h3 className="text-xs font-bold text-white">{evalResult.documentName}</h3>
                    </div>

                    <div className="text-right">
                      <span className="text-[9px] text-slate-500 uppercase font-bold block">Overall RAGAS Score</span>
                      <span className="text-lg font-extrabold text-emerald-400 font-mono">
                        {(evalResult.metrics.overallRagasScore * 100).toFixed(1)}%
                      </span>
                    </div>
                  </div>

                  {/* 3 Core RAGAS Metrics Gauge Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 font-mono">
                    {/* 1. Faithfulness */}
                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center space-y-1">
                      <span className="text-[10px] text-slate-400 font-bold block uppercase">Faithfulness</span>
                      <div className="text-xl font-extrabold text-emerald-400">
                        {(evalResult.metrics.faithfulness * 100).toFixed(0)}%
                      </div>
                      <p className="text-[9px] text-slate-500">Grounded in context</p>
                    </div>

                    {/* 2. Answer Relevance */}
                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center space-y-1">
                      <span className="text-[10px] text-slate-400 font-bold block uppercase">Answer Relevance</span>
                      <div className="text-xl font-extrabold text-purple-300">
                        {(evalResult.metrics.answerRelevance * 100).toFixed(0)}%
                      </div>
                      <p className="text-[9px] text-slate-500">Query directness</p>
                    </div>

                    {/* 3. Context Precision */}
                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center space-y-1">
                      <span className="text-[10px] text-slate-400 font-bold block uppercase">Context Precision</span>
                      <div className="text-xl font-extrabold text-cyan-300">
                        {(evalResult.metrics.contextPrecision * 100).toFixed(0)}%
                      </div>
                      <p className="text-[9px] text-slate-500">Signal vs noise</p>
                    </div>
                  </div>

                  {/* Statement Claims Verification Breakdown */}
                  {evalResult.reasoning && (
                    <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white">Extracted Statement Verification</span>
                        <span className="text-[10px] font-mono text-emerald-400 font-bold">
                          {evalResult.reasoning.supportedStatementsCount} / {evalResult.reasoning.totalStatementsCount} Supported
                        </span>
                      </div>

                      <div className="space-y-1.5 font-mono text-[11px]">
                        {evalResult.reasoning.extractedStatements.map((stmt, idx) => (
                          <div key={idx} className="flex items-start space-x-2 text-slate-300 bg-slate-900/60 p-2 rounded">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                            <span>{stmt}</span>
                          </div>
                        ))}
                      </div>

                      <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 leading-relaxed">
                        <strong className="text-slate-200">RAGAS Diagnostic Reasoning:</strong>
                        <p className="mt-1">{evalResult.reasoning.faithfulnessReasoning}</p>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="bg-slate-900 p-8 rounded-2xl border border-slate-800 text-center space-y-2">
                  <Sparkles className="w-8 h-8 text-purple-400 mx-auto" />
                  <h4 className="text-xs font-bold text-white">No RAGAS Evaluation Generated Yet</h4>
                  <p className="text-xs text-slate-400">Click "Compute RAGAS Evaluation Metrics" to analyze candidate responses.</p>
                </div>
              )}
            </div>
          </div>

          {/* Metric Stability Bar Chart Across Historical Suite */}
          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-mono text-purple-400 uppercase font-bold">Visual Performance Stability</span>
                <h3 className="text-sm font-bold text-white">RAGAS Metrics Across Test Suite Runs</h3>
              </div>
              <span className="text-xs font-mono text-slate-400">Metric Stability Index: <strong className="text-emerald-400">94.8%</strong></span>
            </div>

            <div className="h-64 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={trendBarData} margin={{ top: 10, right: 20, left: -20, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="name" stroke="#64748b" tick={{ fill: '#94a3b8', fontSize: 11 }} />
                  <YAxis domain={[0, 100]} stroke="#64748b" tick={{ fill: '#94a3b8', fontSize: 11 }} unit="%" />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', color: '#f8fafc', fontSize: '12px' }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                  <Bar dataKey="Faithfulness" fill="#10b981" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="Answer Relevance" fill="#a855f7" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="Context Precision" fill="#06b6d4" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="Overall Score" fill="#6366f1" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Batch Benchmark Test Cases Dataset Table */}
          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-mono text-purple-400 uppercase font-bold">Historical Benchmark Suite</span>
                <h3 className="text-sm font-bold text-white">RAGAS Evaluated Document Test Cases</h3>
              </div>

              <span className="text-xs font-mono text-slate-400">
                Total Samples: <strong className="text-white">{testCases.length}</strong>
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-[11px] font-mono text-slate-400 uppercase">
                    <th className="py-2.5 px-3">Document Source</th>
                    <th className="py-2.5 px-3">User Query</th>
                    <th className="py-2.5 px-3">Faithfulness</th>
                    <th className="py-2.5 px-3">Answer Relevance</th>
                    <th className="py-2.5 px-3">Context Precision</th>
                    <th className="py-2.5 px-3">Overall Score</th>
                    <th className="py-2.5 px-3 text-right">Evaluated At</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {testCases.map((tc) => {
                    const isSelected = selectedTestCaseId === tc.id;
                    return (
                      <tr
                        key={tc.id}
                        onClick={() => handleSelectTestCase(tc)}
                        className={`cursor-pointer transition-colors ${
                          isSelected ? 'bg-purple-950/30 font-semibold' : 'hover:bg-slate-800/40'
                        }`}
                      >
                        <td className="py-3 px-3 font-sans font-medium text-white max-w-[180px] truncate">
                          {tc.documentName}
                        </td>
                        <td className="py-3 px-3 text-slate-300 max-w-[280px] truncate">{tc.userQuery}</td>
                        <td className="py-3 px-3 text-emerald-400 font-extrabold">
                          {tc.metrics ? `${(tc.metrics.faithfulness * 100).toFixed(0)}%` : 'N/A'}
                        </td>
                        <td className="py-3 px-3 text-purple-300 font-extrabold">
                          {tc.metrics ? `${(tc.metrics.answerRelevance * 100).toFixed(0)}%` : 'N/A'}
                        </td>
                        <td className="py-3 px-3 text-cyan-300 font-extrabold">
                          {tc.metrics ? `${(tc.metrics.contextPrecision * 100).toFixed(0)}%` : 'N/A'}
                        </td>
                        <td className="py-3 px-3">
                          <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                            {tc.metrics ? `${(tc.metrics.overallRagasScore * 100).toFixed(1)}%` : 'Pending'}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-right text-slate-400">{tc.evaluatedAt || 'Just now'}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {/* VIEW 2: MODEL & CONFIG RADAR COMPARISON VIEW */}
      {activeTab === 'comparison' && (
        <div className="space-y-6">
          {/* Config Selectors Header */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-900 p-5 rounded-2xl border border-slate-800">
            {/* Config A Selector */}
            <div className="space-y-2">
              <label className="text-[11px] font-mono text-cyan-400 uppercase font-bold flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5" />
                Configuration A (Baseline)
              </label>
              <select
                value={configAId}
                onChange={(e) => setConfigAId(e.target.value)}
                className="w-full bg-slate-950 p-2.5 rounded-xl border border-cyan-500/40 text-white font-medium text-xs focus:outline-none focus:border-cyan-400"
              >
                {PRESET_CONFIGURATIONS.map((cfg) => (
                  <option key={cfg.id} value={cfg.id}>
                    {cfg.name}
                  </option>
                ))}
              </select>
              <div className="flex items-center space-x-3 text-[11px] font-mono text-slate-400 pt-1">
                <span>Model: <strong className="text-slate-200">{configA.modelName}</strong></span>
                <span>Top-K: <strong className="text-slate-200">{configA.topK}</strong></span>
                <span>Latency: <strong className="text-slate-200">{configA.latencyMs}ms</strong></span>
              </div>
            </div>

            {/* Config B Selector */}
            <div className="space-y-2">
              <label className="text-[11px] font-mono text-purple-400 uppercase font-bold flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5" />
                Configuration B (Candidate)
              </label>
              <select
                value={configBId}
                onChange={(e) => setConfigBId(e.target.value)}
                className="w-full bg-slate-950 p-2.5 rounded-xl border border-purple-500/40 text-white font-medium text-xs focus:outline-none focus:border-purple-400"
              >
                {PRESET_CONFIGURATIONS.map((cfg) => (
                  <option key={cfg.id} value={cfg.id}>
                    {cfg.name}
                  </option>
                ))}
              </select>
              <div className="flex items-center space-x-3 text-[11px] font-mono text-slate-400 pt-1">
                <span>Model: <strong className="text-slate-200">{configB.modelName}</strong></span>
                <span>Top-K: <strong className="text-slate-200">{configB.topK}</strong></span>
                <span>Latency: <strong className="text-slate-200">{configB.latencyMs}ms</strong></span>
              </div>
            </div>
          </div>

          {/* Radar Chart Visualizer & Side-by-Side Scorecard */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Left: Recharts Radar Chart (7 Cols) */}
            <div className="lg:col-span-7 bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <span className="text-[10px] font-mono text-purple-400 uppercase font-bold">Multi-Metric Radar Visualizer</span>
                  <h3 className="text-sm font-bold text-white">RAGAS Quality Footprint Comparison</h3>
                </div>
                <span className="text-xs font-mono text-slate-400">Scale: 0 - 100%</span>
              </div>

              <div className="h-80 w-full pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart cx="50%" cy="50%" outerRadius="75%" data={radarData}>
                    <PolarGrid stroke="#334155" />
                    <PolarAngleAxis dataKey="metric" stroke="#94a3b8" tick={{ fill: '#e2e8f0', fontSize: 11 }} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} stroke="#475569" tick={{ fill: '#64748b', fontSize: 10 }} />
                    <Radar
                      name={configA.name}
                      dataKey={configA.name}
                      stroke="#06b6d4"
                      fill="#06b6d4"
                      fillOpacity={0.35}
                    />
                    <Radar
                      name={configB.name}
                      dataKey={configB.name}
                      stroke="#c084fc"
                      fill="#c084fc"
                      fillOpacity={0.35}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0f172a',
                        borderColor: '#334155',
                        borderRadius: '0.75rem',
                        color: '#f8fafc',
                        fontSize: '12px',
                      }}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Right: Detailed Metric Delta Side-by-Side Breakdown (5 Cols) */}
            <div className="lg:col-span-5 bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
              <div className="border-b border-slate-800 pb-3">
                <span className="text-[10px] font-mono text-emerald-400 uppercase font-bold">Delta Diagnostic</span>
                <h3 className="text-sm font-bold text-white">Metrics Delta Scorecard</h3>
              </div>

              <div className="space-y-3 font-mono text-xs">
                {/* Metric 1: Faithfulness */}
                {(() => {
                  const diff = Math.round((configB.metrics.faithfulness - configA.metrics.faithfulness) * 100);
                  return (
                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase font-bold block">Faithfulness</span>
                        <div className="flex items-center space-x-2 mt-0.5 text-xs font-bold">
                          <span className="text-cyan-400">{(configA.metrics.faithfulness * 100).toFixed(0)}%</span>
                          <span className="text-slate-500">vs</span>
                          <span className="text-purple-300">{(configB.metrics.faithfulness * 100).toFixed(0)}%</span>
                        </div>
                      </div>
                      <span
                        className={`px-2 py-1 rounded text-xs font-bold ${
                          diff >= 0 ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-red-500/20 text-red-300 border border-red-500/30'
                        }`}
                      >
                        {diff >= 0 ? `+${diff}%` : `${diff}%`}
                      </span>
                    </div>
                  );
                })()}

                {/* Metric 2: Answer Relevance */}
                {(() => {
                  const diff = Math.round((configB.metrics.answerRelevance - configA.metrics.answerRelevance) * 100);
                  return (
                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase font-bold block">Answer Relevance</span>
                        <div className="flex items-center space-x-2 mt-0.5 text-xs font-bold">
                          <span className="text-cyan-400">{(configA.metrics.answerRelevance * 100).toFixed(0)}%</span>
                          <span className="text-slate-500">vs</span>
                          <span className="text-purple-300">{(configB.metrics.answerRelevance * 100).toFixed(0)}%</span>
                        </div>
                      </div>
                      <span
                        className={`px-2 py-1 rounded text-xs font-bold ${
                          diff >= 0 ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-red-500/20 text-red-300 border border-red-500/30'
                        }`}
                      >
                        {diff >= 0 ? `+${diff}%` : `${diff}%`}
                      </span>
                    </div>
                  );
                })()}

                {/* Metric 3: Context Precision */}
                {(() => {
                  const diff = Math.round((configB.metrics.contextPrecision - configA.metrics.contextPrecision) * 100);
                  return (
                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase font-bold block">Context Precision</span>
                        <div className="flex items-center space-x-2 mt-0.5 text-xs font-bold">
                          <span className="text-cyan-400">{(configA.metrics.contextPrecision * 100).toFixed(0)}%</span>
                          <span className="text-slate-500">vs</span>
                          <span className="text-purple-300">{(configB.metrics.contextPrecision * 100).toFixed(0)}%</span>
                        </div>
                      </div>
                      <span
                        className={`px-2 py-1 rounded text-xs font-bold ${
                          diff >= 0 ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-red-500/20 text-red-300 border border-red-500/30'
                        }`}
                      >
                        {diff >= 0 ? `+${diff}%` : `${diff}%`}
                      </span>
                    </div>
                  );
                })()}

                {/* Metric 4: Context Recall */}
                {(() => {
                  const diff = Math.round((configB.metrics.contextRecall - configA.metrics.contextRecall) * 100);
                  return (
                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase font-bold block">Context Recall</span>
                        <div className="flex items-center space-x-2 mt-0.5 text-xs font-bold">
                          <span className="text-cyan-400">{(configA.metrics.contextRecall * 100).toFixed(0)}%</span>
                          <span className="text-slate-500">vs</span>
                          <span className="text-purple-300">{(configB.metrics.contextRecall * 100).toFixed(0)}%</span>
                        </div>
                      </div>
                      <span
                        className={`px-2 py-1 rounded text-xs font-bold ${
                          diff >= 0 ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-red-500/20 text-red-300 border border-red-500/30'
                        }`}
                      >
                        {diff >= 0 ? `+${diff}%` : `${diff}%`}
                      </span>
                    </div>
                  );
                })()}

                {/* Overall Comparison Banner */}
                <div className="p-3 bg-purple-950/30 rounded-xl border border-purple-500/30 text-xs space-y-1 font-sans">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    <Info className="w-3.5 h-3.5 text-purple-400" />
                    Comparative Recommendation
                  </span>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    {configB.metrics.overallRagasScore >= configA.metrics.overallRagasScore ? (
                      <>
                        <strong className="text-purple-300">{configB.name}</strong> achieves a higher overall RAGAS benchmark score ({(configB.metrics.overallRagasScore * 100).toFixed(1)}% vs {(configA.metrics.overallRagasScore * 100).toFixed(1)}%).
                      </>
                    ) : (
                      <>
                        <strong className="text-cyan-300">{configA.name}</strong> remains the superior configuration for accuracy and signal-to-noise ratio.
                      </>
                    )}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
