import React, { useState } from 'react';
import {
  DollarSign,
  TrendingUp,
  Cpu,
  Layers,
  Sparkles,
  Filter,
  BarChart3,
  PieChart as PieChartIcon,
  Zap,
  CheckCircle2,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  Calculator,
  BellRing,
  RefreshCw,
  Search,
  Building,
  HardDrive,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import {
  ProjectCostItem,
  CostDailyTrend,
  CostOptimizationInsight,
  CostProvider,
} from '../../types/langgraph';
import {
  INITIAL_COST_PROJECT_ITEMS,
  INITIAL_COST_DAILY_TRENDS,
  INITIAL_COST_OPTIMIZATIONS,
} from '../../data/mockLangGraphData';

interface CostAnalyticsDashboardProps {
  onOpenCopilotWithContext?: (prompt: string) => void;
}

export const CostAnalyticsDashboard: React.FC<CostAnalyticsDashboardProps> = ({
  onOpenCopilotWithContext,
}) => {
  const [costItems, setCostItems] = useState<ProjectCostItem[]>(INITIAL_COST_PROJECT_ITEMS);
  const [dailyTrends] = useState<CostDailyTrend[]>(INITIAL_COST_DAILY_TRENDS);
  const [optimizations] = useState<CostOptimizationInsight[]>(INITIAL_COST_OPTIMIZATIONS);

  // Filters
  const [timeframe, setTimeframe] = useState<'24h' | '7d' | '30d' | 'ytd'>('7d');
  const [selectedProvider, setSelectedProvider] = useState<string>('ALL');
  const [searchProject, setSearchProject] = useState<string>('');

  // Budget Configurator State
  const [monthlyBudgetLimit, setMonthlyBudgetLimit] = useState<number>(500);
  const [alertThresholdPercent, setAlertThresholdPercent] = useState<number>(80);
  const [isAlertSaved, setIsAlertSaved] = useState<boolean>(false);

  // Interactive Calculator State
  const [calcInputTokens, setCalcInputTokens] = useState<number>(1000000);
  const [calcOutputTokens, setCalcOutputTokens] = useState<number>(250000);

  // Filtered Items
  const filteredCostItems = costItems.filter((item) => {
    const matchesProvider = selectedProvider === 'ALL' || item.provider === selectedProvider;
    const matchesSearch =
      item.project.toLowerCase().includes(searchProject.toLowerCase()) ||
      item.model.toLowerCase().includes(searchProject.toLowerCase());
    return matchesProvider && matchesSearch;
  });

  // Calculate Aggregates
  const totalCostUSD = filteredCostItems.reduce((acc, i) => acc + i.estimatedCostUSD, 0);
  const totalTokens = filteredCostItems.reduce((acc, i) => acc + i.totalTokens, 0);
  const totalRequests = filteredCostItems.reduce((acc, i) => acc + i.requestCount, 0);
  const budgetUtilizationPercent = Math.min(100, Math.round((totalCostUSD / monthlyBudgetLimit) * 100));

  // Pie chart data by Project
  const pieChartData = filteredCostItems.map((item) => ({
    name: item.project,
    value: Number(item.estimatedCostUSD.toFixed(2)),
  }));

  const PIE_COLORS = ['#6366f1', '#a855f7', '#ec4899', '#06b6d4', '#10b981', '#f59e0b'];

  const handleSaveBudgetAlert = () => {
    setIsAlertSaved(true);
    setTimeout(() => setIsAlertSaved(false), 2500);
  };

  // Calculator Estimates
  const calcGeminiCost = (calcInputTokens / 1000000) * 0.075 + (calcOutputTokens / 1000000) * 0.30;
  const calcOpenAICost = (calcInputTokens / 1000000) * 2.50 + (calcOutputTokens / 1000000) * 10.00;
  const calcAnthropicCost = (calcInputTokens / 1000000) * 3.00 + (calcOutputTokens / 1000000) * 15.00;

  return (
    <div className="space-y-6 text-slate-100">
      {/* Top Controls & Filter Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 p-4 rounded-2xl border border-slate-800">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 bg-purple-600/20 border border-purple-500/40 rounded-xl text-purple-400">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              LLM Provider Cost & Token Usage Analytics
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Token usage tracking, estimated billing breakdown by project & model, and Gemini AI cost optimization.
            </p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2.5 text-xs">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchProject}
              onChange={(e) => setSearchProject(e.target.value)}
              placeholder="Search project or model..."
              className="bg-slate-950 pl-8 pr-3 py-1.5 rounded-xl border border-slate-800 text-xs text-white focus:outline-none focus:border-purple-500 w-44"
            />
          </div>

          {/* Provider Filter */}
          <select
            value={selectedProvider}
            onChange={(e) => setSelectedProvider(e.target.value)}
            className="bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-slate-200 font-medium focus:outline-none focus:border-purple-500 cursor-pointer"
          >
            <option value="ALL">All LLM Providers</option>
            <option value="Google Gemini">Google Gemini</option>
            <option value="OpenAI">OpenAI</option>
            <option value="Anthropic">Anthropic</option>
            <option value="vLLM (Local)">vLLM (Local)</option>
          </select>

          {/* Timeframe Toggle */}
          <div className="flex items-center space-x-1 bg-slate-950 p-1 rounded-xl border border-slate-800 font-mono">
            {(['24h', '7d', '30d', 'ytd'] as const).map((tf) => (
              <button
                key={tf}
                onClick={() => setTimeframe(tf)}
                className={`px-2.5 py-1 rounded-lg font-bold uppercase text-[10px] transition-all ${
                  timeframe === tf ? 'bg-purple-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tf}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* KPI Stat Cards (4 Grid) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Estimated Billing ({timeframe.toUpperCase()})</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-extrabold text-white font-mono">${totalCostUSD.toFixed(2)}</span>
            <span className="text-[11px] font-mono text-emerald-400 flex items-center">
              <ArrowDownRight className="w-3.5 h-3.5" /> 3.2%
            </span>
          </div>
          <p className="text-[10px] text-slate-500 font-mono">Across {filteredCostItems.length} active project targets</p>
        </div>

        <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Total Tokens Processed</span>
            <Cpu className="w-4 h-4 text-purple-400" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-extrabold text-purple-300 font-mono">
              {(totalTokens / 1000000).toFixed(1)}M
            </span>
            <span className="text-[11px] font-mono text-purple-400 flex items-center">
              <ArrowUpRight className="w-3.5 h-3.5" /> 8.4%
            </span>
          </div>
          <p className="text-[10px] text-slate-500 font-mono">Prompt: In / Gen: Out ratio ~ 3.8:1</p>
        </div>

        <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>API Requests Served</span>
            <Zap className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-extrabold text-cyan-300 font-mono">
              {(totalRequests / 1000).toFixed(0)}k
            </span>
            <span className="text-[11px] font-mono text-cyan-400">Avg 320ms Latency</span>
          </div>
          <p className="text-[10px] text-slate-500 font-mono">0.00% API Rate Limit Drops</p>
        </div>

        <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Monthly Budget Utilization</span>
            <BellRing className="w-4 h-4 text-amber-400" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-extrabold text-amber-300 font-mono">
              {budgetUtilizationPercent}%
            </span>
            <span className="text-[11px] font-mono text-slate-400">Limit: ${monthlyBudgetLimit}</span>
          </div>
          <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden mt-1 border border-slate-800">
            <div
              className={`h-full transition-all ${
                budgetUtilizationPercent > alertThresholdPercent ? 'bg-amber-400' : 'bg-purple-500'
              }`}
              style={{ width: `${budgetUtilizationPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Visual Charts Row: Recharts Daily Cost Trend + Spend by Project Pie */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Daily Token & Cost Trend (8 Cols) */}
        <div className="lg:col-span-8 bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <span className="text-[10px] font-mono text-purple-400 uppercase font-bold">Daily Billing Breakdown</span>
              <h3 className="text-xs font-bold text-white">LLM Provider Cost Trend ($ USD)</h3>
            </div>
            <div className="flex items-center space-x-3 text-[11px] font-mono">
              <span className="text-indigo-400 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-indigo-500" /> Gemini
              </span>
              <span className="text-purple-400 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-purple-500" /> OpenAI
              </span>
              <span className="text-cyan-400 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-cyan-500" /> Anthropic
              </span>
            </div>
          </div>

          <div className="h-[260px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dailyTrends} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorGemini" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorOpenAI" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#a855f7" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#a855f7" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorAnthropic" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="date" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#020617', borderColor: '#334155', borderRadius: '12px' }}
                  labelStyle={{ color: '#f8fafc', fontWeight: 'bold' }}
                />
                <Area type="monotone" dataKey="geminiCost" name="Google Gemini" stroke="#6366f1" fillOpacity={1} fill="url(#colorGemini)" />
                <Area type="monotone" dataKey="openaiCost" name="OpenAI" stroke="#a855f7" fillOpacity={1} fill="url(#colorOpenAI)" />
                <Area type="monotone" dataKey="anthropicCost" name="Anthropic" stroke="#06b6d4" fillOpacity={1} fill="url(#colorAnthropic)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Cost Distribution by Project Pie Chart (4 Cols) */}
        <div className="lg:col-span-4 bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
          <div className="border-b border-slate-800 pb-3">
            <span className="text-[10px] font-mono text-purple-400 uppercase font-bold">Project Allocation</span>
            <h3 className="text-xs font-bold text-white">Cost Distribution by Project</h3>
          </div>

          <div className="h-[220px] w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieChartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={80}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {pieChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#020617', borderColor: '#334155', borderRadius: '12px' }}
                  formatter={(val: any) => [`$${val}`, 'Cost']}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
            {pieChartData.slice(0, 4).map((p, idx) => (
              <div key={p.name} className="flex items-center space-x-1.5 truncate">
                <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: PIE_COLORS[idx % PIE_COLORS.length] }} />
                <span className="text-slate-300 truncate">{p.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Breakdown Table by Project & Model */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <span className="text-[10px] font-mono text-purple-400 uppercase font-bold">Project & Model Cost Ledger</span>
            <h3 className="text-sm font-bold text-white">Granular Usage Breakdown</h3>
          </div>

          <span className="text-xs font-mono text-slate-400">
            Showing <strong className="text-white">{filteredCostItems.length}</strong> project deployments
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-[11px] font-mono text-slate-400 uppercase">
                <th className="py-2.5 px-3">Project Target</th>
                <th className="py-2.5 px-3">LLM Model</th>
                <th className="py-2.5 px-3">Provider</th>
                <th className="py-2.5 px-3">Token Usage (In / Out)</th>
                <th className="py-2.5 px-3">Requests</th>
                <th className="py-2.5 px-3">Avg Latency</th>
                <th className="py-2.5 px-3 text-right">Estimated Billing</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {filteredCostItems.map((item) => (
                <tr key={item.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-3 font-semibold text-white font-sans">{item.project}</td>
                  <td className="py-3 px-3 text-purple-300 font-bold">{item.model}</td>
                  <td className="py-3 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] border ${
                        item.provider === 'Google Gemini'
                          ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
                          : item.provider === 'OpenAI'
                          ? 'bg-purple-500/20 text-purple-300 border-purple-500/30'
                          : item.provider === 'Anthropic'
                          ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30'
                          : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                      }`}
                    >
                      {item.provider}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-slate-300">
                    {(item.inputTokens / 1000000).toFixed(1)}M / {(item.outputTokens / 1000000).toFixed(1)}M
                  </td>
                  <td className="py-3 px-3 text-slate-300">{item.requestCount.toLocaleString()}</td>
                  <td className="py-3 px-3 text-slate-400">{item.avgLatencyMs}ms</td>
                  <td className="py-3 px-3 text-right font-extrabold text-emerald-400">
                    ${item.estimatedCostUSD.toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Bottom Grid: Interactive Token Cost Calculator + Gemini AI Cost Optimization Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Token Simulator & Budget Alert Configurator (6 Cols) */}
        <div className="lg:col-span-6 bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Calculator className="w-4 h-4 text-purple-400" />
              Token Pricing Simulator & Budget Limits
            </h3>
            <span className="text-[10px] font-mono text-purple-400 font-bold">Real-time Rate Match</span>
          </div>

          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] font-mono text-slate-400 uppercase font-bold">Simulated Input Tokens</label>
                <input
                  type="number"
                  value={calcInputTokens}
                  onChange={(e) => setCalcInputTokens(parseInt(e.target.value) || 0)}
                  className="w-full bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 font-mono text-white focus:outline-none focus:border-purple-500 mt-1"
                />
              </div>

              <div>
                <label className="text-[10px] font-mono text-slate-400 uppercase font-bold">Simulated Output Tokens</label>
                <input
                  type="number"
                  value={calcOutputTokens}
                  onChange={(e) => setCalcOutputTokens(parseInt(e.target.value) || 0)}
                  className="w-full bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 font-mono text-white focus:outline-none focus:border-purple-500 mt-1"
                />
              </div>
            </div>

            {/* Price Comparison Cards */}
            <div className="grid grid-cols-3 gap-2 font-mono">
              <div className="bg-slate-950 p-3 rounded-xl border border-indigo-500/40 text-center">
                <span className="text-[10px] text-slate-400 font-bold block">Gemini 1.5 Flash</span>
                <span className="text-sm font-extrabold text-emerald-400 mt-1 block">${calcGeminiCost.toFixed(3)}</span>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 font-bold block">OpenAI GPT-4o</span>
                <span className="text-sm font-extrabold text-purple-300 mt-1 block">${calcOpenAICost.toFixed(3)}</span>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 font-bold block">Claude 3.5 Sonnet</span>
                <span className="text-sm font-extrabold text-cyan-300 mt-1 block">${calcAnthropicCost.toFixed(3)}</span>
              </div>
            </div>

            {/* Budget Alert Limits Input */}
            <div className="pt-3 border-t border-slate-800 space-y-3">
              <span className="text-[11px] font-mono text-slate-300 font-bold block">Monthly Alert Thresholds</span>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 font-bold">Monthly Budget Limit ($)</label>
                  <input
                    type="number"
                    value={monthlyBudgetLimit}
                    onChange={(e) => setMonthlyBudgetLimit(parseFloat(e.target.value) || 100)}
                    className="w-full bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-white font-mono mt-1"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 font-bold">Alert Threshold (%)</label>
                  <input
                    type="number"
                    value={alertThresholdPercent}
                    onChange={(e) => setAlertThresholdPercent(parseInt(e.target.value) || 80)}
                    className="w-full bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-white font-mono mt-1"
                  />
                </div>
              </div>

              <button
                onClick={handleSaveBudgetAlert}
                className="w-full py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center space-x-1.5 transition-colors"
              >
                {isAlertSaved ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" /> : <BellRing className="w-3.5 h-3.5" />}
                <span>{isAlertSaved ? 'Budget Alert Rules Saved!' : 'Save Budget Alert Thresholds'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Gemini AI Cost Optimization Insights (6 Cols) */}
        <div className="lg:col-span-6 bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-yellow-300" />
              Gemini AI Cost Optimization Recommendations
            </h3>
            <span className="text-[10px] font-mono text-emerald-400 font-bold">Potential ~$365.90 / mo Savings</span>
          </div>

          <div className="space-y-3">
            {optimizations.map((opt) => (
              <div key={opt.id} className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">{opt.title}</span>
                  <span className="text-xs font-extrabold text-emerald-400 font-mono">
                    +${opt.estimatedSavingsMonthlyUSD}/mo
                  </span>
                </div>

                <p className="text-[11px] text-slate-300 leading-relaxed">{opt.description}</p>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800/60 text-[10px] font-mono">
                  <span className="text-purple-300 font-bold">Action: {opt.recommendedAction}</span>
                  <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    {opt.impactScore} IMPACT
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
