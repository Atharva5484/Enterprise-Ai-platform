import React, { useState } from 'react';
import {
  Sparkles,
  Code,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  Play,
  RefreshCw,
  Copy,
  Layers,
  FileText,
  Zap,
  DollarSign,
  FileSearch,
} from 'lucide-react';
import { PromptTemplate } from '../../types/mlops';
import { RagasEvalModule } from './RagasEvalModule';
import { CostAnalyticsDashboard } from './CostAnalyticsDashboard';
import { AgentOrchestrationModule } from './AgentOrchestrationModule';
import { GitFork } from 'lucide-react';

interface LLMOpsViewProps {
  promptTemplates: PromptTemplate[];
  onOpenCopilotWithContext: (prompt: string) => void;
  onOpenExportModal?: () => void;
}

export const LLMOpsView: React.FC<LLMOpsViewProps> = ({
  promptTemplates,
  onOpenCopilotWithContext,
  onOpenExportModal,
}) => {
  const [activeTab, setActiveTab] = useState<'agents' | 'ragas' | 'cost' | 'prompts'>('agents');

  const [selectedPrompt, setSelectedPrompt] = useState<PromptTemplate>(promptTemplates[0]);
  const [editableTemplate, setEditableTemplate] = useState<string>(promptTemplates[0].template);
  const [sampleInputContext, setSampleInputContext] = useState<string>(
    'Company: Acme Bank, Quarter: Q2 2026, Wire Transfer Amount: $2,450,000, Flagged for Sanctions Check.'
  );
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);
  const [evalReport, setEvalReport] = useState<any>(null);

  // Send request to server AI prompt evaluation endpoint
  const handleEvaluatePrompt = async () => {
    try {
      setIsEvaluating(true);
      setEvalReport(null);

      const res = await fetch('/api/eval-prompt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          promptText: editableTemplate,
          sampleInput: sampleInputContext,
        }),
      });

      const data = await res.json();
      setEvalReport(data);
    } catch (err: any) {
      console.error(err);
      setEvalReport({ error: 'Evaluation failed', details: err.message });
    } finally {
      setIsEvaluating(false);
    }
  };

  return (
    <div className="p-6 space-y-6 text-slate-100 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 p-5 rounded-2xl border border-slate-800">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-400" />
            Enterprise LLMOps & GenAI Hub
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            RAGAS document evaluation framework, token usage & cost analytics, and prompt registry benchmarking.
          </p>
        </div>

        {/* View Switcher Tabs */}
        <div className="flex items-center space-x-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('agents')}
            className={`px-3.5 py-1.5 rounded-lg font-bold transition-all flex items-center gap-2 ${
              activeTab === 'agents'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <GitFork className="w-3.5 h-3.5 text-indigo-300" />
            <span>Agent Orchestration</span>
          </button>

          <button
            onClick={() => setActiveTab('ragas')}
            className={`px-3.5 py-1.5 rounded-lg font-bold transition-all flex items-center gap-2 ${
              activeTab === 'ragas'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileSearch className="w-3.5 h-3.5 text-purple-300" />
            <span>RAGAS Document Eval</span>
          </button>

          <button
            onClick={() => setActiveTab('cost')}
            className={`px-3.5 py-1.5 rounded-lg font-bold transition-all flex items-center gap-2 ${
              activeTab === 'cost'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
            <span>Cost Analytics</span>
          </button>

          <button
            onClick={() => setActiveTab('prompts')}
            className={`px-3.5 py-1.5 rounded-lg font-bold transition-all flex items-center gap-2 ${
              activeTab === 'prompts'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>Prompt Registry</span>
          </button>
        </div>
      </div>

      {activeTab === 'agents' && (
        <AgentOrchestrationModule
          onOpenCopilotWithContext={onOpenCopilotWithContext}
          onOpenExportModal={onOpenExportModal}
        />
      )}

      {activeTab === 'ragas' && (
        <RagasEvalModule onOpenCopilotWithContext={onOpenCopilotWithContext} />
      )}

      {activeTab === 'cost' && (
        <CostAnalyticsDashboard onOpenCopilotWithContext={onOpenCopilotWithContext} />
      )}

      {activeTab === 'prompts' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Prompt Templates (4 Cols) */}
          <div className="lg:col-span-4 space-y-3">
            {promptTemplates.map((p) => {
              const isSelected = selectedPrompt.id === p.id;
              return (
                <div
                  key={p.id}
                  onClick={() => {
                    setSelectedPrompt(p);
                    setEditableTemplate(p.template);
                  }}
                  className={`p-4 rounded-xl border transition-all cursor-pointer space-y-2 ${
                    isSelected
                      ? 'bg-slate-900 border-purple-500 ring-1 ring-purple-500/40 shadow-lg'
                      : 'bg-slate-900/60 border-slate-800 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono text-purple-400 uppercase font-bold">{p.version}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                      {p.category}
                    </span>
                  </div>

                  <h3 className="text-xs font-bold text-white">{p.title}</h3>

                  <div className="grid grid-cols-2 gap-2 text-[11px] font-mono bg-slate-950 p-2 rounded-lg border border-slate-800/80 mt-2">
                    <div>
                      <span className="text-slate-500 block text-[9px]">Faithfulness</span>
                      <span className="text-emerald-400 font-bold">{p.faithfulnessScore}%</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[9px]">Hallucination</span>
                      <span className="text-cyan-300 font-bold">{p.hallucinationRate}%</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Right Column: Prompt Editor & Automated Benchmarking (8 Cols) */}
          <div className="lg:col-span-8 space-y-5">
            <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div>
                  <span className="text-[10px] font-mono text-purple-400 uppercase font-bold">Template Editor & Variables</span>
                  <h2 className="text-sm font-bold text-white">{selectedPrompt.title}</h2>
                </div>

                <button
                  onClick={handleEvaluatePrompt}
                  disabled={isEvaluating}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center space-x-2 shadow transition-all disabled:opacity-50"
                >
                  {isEvaluating ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Play className="w-3.5 h-3.5 fill-current" />
                  )}
                  <span>{isEvaluating ? 'Benchmarking Prompt...' : 'Run Automated Benchmark'}</span>
                </button>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-[11px] font-mono text-slate-400 uppercase font-bold">Prompt Template</label>
                  <textarea
                    value={editableTemplate}
                    onChange={(e) => setEditableTemplate(e.target.value)}
                    rows={6}
                    className="w-full bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-xs text-purple-200 focus:outline-none focus:border-purple-500 leading-relaxed mt-1"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-mono text-slate-400 uppercase font-bold">Sample Context Input</label>
                  <input
                    type="text"
                    value={sampleInputContext}
                    onChange={(e) => setSampleInputContext(e.target.value)}
                    className="w-full bg-slate-950 px-3.5 py-2 rounded-xl border border-slate-800 font-mono text-xs text-slate-200 focus:outline-none focus:border-purple-500 mt-1"
                  />
                </div>
              </div>
            </div>

            {/* Evaluation Results Card */}
            {evalReport && (
              <div className="bg-slate-900 p-5 rounded-2xl border border-purple-500/40 space-y-4 shadow-xl">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-purple-400" />
                    Gemini Prompt Evaluation Benchmark Report
                  </h3>
                  <span className="text-xs font-mono text-emerald-400 font-bold">Passed Quality Gate</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-500 uppercase font-bold">Faithfulness</span>
                    <div className="text-lg font-extrabold text-emerald-400 font-mono mt-0.5">
                      {evalReport.faithfulnessScore}%
                    </div>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-500 uppercase font-bold">Hallucination Rate</span>
                    <div className="text-lg font-extrabold text-cyan-300 font-mono mt-0.5">
                      {evalReport.hallucinationRate}%
                    </div>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-500 uppercase font-bold">Toxicity Risk</span>
                    <div className="text-lg font-extrabold text-emerald-400 font-mono mt-0.5">
                      {evalReport.toxicityRisk}%
                    </div>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-500 uppercase font-bold">Clarity Score</span>
                    <div className="text-lg font-extrabold text-purple-300 font-mono mt-0.5">
                      {evalReport.clarityScore}%
                    </div>
                  </div>
                </div>

                {evalReport.recommendations && (
                  <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
                    <span className="text-xs font-bold text-slate-200">Recommendations:</span>
                    <ul className="list-disc list-inside text-xs text-slate-300 space-y-1 font-mono">
                      {evalReport.recommendations.map((rec: string, idx: number) => (
                        <li key={idx}>{rec}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
