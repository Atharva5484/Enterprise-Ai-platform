import React, { useState } from 'react';
import {
  GitFork,
  Bot,
  Terminal,
  Clock,
  Play,
  Pause,
  RefreshCw,
  Plus,
  Search,
  Layers,
  Cpu,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Send,
  Sliders,
  Sparkles,
  ChevronRight,
  Database,
  ArrowRight,
  Code,
  ShieldCheck,
  UserCheck,
  Eye,
  Trash2,
  Calendar,
  Zap,
  Info,
  X,
  MessageSquare,
  FileCode,
  Settings,
  Download,
} from 'lucide-react';
import {
  AgentNodeDetail,
  AgentCommunicationMessage,
  AgentScheduledTask,
} from '../../types/langgraph';

interface AgentOrchestrationModuleProps {
  onOpenCopilotWithContext?: (prompt: string) => void;
  onOpenExportModal?: () => void;
}

// Pre-defined Workflows Meta
export interface AgentWorkflowMeta {
  id: string;
  name: string;
  framework: 'LangGraph' | 'AutoGen' | 'CrewAI' | 'MCP Server';
  description: string;
  status: 'running' | 'idle' | 'scheduled' | 'failed' | 'succeeded';
  lastRun: string;
  totalTokens: number;
  avgLatencyMs: number;
  activeAgentsCount: number;
  agents: AgentNodeDetail[];
}

const INITIAL_WORKFLOWS: AgentWorkflowMeta[] = [
  {
    id: 'wf-langgraph-rag',
    name: 'LangGraph Multi-Agent RAG & Quality Sentinel',
    framework: 'LangGraph',
    description: 'Stateful LangGraph workflow routing vector retrieval, faithfulness scoring, and memory check-pointing.',
    status: 'running',
    lastRun: '2 mins ago',
    totalTokens: 14250,
    avgLatencyMs: 480,
    activeAgentsCount: 4,
    agents: [
      {
        id: 'agent-lg-supervisor',
        name: 'Supervisor Agent',
        role: 'Orchestrator & Intent Classifier',
        framework: 'LangGraph',
        model: 'Gemini 1.5 Pro',
        status: 'completed',
        systemPrompt: 'You are the supervisor agent. Inspect input user query, evaluate schema state, and route to VectorRetriever or CodeExecutor.',
        memoryBuffer: [
          { role: 'user', content: 'Audit Q2 risk metrics for Acme Bank', timestamp: '14:02:10' },
          { role: 'assistant', content: 'Delegating to Document Retriever Agent with top_k=5 and Qdrant index', timestamp: '14:02:11' },
        ],
        stateVariables: {
          thread_id: 'lg-thread-9842',
          recursion_limit: 25,
          current_step: 'verification',
          intent: 'risk_audit',
          retrieval_approved: true,
        },
        tools: ['QdrantVectorSearch', 'IntentClassifier', 'CheckpointerStateSaver'],
        tokensUsed: 2150,
        latencyMs: 340,
      },
      {
        id: 'agent-lg-retriever',
        name: 'Document Retriever Agent',
        role: 'Dense Vector & Hybrid BM25 Search',
        framework: 'LangGraph',
        model: 'Gemini 1.5 Flash',
        status: 'completed',
        systemPrompt: 'Execute vector search on dense Qdrant collection. Extract top matching text chunks.',
        memoryBuffer: [
          { role: 'system', content: 'Query vector embedding generated via Gemini Text Embedding 004', timestamp: '14:02:12' },
          { role: 'assistant', content: 'Retrieved 4 relevant context chunks with avg cosine similarity 0.94', timestamp: '14:02:13' },
        ],
        stateVariables: {
          chunks_retrieved: 4,
          top_similarity: 0.962,
          collection: 'financial_q2_reports',
        },
        tools: ['QdrantVectorStore', 'CohereRerank'],
        tokensUsed: 4200,
        latencyMs: 180,
      },
      {
        id: 'agent-lg-evaluator',
        name: 'RAGAS Faithfulness Evaluator',
        role: 'Quality Sentinel & Hallucination Guard',
        framework: 'LangGraph',
        model: 'Gemini 1.5 Pro',
        status: 'running',
        systemPrompt: 'Verify candidate response against context chunks. Compute Faithfulness and Context Precision.',
        memoryBuffer: [
          { role: 'user', content: 'Evaluate statement claims against retrieved text', timestamp: '14:02:14' },
          { role: 'assistant', content: 'Faithfulness score = 0.98. Supported statements 4/4.', timestamp: '14:02:15' },
        ],
        stateVariables: {
          faithfulness_score: 0.98,
          context_precision: 0.95,
          hallucination_detected: false,
        },
        tools: ['RagasMetricEvaluator', 'FactCheckerEngine'],
        tokensUsed: 5400,
        latencyMs: 620,
      },
      {
        id: 'agent-lg-checkpoint',
        name: 'State Checkpointer Node',
        role: 'Durable Postgres State Saver',
        framework: 'LangGraph',
        model: 'System Deterministic',
        status: 'idle',
        systemPrompt: 'Save current state graph snapshot to durable database.',
        memoryBuffer: [
          { role: 'system', content: 'Snapshot serialized to Postgres table langgraph_checkpoints', timestamp: '14:02:16' },
        ],
        stateVariables: {
          checkpoint_id: 'chk_9941_v2',
          saved_keys: 8,
          bytes_written: 1420,
        },
        tools: ['PostgresStateSaver'],
        tokensUsed: 0,
        latencyMs: 15,
      },
    ],
  },
  {
    id: 'wf-autogen-devteam',
    name: 'AutoGen Autonomous Software Dev Swarm',
    framework: 'AutoGen',
    description: 'Conversational AutoGen agent group chat featuring UserProxy, Architect, Coder, and CodeReviewer.',
    status: 'idle',
    lastRun: '15 mins ago',
    totalTokens: 28900,
    avgLatencyMs: 820,
    activeAgentsCount: 4,
    agents: [
      {
        id: 'agent-ag-userproxy',
        name: 'User Proxy Agent',
        role: 'Human-in-the-Loop & Code Executor',
        framework: 'AutoGen',
        model: 'Human / System Sandbox',
        status: 'idle',
        systemPrompt: 'Execute generated Python/TypeScript code in isolated Docker sandbox upon user consent.',
        memoryBuffer: [
          { role: 'user', content: 'Build a Ray distributed cluster initialization script', timestamp: '13:45:00' },
        ],
        stateVariables: {
          human_input_mode: 'NEVER',
          code_execution_config: { work_dir: '/sandbox', use_docker: true },
          max_consecutive_auto_reply: 10,
        },
        tools: ['DockerSandboxExecutor', 'TerminalRunner'],
        tokensUsed: 1200,
        latencyMs: 45,
      },
      {
        id: 'agent-ag-architect',
        name: 'Software Architect Agent',
        role: 'System Design & Specification Planner',
        framework: 'AutoGen',
        model: 'Gemini 1.5 Pro',
        status: 'completed',
        systemPrompt: 'Break down complex developer requests into modular component specifications and interfaces.',
        memoryBuffer: [
          { role: 'assistant', content: 'Created design spec with 3 modules: ClusterInit, WorkerManager, HealthCheck.', timestamp: '13:45:10' },
        ],
        stateVariables: {
          spec_approved: true,
          modules_count: 3,
        },
        tools: ['UMLDiagramGenerator', 'SpecValidator'],
        tokensUsed: 8400,
        latencyMs: 710,
      },
      {
        id: 'agent-ag-coder',
        name: 'Code Writer Agent',
        role: 'Full-Stack & Python Engineer',
        framework: 'AutoGen',
        model: 'Gemini 1.5 Pro',
        status: 'completed',
        systemPrompt: 'Write clean, type-safe Python and TypeScript code matching architecture spec.',
        memoryBuffer: [
          { role: 'assistant', content: 'Generated script `init_ray_cluster.py` with multi-node initialization handles.', timestamp: '13:45:25' },
        ],
        stateVariables: {
          lines_generated: 142,
          syntax_valid: true,
        },
        tools: ['ASTParser', 'LinterEngine'],
        tokensUsed: 12400,
        latencyMs: 950,
      },
      {
        id: 'agent-ag-reviewer',
        name: 'Code Reviewer Agent',
        role: 'Security & Quality Gatekeeper',
        framework: 'AutoGen',
        model: 'Gemini 1.5 Pro',
        status: 'completed',
        systemPrompt: 'Inspect code for vulnerabilities, edge case errors, and memory leaks. Return TERMINATE when satisfied.',
        memoryBuffer: [
          { role: 'assistant', content: 'Code inspection passed. No vulnerabilities detected. Response ends with TERMINATE.', timestamp: '13:45:35' },
        ],
        stateVariables: {
          security_vulnerabilities: 0,
          approved: true,
          terminate_signal: true,
        },
        tools: ['BanditSecurityScanner', 'StaticAnalysisEngine'],
        tokensUsed: 6900,
        latencyMs: 580,
      },
    ],
  },
];

const INITIAL_LOGS: AgentCommunicationMessage[] = [
  {
    id: 'log-1',
    workflowId: 'wf-langgraph-rag',
    timestamp: '14:02:10',
    sender: 'Supervisor Agent',
    senderFramework: 'LangGraph',
    receiver: 'Document Retriever Agent',
    messageType: 'TASK_DELEGATION',
    summary: 'Delegated query intent "Audit Q2 risk metrics for Acme Bank" to Document Retriever.',
    payload: { query: 'Audit Q2 risk metrics for Acme Bank', top_k: 5, index: 'financial_q2_reports' },
    tokensUsed: 420,
    latencyMs: 120,
  },
  {
    id: 'log-2',
    workflowId: 'wf-langgraph-rag',
    timestamp: '14:02:12',
    sender: 'Document Retriever Agent',
    senderFramework: 'LangGraph',
    receiver: 'RAGAS Faithfulness Evaluator',
    messageType: 'TOOL_RESULT',
    summary: 'Retrieved 4 vector chunks from Qdrant with max similarity 0.962.',
    payload: { chunks_count: 4, top_similarity: 0.962, vector_store: 'Qdrant' },
    tokensUsed: 1280,
    latencyMs: 180,
  },
  {
    id: 'log-3',
    workflowId: 'wf-langgraph-rag',
    timestamp: '14:02:14',
    sender: 'RAGAS Faithfulness Evaluator',
    senderFramework: 'LangGraph',
    receiver: 'State Checkpointer Node',
    messageType: 'STATE_UPDATE',
    summary: 'Computed RAGAS metrics: Faithfulness = 98%, Context Precision = 95%. Triggering Checkpointer.',
    payload: { faithfulness: 0.98, context_precision: 0.95, hallucination: false },
    tokensUsed: 890,
    latencyMs: 240,
  },
  {
    id: 'log-4',
    workflowId: 'wf-autogen-devteam',
    timestamp: '13:45:00',
    sender: 'User Proxy Agent',
    senderFramework: 'AutoGen',
    receiver: 'Software Architect Agent',
    messageType: 'TASK_DELEGATION',
    summary: 'Initiated AutoGen GroupChat for user goal: "Build Ray distributed cluster initialization script".',
    payload: { user_prompt: 'Build Ray distributed cluster script', execution_sandbox: 'Docker' },
    tokensUsed: 310,
    latencyMs: 45,
  },
  {
    id: 'log-5',
    workflowId: 'wf-autogen-devteam',
    timestamp: '13:45:10',
    sender: 'Software Architect Agent',
    senderFramework: 'AutoGen',
    receiver: 'Code Writer Agent',
    messageType: 'PLAN_VERIFICATION',
    summary: 'Passed system spec architecture layout to Code Writer Agent.',
    payload: { spec_modules: ['ClusterInit', 'WorkerManager', 'HealthCheck'] },
    tokensUsed: 1450,
    latencyMs: 380,
  },
];

const INITIAL_SCHEDULED_TASKS: AgentScheduledTask[] = [
  {
    id: 'task-101',
    workflowId: 'wf-langgraph-rag',
    workflowName: 'LangGraph Multi-Agent RAG & Quality Sentinel',
    framework: 'LangGraph',
    scheduleType: 'CRON',
    cronExpression: '0 */2 * * *',
    promptGoal: 'Run automated RAGAS quality audit on newly uploaded PDF knowledge base chunks.',
    status: 'SCHEDULED',
    nextRunAt: 'In 1 hour 45 mins',
    lastRunAt: '2026-08-04 06:00:00',
    maxTurns: 15,
    priority: 'HIGH',
    createdByName: 'Lead MLOps Engineer',
  },
  {
    id: 'task-102',
    workflowId: 'wf-autogen-devteam',
    workflowName: 'AutoGen Autonomous Software Dev Swarm',
    framework: 'AutoGen',
    scheduleType: 'MANUAL',
    promptGoal: 'Refactor PyTorch model serving endpoint to support dynamic batching and vLLM acceleration.',
    status: 'COMPLETED',
    lastRunAt: '2026-08-04 05:12:00',
    maxTurns: 25,
    priority: 'NORMAL',
    createdByName: 'DevOps Lead',
  },
];

export const AgentOrchestrationModule: React.FC<AgentOrchestrationModuleProps> = ({
  onOpenCopilotWithContext,
  onOpenExportModal,
}) => {
  const [workflows, setWorkflows] = useState<AgentWorkflowMeta[]>(INITIAL_WORKFLOWS);
  const [selectedWorkflowId, setSelectedWorkflowId] = useState<string>(INITIAL_WORKFLOWS[0].id);
  const [selectedFrameworkFilter, setSelectedFrameworkFilter] = useState<string>('ALL');
  
  // Active selected workflow
  const activeWorkflow = workflows.find((w) => w.id === selectedWorkflowId) || workflows[0];

  // Selected Agent Node for State Inspector
  const [selectedAgentId, setSelectedAgentId] = useState<string>(activeWorkflow.agents[0].id);
  const activeAgent = activeWorkflow.agents.find((a) => a.id === selectedAgentId) || activeWorkflow.agents[0];

  // Communication Logs State
  const [logs, setLogs] = useState<AgentCommunicationMessage[]>(INITIAL_LOGS);
  const [logSearchQuery, setLogSearchQuery] = useState<string>('');
  const [logMessageTypeFilter, setLogMessageTypeFilter] = useState<string>('ALL');

  // Manual Bus Injection Input
  const [manualInjectionMessage, setManualInjectionMessage] = useState<string>('');
  const [injectionTargetAgent, setInjectionTargetAgent] = useState<string>(activeWorkflow.agents[0].name);

  // Manual Task Scheduler Modal State
  const [isSchedulerModalOpen, setIsSchedulerModalOpen] = useState<boolean>(false);
  const [taskTargetWorkflowId, setTaskTargetWorkflowId] = useState<string>(activeWorkflow.id);
  const [taskScheduleType, setTaskScheduleType] = useState<'MANUAL' | 'CRON'>('MANUAL');
  const [taskCronExpression, setTaskCronExpression] = useState<string>('0 */4 * * *');
  const [taskPromptGoal, setTaskPromptGoal] = useState<string>(
    'Execute autonomous stateful agent audit on Qdrant embeddings and evaluate drift metrics.'
  );
  const [taskMaxTurns, setTaskMaxTurns] = useState<number>(20);
  const [taskPriority, setTaskPriority] = useState<'HIGH' | 'NORMAL' | 'LOW'>('HIGH');
  const [scheduledTasks, setScheduledTasks] = useState<AgentScheduledTask[]>(INITIAL_SCHEDULED_TASKS);
  const [isSimulatingRun, setIsSimulatingRun] = useState<boolean>(false);

  // Filtered Workflows by Framework
  const filteredWorkflows = workflows.filter((w) => {
    if (selectedFrameworkFilter === 'ALL') return true;
    return w.framework === selectedFrameworkFilter;
  });

  // Filtered Logs by Active Workflow & Filters
  const filteredLogs = logs.filter((l) => {
    if (l.workflowId !== activeWorkflow.id) return false;
    if (logMessageTypeFilter !== 'ALL' && l.messageType !== logMessageTypeFilter) return false;
    if (logSearchQuery.trim() !== '') {
      const q = logSearchQuery.toLowerCase();
      return (
        l.sender.toLowerCase().includes(q) ||
        l.receiver.toLowerCase().includes(q) ||
        l.summary.toLowerCase().includes(q)
      );
    }
    return true;
  });

  // Handle Injecting Manual Message to Communication Bus
  const handleInjectBusMessage = () => {
    if (!manualInjectionMessage.trim()) return;

    const newLog: AgentCommunicationMessage = {
      id: `log-${Date.now()}`,
      workflowId: activeWorkflow.id,
      timestamp: new Date().toLocaleTimeString('en-US', { hour12: false }),
      sender: 'Human Operator (Manual Override)',
      senderFramework: activeWorkflow.framework,
      receiver: injectionTargetAgent,
      messageType: 'HUMAN_APPROVAL',
      summary: `Injected operator instruction: "${manualInjectionMessage}"`,
      payload: { operator_override: manualInjectionMessage, target_agent: injectionTargetAgent },
      tokensUsed: 120,
      latencyMs: 25,
    };

    setLogs([newLog, ...logs]);
    setManualInjectionMessage('');
  };

  // Handle Triggering / Scheduling Task
  const handleTriggerTask = () => {
    if (!taskPromptGoal.trim()) return;

    setIsSimulatingRun(true);

    setTimeout(() => {
      const targetWf = workflows.find((w) => w.id === taskTargetWorkflowId) || activeWorkflow;

      const newTask: AgentScheduledTask = {
        id: `task-${Date.now()}`,
        workflowId: targetWf.id,
        workflowName: targetWf.name,
        framework: targetWf.framework,
        scheduleType: taskScheduleType,
        cronExpression: taskScheduleType === 'CRON' ? taskCronExpression : undefined,
        promptGoal: taskPromptGoal,
        status: taskScheduleType === 'MANUAL' ? 'RUNNING' : 'SCHEDULED',
        nextRunAt: taskScheduleType === 'CRON' ? 'In 4 hours' : 'Immediate',
        lastRunAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
        maxTurns: taskMaxTurns,
        priority: taskPriority,
        createdByName: 'Operator Studio',
      };

      setScheduledTasks([newTask, ...scheduledTasks]);

      // Add simulated execution log to active workflow
      const simLog: AgentCommunicationMessage = {
        id: `log-sim-${Date.now()}`,
        workflowId: targetWf.id,
        timestamp: new Date().toLocaleTimeString('en-US', { hour12: false }),
        sender: 'Manual Scheduler Engine',
        senderFramework: targetWf.framework,
        receiver: targetWf.agents[0].name,
        messageType: 'TASK_DELEGATION',
        summary: `Triggered manual task schedule: "${taskPromptGoal.slice(0, 80)}..."`,
        payload: { task_id: newTask.id, max_turns: taskMaxTurns, priority: taskPriority },
        tokensUsed: 520,
        latencyMs: 95,
      };

      setLogs([simLog, ...logs]);
      setIsSimulatingRun(false);
      setIsSchedulerModalOpen(false);
    }, 800);
  };

  return (
    <div className="space-y-6 text-slate-100">
      {/* Top Header & Framework Switcher */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900 p-5 rounded-2xl border border-slate-800 shadow-xl">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-mono font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Agent Control Plane
            </span>
            <span className="text-xs text-slate-400 font-mono">LangGraph & AutoGen Workflows</span>
          </div>
          <h2 className="text-base font-bold text-white mt-1 flex items-center gap-2">
            <GitFork className="w-5 h-5 text-indigo-400" />
            Enterprise Agent Orchestration Studio
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Monitor stateful LangGraph graphs & AutoGen group chats, inspect agent memories, trace inter-agent communication, and schedule automated tasks.
          </p>
        </div>

        {/* Framework Filter & Quick Actions */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Framework Selector Pills */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-mono">
            {['ALL', 'LangGraph', 'AutoGen', 'CrewAI', 'MCP Server'].map((fw) => (
              <button
                key={fw}
                onClick={() => setSelectedFrameworkFilter(fw)}
                className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
                  selectedFrameworkFilter === fw
                    ? 'bg-indigo-600 text-white shadow'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {fw}
              </button>
            ))}
          </div>

          <button
            onClick={() => setIsSchedulerModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold text-xs flex items-center space-x-2 shadow-lg shadow-indigo-600/20 transition-all"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Trigger Task / Schedule</span>
          </button>

          {onOpenExportModal && (
            <button
              onClick={onOpenExportModal}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 border border-indigo-500/30 font-bold text-xs flex items-center space-x-1.5 transition-colors shadow-sm"
              title="Export Agent Work, Traces & Logs"
            >
              <Download className="w-3.5 h-3.5 text-indigo-400" />
              <span>Export Work Data</span>
            </button>
          )}

          {onOpenCopilotWithContext && (
            <button
              onClick={() =>
                onOpenCopilotWithContext(
                  `Explain the architectural differences between LangGraph stateful graph nodes (with Postgres checkpointers) vs AutoGen conversational GroupChat multi-agent swarms.`
                )
              }
              className="px-3.5 py-2 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30 font-semibold text-xs flex items-center space-x-1.5 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
              <span>Orchestration Guide</span>
            </button>
          )}
        </div>
      </div>

      {/* Active Workflows Cards Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
        {filteredWorkflows.map((wf) => {
          const isSelected = wf.id === selectedWorkflowId;
          return (
            <div
              key={wf.id}
              onClick={() => {
                setSelectedWorkflowId(wf.id);
                if (wf.agents.length > 0) setSelectedAgentId(wf.agents[0].id);
              }}
              className={`p-4 rounded-2xl border transition-all cursor-pointer space-y-3 ${
                isSelected
                  ? 'bg-slate-900 border-indigo-500 ring-2 ring-indigo-500/30 shadow-xl'
                  : 'bg-slate-900/70 border-slate-800 hover:bg-slate-900'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span
                    className={`px-2.5 py-0.5 rounded text-[10px] font-mono font-bold border ${
                      wf.framework === 'LangGraph'
                        ? 'bg-purple-500/20 text-purple-300 border-purple-500/30'
                        : 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30'
                    }`}
                  >
                    {wf.framework}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold flex items-center gap-1 ${
                      wf.status === 'running'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 animate-pulse'
                        : 'bg-slate-800 text-slate-300 border border-slate-700'
                    }`}
                  >
                    <span className={`w-1.5 h-1.5 rounded-full ${wf.status === 'running' ? 'bg-emerald-400' : 'bg-slate-400'}`} />
                    {wf.status.toUpperCase()}
                  </span>
                </div>

                <span className="text-[11px] font-mono text-slate-400">Last run: {wf.lastRun}</span>
              </div>

              <div>
                <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Bot className="w-4 h-4 text-indigo-400" />
                  {wf.name}
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed line-clamp-2">{wf.description}</p>
              </div>

              <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800/80 font-mono text-[11px]">
                <div>
                  <span className="text-slate-500 text-[10px] uppercase font-bold block">Active Agents</span>
                  <span className="text-white font-bold">{wf.activeAgentsCount} Agents</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px] uppercase font-bold block">Token Spent</span>
                  <span className="text-purple-300 font-bold">{(wf.totalTokens / 1000).toFixed(1)}k tokens</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px] uppercase font-bold block">Avg Step Latency</span>
                  <span className="text-emerald-400 font-bold">{wf.avgLatencyMs} ms</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Main Orchestration Workspace: Visual Agent State Graph (7 Cols) vs State Inspector (5 Cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Visual View of Agent State Graph (7 Cols) */}
        <div className="lg:col-span-7 bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <span className="text-[10px] font-mono text-indigo-400 uppercase font-bold">Visual Workflow State Graph</span>
              <h3 className="text-xs font-bold text-white">{activeWorkflow.name}</h3>
            </div>

            <div className="flex items-center space-x-2 text-xs font-mono">
              <span className="px-2.5 py-1 rounded bg-slate-950 border border-slate-800 text-slate-300">
                Framework: <strong className="text-indigo-300">{activeWorkflow.framework}</strong>
              </span>
            </div>
          </div>

          {/* Interactive Agent Nodes Flow Layout */}
          <div className="bg-slate-950/80 p-5 rounded-xl border border-slate-800 min-h-[340px] flex flex-col justify-between relative overflow-hidden">
            {/* Background Network Grid Pattern */}
            <div className="absolute inset-0 bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:16px_16px] opacity-30 pointer-events-none" />

            <div className="relative z-10 space-y-6">
              <div className="text-[10px] font-mono text-slate-400 flex items-center justify-between">
                <span>Click any Agent Node to inspect internal Memory Buffer, Variables & Prompt:</span>
                <span className="text-emerald-400 font-bold">State Checkpoints: Synchronized</span>
              </div>

              {/* Agent Nodes Visual Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {activeWorkflow.agents.map((agent, index) => {
                  const isNodeSelected = agent.id === selectedAgentId;
                  return (
                    <div
                      key={agent.id}
                      onClick={() => setSelectedAgentId(agent.id)}
                      className={`p-3.5 rounded-xl border cursor-pointer transition-all space-y-2 relative ${
                        isNodeSelected
                          ? 'bg-slate-900 border-indigo-400 ring-2 ring-indigo-400/30 shadow-lg'
                          : 'bg-slate-900/80 border-slate-800 hover:bg-slate-900'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold text-slate-400 flex items-center gap-1">
                          <span className="w-4 h-4 rounded-full bg-slate-800 text-indigo-300 flex items-center justify-center text-[9px]">
                            {index + 1}
                          </span>
                          {agent.framework}
                        </span>

                        <span
                          className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold ${
                            agent.status === 'running'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 animate-pulse'
                              : agent.status === 'completed'
                              ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                              : 'bg-slate-800 text-slate-400 border border-slate-700'
                          }`}
                        >
                          {agent.status.toUpperCase()}
                        </span>
                      </div>

                      <div>
                        <h4 className="text-xs font-bold text-white flex items-center justify-between">
                          <span>{agent.name}</span>
                          <ChevronRight className={`w-3.5 h-3.5 text-slate-500 ${isNodeSelected ? 'text-indigo-400 transform rotate-90' : ''}`} />
                        </h4>
                        <p className="text-[11px] text-slate-400 mt-0.5 font-medium">{agent.role}</p>
                      </div>

                      <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 pt-1.5 border-t border-slate-800">
                        <span>Model: <strong className="text-slate-200">{agent.model}</strong></span>
                        <span>{(agent.tokensUsed / 1000).toFixed(1)}k tok</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Bottom Workflow Legend & Execution Pipeline Trail */}
            <div className="relative z-10 pt-4 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono text-slate-400">
              <div className="flex items-center space-x-3">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  Running
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-purple-400" />
                  Completed
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-slate-500" />
                  Idle
                </span>
              </div>

              <span className="text-indigo-300 font-bold">
                {activeWorkflow.agents.length} State Nodes Connected
              </span>
            </div>
          </div>
        </div>

        {/* Right Column: Visual Agent State Inspector Panel (5 Cols) */}
        <div className="lg:col-span-5 bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <span className="text-[10px] font-mono text-indigo-400 uppercase font-bold">Agent State Inspector</span>
              <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                <Bot className="w-4 h-4 text-purple-400" />
                {activeAgent.name}
              </h3>
            </div>

            <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              {activeAgent.framework}
            </span>
          </div>

          <div className="space-y-3 text-xs">
            {/* System Prompt View */}
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
              <span className="text-[10px] font-mono text-slate-400 uppercase font-bold block">System Prompt / Instructions</span>
              <p className="text-[11px] font-mono text-slate-300 leading-relaxed bg-slate-900/60 p-2 rounded border border-slate-800/60">
                "{activeAgent.systemPrompt}"
              </p>
            </div>

            {/* Active State Variables JSON Inspector */}
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5 font-mono">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-indigo-400 uppercase font-bold flex items-center gap-1">
                  <Database className="w-3 h-3" />
                  State Schema Variables
                </span>
                <span className="text-[10px] text-slate-500">{Object.keys(activeAgent.stateVariables).length} keys</span>
              </div>
              <pre className="text-[11px] bg-slate-900/90 p-2.5 rounded-lg text-emerald-300 overflow-x-auto border border-slate-800/80 leading-relaxed font-mono">
                {JSON.stringify(activeAgent.stateVariables, null, 2)}
              </pre>
            </div>

            {/* Memory Buffer Preview */}
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2">
              <span className="text-[10px] font-mono text-slate-400 uppercase font-bold block">Recent Memory Buffer ({activeAgent.memoryBuffer.length})</span>
              <div className="space-y-1.5 max-h-[140px] overflow-y-auto pr-1 text-[11px] font-mono">
                {activeAgent.memoryBuffer.map((msg, i) => (
                  <div key={i} className="bg-slate-900/70 p-2 rounded border border-slate-800/50 space-y-0.5">
                    <div className="flex items-center justify-between text-[9px] text-slate-500">
                      <span className="text-purple-300 font-bold uppercase">{msg.role}</span>
                      <span>{msg.timestamp}</span>
                    </div>
                    <p className="text-slate-300">{msg.content}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Connected Tools Pills */}
            <div>
              <span className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">Attached Tool Capabilities</span>
              <div className="flex flex-wrap gap-1.5">
                {activeAgent.tools.map((t) => (
                  <span key={t} className="px-2 py-0.5 rounded bg-slate-950 text-indigo-300 border border-slate-800 text-[10px] font-mono flex items-center gap-1">
                    <Zap className="w-2.5 h-2.5 text-indigo-400" />
                    {t}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Communication Logs Between Agents (Inter-Agent Trace Feed) */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-4 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <span className="text-[10px] font-mono text-indigo-400 uppercase font-bold">Inter-Agent Trace Log</span>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-purple-400" />
              Communication Logs & Message Bus ({activeWorkflow.name})
            </h3>
          </div>

          {/* Log Filters & Search Bar */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                value={logSearchQuery}
                onChange={(e) => setLogSearchQuery(e.target.value)}
                placeholder="Search agent or message..."
                className="bg-slate-950 pl-8 pr-3 py-1.5 rounded-xl border border-slate-800 text-white font-medium focus:outline-none focus:border-indigo-500 text-xs w-48"
              />
            </div>

            <select
              value={logMessageTypeFilter}
              onChange={(e) => setLogMessageTypeFilter(e.target.value)}
              className="bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-slate-300 font-mono text-xs focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All Message Types</option>
              <option value="TASK_DELEGATION">Task Delegation</option>
              <option value="TOOL_CALL">Tool Call</option>
              <option value="TOOL_RESULT">Tool Result</option>
              <option value="STATE_UPDATE">State Update</option>
              <option value="HUMAN_APPROVAL">Human Approval</option>
            </select>
          </div>
        </div>

        {/* Live Trace Stream Feed */}
        <div className="space-y-2.5 max-h-[320px] overflow-y-auto pr-1">
          {filteredLogs.length > 0 ? (
            filteredLogs.map((log) => (
              <div
                key={log.id}
                className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 hover:border-slate-700 transition-all space-y-2 font-mono"
              >
                <div className="flex flex-wrap items-center justify-between text-[10px] text-slate-400 gap-2">
                  <div className="flex items-center space-x-2">
                    <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/30">
                      {log.sender}
                    </span>
                    <ArrowRight className="w-3 h-3 text-slate-500" />
                    <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-bold border border-purple-500/30">
                      {log.receiver}
                    </span>
                  </div>

                  <div className="flex items-center space-x-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                        log.messageType === 'TASK_DELEGATION'
                          ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                          : log.messageType === 'TOOL_RESULT'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : log.messageType === 'HUMAN_APPROVAL'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-slate-800 text-slate-300 border border-slate-700'
                      }`}
                    >
                      {log.messageType}
                    </span>
                    <span>{log.timestamp}</span>
                    <span>{log.tokensUsed} tokens</span>
                    <span>{log.latencyMs}ms</span>
                  </div>
                </div>

                <p className="text-xs text-slate-200 font-sans font-medium">{log.summary}</p>

                {log.payload && (
                  <details className="text-[11px] text-slate-400">
                    <summary className="cursor-pointer text-indigo-400 hover:text-indigo-300 font-bold">
                      Inspect JSON Payload
                    </summary>
                    <pre className="mt-1 bg-slate-900 p-2 rounded border border-slate-800 text-emerald-300 font-mono text-[10px]">
                      {JSON.stringify(log.payload, null, 2)}
                    </pre>
                  </details>
                )}
              </div>
            ))
          ) : (
            <div className="p-8 bg-slate-950 rounded-xl border border-slate-800 text-center text-slate-400 text-xs">
              No communication logs matching current filter query.
            </div>
          )}
        </div>

        {/* Inject Manual Instruction to Agent Bus */}
        <div className="pt-3 border-t border-slate-800 flex flex-col md:flex-row items-center gap-2">
          <div className="flex items-center space-x-2 text-xs font-mono text-slate-400 shrink-0">
            <span>Inject Operator Prompt To:</span>
            <select
              value={injectionTargetAgent}
              onChange={(e) => setInjectionTargetAgent(e.target.value)}
              className="bg-slate-950 px-2.5 py-1.5 rounded-lg border border-slate-800 text-indigo-300 font-bold focus:outline-none"
            >
              {activeWorkflow.agents.map((a) => (
                <option key={a.id} value={a.name}>
                  {a.name} ({a.framework})
                </option>
              ))}
            </select>
          </div>

          <input
            type="text"
            value={manualInjectionMessage}
            onChange={(e) => setManualInjectionMessage(e.target.value)}
            placeholder="Type operator message or override prompt..."
            className="flex-1 bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 text-white font-medium text-xs focus:outline-none focus:border-indigo-500 w-full"
            onKeyDown={(e) => e.key === 'Enter' && handleInjectBusMessage()}
          />

          <button
            onClick={handleInjectBusMessage}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center space-x-1.5 shrink-0 transition-colors"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Inject Message</span>
          </button>
        </div>
      </div>

      {/* Manual Task Scheduling Queue Table */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-4 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <span className="text-[10px] font-mono text-indigo-400 uppercase font-bold">Task Scheduler & Cron Engine</span>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-emerald-400" />
              Scheduled & Triggered Agent Tasks
            </h3>
          </div>

          <span className="text-xs font-mono text-slate-400">
            Active Jobs: <strong className="text-white">{scheduledTasks.length}</strong>
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-[11px] font-mono text-slate-400 uppercase">
                <th className="py-2.5 px-3">Workflow Target</th>
                <th className="py-2.5 px-3">Type</th>
                <th className="py-2.5 px-3">Goal / Prompt</th>
                <th className="py-2.5 px-3">Priority</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Next / Last Run</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {scheduledTasks.map((task) => (
                <tr key={task.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-3">
                    <span className="font-bold text-white block">{task.workflowName}</span>
                    <span className="text-[10px] text-slate-400">{task.framework}</span>
                  </td>

                  <td className="py-3 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        task.scheduleType === 'CRON'
                          ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                          : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                      }`}
                    >
                      {task.scheduleType} {task.cronExpression ? `(${task.cronExpression})` : ''}
                    </span>
                  </td>

                  <td className="py-3 px-3 text-slate-300 font-sans max-w-[280px] truncate">
                    {task.promptGoal}
                  </td>

                  <td className="py-3 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        task.priority === 'HIGH'
                          ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                          : 'bg-slate-800 text-slate-300 border border-slate-700'
                      }`}
                    >
                      {task.priority}
                    </span>
                  </td>

                  <td className="py-3 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        task.status === 'RUNNING'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 animate-pulse'
                          : task.status === 'SCHEDULED'
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                          : 'bg-slate-800 text-slate-400 border border-slate-700'
                      }`}
                    >
                      {task.status}
                    </span>
                  </td>

                  <td className="py-3 px-3 text-slate-400 text-[11px]">
                    <div>Next: {task.nextRunAt || 'N/A'}</div>
                    <div className="text-[9px] text-slate-500">Last: {task.lastRunAt || 'None'}</div>
                  </td>

                  <td className="py-3 px-3 text-right">
                    <button
                      onClick={() => setScheduledTasks(scheduledTasks.filter((t) => t.id !== task.id))}
                      className="p-1.5 text-slate-500 hover:text-red-400 transition-colors"
                      title="Cancel Task"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Manual Task Trigger / Schedule Modal */}
      {isSchedulerModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full p-6 space-y-5 shadow-2xl text-slate-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-mono text-indigo-400 uppercase font-bold">Manual Trigger & Schedule</span>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Play className="w-4 h-4 text-emerald-400 fill-current" />
                  Schedule Agent Workflow Execution
                </h3>
              </div>
              <button
                onClick={() => setIsSchedulerModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs font-mono">
              {/* Target Workflow Select */}
              <div>
                <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                  Target Workflow Engine
                </label>
                <select
                  value={taskTargetWorkflowId}
                  onChange={(e) => setTaskTargetWorkflowId(e.target.value)}
                  className="w-full bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-white font-medium focus:outline-none focus:border-indigo-500"
                >
                  {workflows.map((w) => (
                    <option key={w.id} value={w.id}>
                      [{w.framework}] {w.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Schedule Type (Manual vs Cron) */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Execution Mode
                  </label>
                  <div className="flex items-center space-x-2 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
                    <button
                      type="button"
                      onClick={() => setTaskScheduleType('MANUAL')}
                      className={`flex-1 py-1.5 rounded-lg font-bold transition-colors ${
                        taskScheduleType === 'MANUAL'
                          ? 'bg-indigo-600 text-white'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Immediate Run
                    </button>
                    <button
                      type="button"
                      onClick={() => setTaskScheduleType('CRON')}
                      className={`flex-1 py-1.5 rounded-lg font-bold transition-colors ${
                        taskScheduleType === 'CRON'
                          ? 'bg-purple-600 text-white'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Cron Job
                    </button>
                  </div>
                </div>

                {taskScheduleType === 'CRON' ? (
                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      Cron Schedule Expression
                    </label>
                    <input
                      type="text"
                      value={taskCronExpression}
                      onChange={(e) => setTaskCronExpression(e.target.value)}
                      placeholder="e.g. 0 */4 * * *"
                      className="w-full bg-slate-950 p-2 rounded-xl border border-slate-800 text-emerald-300 font-mono text-xs focus:outline-none focus:border-purple-500"
                    />
                  </div>
                ) : (
                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                      Priority Level
                    </label>
                    <select
                      value={taskPriority}
                      onChange={(e: any) => setTaskPriority(e.target.value)}
                      className="w-full bg-slate-950 p-2 rounded-xl border border-slate-800 text-white text-xs focus:outline-none"
                    >
                      <option value="HIGH">High Priority</option>
                      <option value="NORMAL">Normal Priority</option>
                      <option value="LOW">Low Priority</option>
                    </select>
                  </div>
                )}
              </div>

              {/* Goal / Prompt Input */}
              <div>
                <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                  Goal / Agent Prompt Instruction
                </label>
                <textarea
                  value={taskPromptGoal}
                  onChange={(e) => setTaskPromptGoal(e.target.value)}
                  rows={3}
                  className="w-full bg-slate-950 p-3 rounded-xl border border-slate-800 text-white font-sans text-xs focus:outline-none focus:border-indigo-500 leading-relaxed"
                  placeholder="Describe goal or instruction for agent workflow..."
                />
              </div>

              {/* Recursion Limit / Max Turns */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">
                    Max Turns / Recursion Limit
                  </label>
                  <input
                    type="number"
                    value={taskMaxTurns}
                    onChange={(e) => setTaskMaxTurns(Number(e.target.value))}
                    min={1}
                    max={100}
                    className="w-full bg-slate-950 p-2 rounded-xl border border-slate-800 text-white text-xs focus:outline-none"
                  />
                </div>

                <div className="flex items-end pb-1">
                  <span className="text-[11px] font-sans text-slate-400">
                    Durable state snapshot checkpointer enabled.
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsSchedulerModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-300 font-semibold text-xs transition-colors"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleTriggerTask}
                disabled={isSimulatingRun}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold text-xs flex items-center space-x-2 shadow-lg transition-all disabled:opacity-50"
              >
                {isSimulatingRun ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Play className="w-3.5 h-3.5 fill-current" />
                )}
                <span>{isSimulatingRun ? 'Triggering Workflow...' : 'Execute Task Now'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
