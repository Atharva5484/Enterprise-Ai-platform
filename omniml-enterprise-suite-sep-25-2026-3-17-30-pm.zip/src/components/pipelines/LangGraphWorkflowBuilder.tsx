import React, { useState } from 'react';
import {
  GitFork,
  Play,
  Plus,
  Trash2,
  Settings,
  Sparkles,
  Code,
  CheckCircle2,
  Clock,
  ArrowRight,
  RefreshCw,
  Copy,
  Check,
  ShieldAlert,
  Brain,
  Database,
  Terminal,
  Cpu,
  Layers,
  FileCode,
  Zap,
  UserCheck,
  HardDrive,
  Eye,
  Sliders,
  ChevronDown,
  ChevronRight,
  AlertTriangle,
} from 'lucide-react';
import {
  LangGraphWorkflow,
  LangGraphNode,
  LangGraphEdge,
  LangGraphNodeType,
} from '../../types/langgraph';
import { INITIAL_LANGGRAPH_WORKFLOWS } from '../../data/mockLangGraphData';

interface LangGraphWorkflowBuilderProps {
  onOpenCopilotWithContext?: (prompt: string) => void;
  onTriggerPipeline?: () => void;
}

export const LangGraphWorkflowBuilder: React.FC<LangGraphWorkflowBuilderProps> = ({
  onOpenCopilotWithContext,
  onTriggerPipeline,
}) => {
  const [workflows, setWorkflows] = useState<LangGraphWorkflow[]>(INITIAL_LANGGRAPH_WORKFLOWS);
  const [selectedWorkflowId, setSelectedWorkflowId] = useState<string>(INITIAL_LANGGRAPH_WORKFLOWS[0].id);
  const activeWorkflow = workflows.find((w) => w.id === selectedWorkflowId) || workflows[0];

  const [selectedNodeId, setSelectedNodeId] = useState<string>(activeWorkflow.nodes[0]?.id || '');
  const selectedNode = activeWorkflow.nodes.find((n) => n.id === selectedNodeId) || activeWorkflow.nodes[0];

  const [isExecuting, setIsExecuting] = useState(false);
  const [activeTab, setActiveTab] = useState<'canvas' | 'code' | 'logs'>('canvas');
  const [copiedCode, setCopiedCode] = useState(false);

  // Drag state or Node Insertion Modal
  const [isAddNodeOpen, setIsAddNodeOpen] = useState(false);
  const [newNodeType, setNewNodeType] = useState<LangGraphNodeType>('agent');
  const [newNodeLabel, setNewNodeLabel] = useState('');

  // Handle Node Select
  const handleSelectNode = (nodeId: string) => {
    setSelectedNodeId(nodeId);
  };

  // Update selected node config
  const handleUpdateNodeConfig = (key: string, value: any) => {
    setWorkflows((prev) =>
      prev.map((wf) => {
        if (wf.id !== activeWorkflow.id) return wf;
        return {
          ...wf,
          nodes: wf.nodes.map((node) => {
            if (node.id !== selectedNodeId) return node;
            return {
              ...node,
              config: {
                ...node.config,
                [key]: value,
              },
            };
          }),
        };
      })
    );
  };

  // Update selected node label
  const handleUpdateNodeLabel = (label: string) => {
    setWorkflows((prev) =>
      prev.map((wf) => {
        if (wf.id !== activeWorkflow.id) return wf;
        return {
          ...wf,
          nodes: wf.nodes.map((node) => (node.id === selectedNodeId ? { ...node, label } : node)),
        };
      })
    );
  };

  // Add new node
  const handleAddNode = () => {
    const newId = `node-${Date.now().toString().slice(-4)}`;
    const lastNode = activeWorkflow.nodes[activeWorkflow.nodes.length - 1];
    const newPosX = lastNode ? lastNode.position.x + 220 : 100;
    const newPosY = 180;

    const newNode: LangGraphNode = {
      id: newId,
      type: newNodeType,
      label: newNodeLabel || `New ${newNodeType.toUpperCase()} Node`,
      description: `Autonomous ${newNodeType} state node`,
      position: { x: newPosX, y: newPosY },
      config: {
        model: 'gemini-1.5-flash',
        prompt: 'Autonomous agent step instructions...',
        maxRetries: 3,
      },
      status: 'idle',
    };

    // Auto-connect to last node
    const newEdge: LangGraphEdge | null = lastNode
      ? {
          id: `edge-${lastNode.id}-${newId}`,
          source: lastNode.id,
          target: newId,
          animated: true,
        }
      : null;

    setWorkflows((prev) =>
      prev.map((wf) => {
        if (wf.id !== activeWorkflow.id) return wf;
        return {
          ...wf,
          nodes: [...wf.nodes, newNode],
          edges: newEdge ? [...wf.edges, newEdge] : wf.edges,
        };
      })
    );

    setSelectedNodeId(newId);
    setIsAddNodeOpen(false);
    setNewNodeLabel('');
  };

  // Delete node
  const handleDeleteNode = (nodeId: string) => {
    if (activeWorkflow.nodes.length <= 2) return; // keep minimum
    setWorkflows((prev) =>
      prev.map((wf) => {
        if (wf.id !== activeWorkflow.id) return wf;
        return {
          ...wf,
          nodes: wf.nodes.filter((n) => n.id !== nodeId),
          edges: wf.edges.filter((e) => e.source !== nodeId && e.target !== nodeId),
        };
      })
    );
    setSelectedNodeId(activeWorkflow.nodes[0].id);
  };

  // Execute Workflow Simulation
  const handleRunWorkflow = async () => {
    try {
      setIsExecuting(true);
      // Simulate step-by-step execution in LangGraph
      setWorkflows((prev) =>
        prev.map((wf) => {
          if (wf.id !== activeWorkflow.id) return wf;
          return {
            ...wf,
            status: 'running',
            nodes: wf.nodes.map((n) => ({ ...n, status: 'running' })),
          };
        })
      );

      await new Promise((res) => setTimeout(res, 1800));

      setWorkflows((prev) =>
        prev.map((wf) => {
          if (wf.id !== activeWorkflow.id) return wf;
          return {
            ...wf,
            status: 'succeeded',
            lastExecutionTime: new Date().toISOString().replace('T', ' ').substring(0, 19),
            nodes: wf.nodes.map((n) => ({ ...n, status: 'completed' })),
            executionLogs: [
              `[${new Date().toLocaleTimeString()}] [LangGraph Engine] Initialized StateGraph with thread ID lg-thread-${Math.floor(
                Math.random() * 90000 + 10000
              )}.`,
              `[${new Date().toLocaleTimeString()}] [TriggerNode] Evaluated condition \`${activeWorkflow.nodes[0]?.config.targetMetric || 'PSI'}\` = 0.284. Branch triggered.`,
              `[${new Date().toLocaleTimeString()}] [AgentWorker] Generated state patch: \`{ valAccuracy: 0.948, retrainApproved: true }\`.`,
              `[${new Date().toLocaleTimeString()}] [Router] Conditional edge \`rocAuc >= 0.90\` evaluated to TRUE. Routing to Deploy node.`,
              `[${new Date().toLocaleTimeString()}] [Checkpointer] Persisted thread state to Postgres saver successfully.`,
              ...wf.executionLogs,
            ],
          };
        })
      );

      if (onTriggerPipeline) {
        onTriggerPipeline();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsExecuting(false);
    }
  };

  // Generate LangGraph Python script code
  const generateLangGraphCode = (): string => {
    return `from typing import Annotated, TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.postgres import PostgresSaver
from langchain_google_genai import ChatGoogleGenerativeAI

# Define LangGraph State Schema
class PipelineState(TypedDict):
    drift_detected: bool
    psi_score: float
    dataset_uri: str
    roc_auc: float
    retrain_approved: bool
    canary_percent: int

# Initialize Gemini LLM Engine
llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash", temperature=0.2)

# Define Autonomous Node Handlers
def data_sanitizer_node(state: PipelineState):
    print(f"[Agent] Inspecting dataset snapshot: {state.get('dataset_uri')}")
    # Run automated Great Expectations validation
    return {"cleaned_rows": 1420000, "missing_cells_ratio": 0.001}

def ray_retrain_worker_node(state: PipelineState):
    print("[RayWorker] Spawning distributed PyTorch GPU training job...")
    return {"artifact_uri": "s3://nexusml-models/fraud-v2.2.0.pt"}

def val_eval_agent_node(state: PipelineState):
    print("[EvalAgent] Running benchmark suite against holdout set...")
    return {"roc_auc": 0.948, "f1_score": 0.921}

def quality_gate_router(state: PipelineState):
    if state.get("roc_auc", 0) >= 0.90:
        return "deploy_canary"
    return "human_approval"

# Build LangGraph Directed Acyclic Graph
builder = StateGraph(PipelineState)

# Add Nodes
builder.add_node("sanitizer", data_sanitizer_node)
builder.add_node("retrain", ray_retrain_worker_node)
builder.add_node("evaluator", val_eval_agent_node)

# Add Edges & Conditional Routing
builder.add_edge(START, "sanitizer")
builder.add_edge("sanitizer", "retrain")
builder.add_edge("retrain", "evaluator")

builder.add_conditional_edges(
    "evaluator",
    quality_gate_router,
    {
        "deploy_canary": END,
        "human_approval": END
    }
)

# Compile with Postgres Persistence Checkpointer
app = builder.compile()
print("LangGraph Autonomous Retraining Workflow Compiled Successfully!")`;
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(generateLangGraphCode());
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const getNodeIcon = (type: LangGraphNodeType) => {
    switch (type) {
      case 'trigger':
        return Zap;
      case 'agent':
        return Brain;
      case 'router':
        return GitFork;
      case 'tool':
        return Cpu;
      case 'evaluator':
        return Sparkles;
      case 'retrain_trigger':
        return RefreshCw;
      case 'approval':
        return UserCheck;
      case 'memory':
        return HardDrive;
      default:
        return Layers;
    }
  };

  const getNodeBadgeColor = (type: LangGraphNodeType) => {
    switch (type) {
      case 'trigger':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      case 'agent':
        return 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30';
      case 'router':
        return 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30';
      case 'tool':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
      case 'evaluator':
        return 'bg-purple-500/20 text-purple-300 border-purple-500/30';
      case 'retrain_trigger':
        return 'bg-teal-500/20 text-teal-300 border-teal-500/30';
      case 'approval':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/30';
      case 'memory':
        return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  return (
    <div className="space-y-5">
      {/* Top Workflow Control Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 bg-indigo-600/20 border border-indigo-500/40 rounded-xl text-indigo-400">
            <GitFork className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <select
                value={selectedWorkflowId}
                onChange={(e) => setSelectedWorkflowId(e.target.value)}
                className="bg-slate-950 font-bold text-sm text-white px-3 py-1 rounded-lg border border-slate-700 focus:outline-none focus:border-indigo-500 cursor-pointer"
              >
                {workflows.map((wf) => (
                  <option key={wf.id} value={wf.id}>
                    {wf.name}
                  </option>
                ))}
              </select>

              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                LangGraph v0.2
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">{activeWorkflow.description}</p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center space-x-2.5">
          <div className="flex items-center space-x-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setActiveTab('canvas')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'canvas'
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Graph Canvas</span>
            </button>

            <button
              onClick={() => setActiveTab('code')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'code'
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Code className="w-3.5 h-3.5" />
              <span>Python Script</span>
            </button>

            <button
              onClick={() => setActiveTab('logs')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'logs'
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Trace Logs ({activeWorkflow.executionLogs?.length || 0})</span>
            </button>
          </div>

          <button
            onClick={() => setIsAddNodeOpen(true)}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center space-x-1.5 border border-slate-700 transition-colors"
          >
            <Plus className="w-3.5 h-3.5 text-indigo-400" />
            <span>Add Node</span>
          </button>

          <button
            onClick={handleRunWorkflow}
            disabled={isExecuting}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center space-x-2 shadow-lg shadow-emerald-600/20 transition-all border border-emerald-400/30 active:scale-95 disabled:opacity-50"
          >
            {isExecuting ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Play className="w-3.5 h-3.5 fill-current" />
            )}
            <span>{isExecuting ? 'Executing StateGraph...' : 'Run LangGraph Execution'}</span>
          </button>
        </div>
      </div>

      {/* Main Work Area based on Active Tab */}
      {activeTab === 'canvas' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Visual Interactive Canvas (8 Cols) */}
          <div className="lg:col-span-8 bg-slate-900/90 rounded-2xl border border-slate-800 p-5 min-h-[540px] flex flex-col justify-between relative overflow-hidden">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 z-10">
              <div className="flex items-center space-x-2 text-xs font-mono">
                <span className="text-slate-500 font-bold uppercase">State Schema Keys:</span>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {Object.keys(activeWorkflow.stateSchema).map((key) => (
                    <span
                      key={key}
                      className="px-2 py-0.5 rounded bg-slate-950 text-indigo-300 border border-indigo-500/30 text-[10px]"
                    >
                      {key}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex items-center space-x-2 text-[11px] font-mono text-slate-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>StateSaver Active (Postgres)</span>
              </div>
            </div>

            {/* Nodes Visual Workflow Diagram */}
            <div className="py-8 my-auto overflow-x-auto">
              <div className="flex items-center space-x-4 min-w-max px-2 py-4">
                {activeWorkflow.nodes.map((node, idx) => {
                  const isSelected = selectedNode?.id === node.id;
                  const Icon = getNodeIcon(node.type);
                  const badgeColor = getNodeBadgeColor(node.type);

                  return (
                    <React.Fragment key={node.id}>
                      <div
                        onClick={() => handleSelectNode(node.id)}
                        className={`group relative p-4 rounded-2xl border transition-all cursor-pointer w-52 flex flex-col justify-between shadow-xl ${
                          isSelected
                            ? 'bg-slate-800 border-indigo-500 ring-2 ring-indigo-500/50 scale-105 z-20'
                            : 'bg-slate-950/90 border-slate-800 hover:border-slate-700 hover:scale-102'
                        }`}
                      >
                        {/* Node Header */}
                        <div className="flex items-center justify-between">
                          <div className={`p-1.5 rounded-lg border ${badgeColor}`}>
                            <Icon className="w-4 h-4" />
                          </div>

                          <div className="flex items-center space-x-1">
                            <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-full border ${badgeColor}`}>
                              {node.type.toUpperCase()}
                            </span>

                            {activeWorkflow.nodes.length > 2 && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteNode(node.id);
                                }}
                                className="opacity-0 group-hover:opacity-100 p-1 text-slate-500 hover:text-red-400 transition-opacity"
                                title="Delete node"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Node Label & Subtitle */}
                        <div className="mt-3">
                          <h4 className="text-xs font-bold text-white leading-snug">{node.label}</h4>
                          <p className="text-[10px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                            {node.description}
                          </p>
                        </div>

                        {/* Config Summary Pill */}
                        <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono text-slate-400">
                          <span className="text-indigo-400 truncate max-w-[110px]">
                            {node.config.model || node.config.toolName || node.config.condition || 'Configured'}
                          </span>
                          {node.status === 'completed' ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          ) : node.status === 'running' ? (
                            <div className="w-3.5 h-3.5 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin shrink-0" />
                          ) : (
                            <Clock className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                          )}
                        </div>
                      </div>

                      {/* Edge Arrow Connector */}
                      {idx < activeWorkflow.nodes.length - 1 && (
                        <div className="flex flex-col items-center justify-center shrink-0 space-y-1">
                          <div className="w-6 h-0.5 bg-gradient-to-r from-indigo-500 to-cyan-400 relative">
                            <ArrowRight className="w-3.5 h-3.5 text-cyan-400 absolute -right-2 -top-1.5" />
                          </div>
                          {activeWorkflow.edges[idx]?.label && (
                            <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-950 text-cyan-300 border border-cyan-500/30">
                              {activeWorkflow.edges[idx].label}
                            </span>
                          )}
                        </div>
                      )}
                    </React.Fragment>
                  );
                })}
              </div>
            </div>

            {/* Bottom State Inspector Summary Bar */}
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
              <div className="flex items-center space-x-2">
                <Brain className="w-4 h-4 text-purple-400" />
                <span className="text-slate-300 font-bold">Latest Graph Output:</span>
                <span className="text-emerald-400">
                  {selectedNode?.outputState ? JSON.stringify(selectedNode.outputState) : 'Ready for execution run'}
                </span>
              </div>

              {onOpenCopilotWithContext && (
                <button
                  onClick={() =>
                    onOpenCopilotWithContext(
                      `Analyze LangGraph workflow "${activeWorkflow.name}". Suggest optimizations for state memory persistence and agent prompt tuning.`
                    )
                  }
                  className="px-2.5 py-1 rounded-lg bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30 text-[11px] font-bold flex items-center space-x-1.5 transition-colors"
                >
                  <Sparkles className="w-3 h-3 text-yellow-300" />
                  <span>Ask Copilot to Audit Flow</span>
                </button>
              )}
            </div>
          </div>

          {/* Selected Node Inspector Panel (4 Cols) */}
          <div className="lg:col-span-4 bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2">
                <Settings className="w-4 h-4 text-indigo-400" />
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                  Node Inspector: {selectedNode?.label}
                </h3>
              </div>

              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                {selectedNode?.type}
              </span>
            </div>

            {selectedNode ? (
              <div className="space-y-4 text-xs">
                <div>
                  <label className="text-[11px] font-mono text-slate-400 uppercase font-bold">Node Name</label>
                  <input
                    type="text"
                    value={selectedNode.label}
                    onChange={(e) => handleUpdateNodeLabel(e.target.value)}
                    className="w-full bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 text-white font-bold focus:outline-none focus:border-indigo-500 mt-1"
                  />
                </div>

                {/* Conditional Fields based on Node Type */}
                {selectedNode.type === 'agent' || selectedNode.type === 'evaluator' ? (
                  <>
                    <div>
                      <label className="text-[11px] font-mono text-slate-400 uppercase font-bold">LLM Model Engine</label>
                      <select
                        value={selectedNode.config.model || 'gemini-1.5-flash'}
                        onChange={(e) => handleUpdateNodeConfig('model', e.target.value)}
                        className="w-full bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 text-slate-200 focus:outline-none focus:border-indigo-500 mt-1"
                      >
                        <option value="gemini-1.5-flash">Google Gemini 1.5 Flash (Fast)</option>
                        <option value="gemini-1.5-pro">Google Gemini 1.5 Pro (Deep Reasoning)</option>
                        <option value="gpt-4o">OpenAI GPT-4o</option>
                        <option value="claude-3-5-sonnet">Anthropic Claude 3.5 Sonnet</option>
                        <option value="vllm-deepseek-r1">vLLM Local DeepSeek-R1</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[11px] font-mono text-slate-400 uppercase font-bold">Agent System Prompt</label>
                      <textarea
                        value={selectedNode.config.prompt || ''}
                        onChange={(e) => handleUpdateNodeConfig('prompt', e.target.value)}
                        rows={4}
                        className="w-full bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-xs text-indigo-200 focus:outline-none focus:border-indigo-500 leading-relaxed mt-1"
                      />
                    </div>
                  </>
                ) : null}

                {selectedNode.type === 'router' ? (
                  <div>
                    <label className="text-[11px] font-mono text-slate-400 uppercase font-bold">Routing Condition</label>
                    <input
                      type="text"
                      value={selectedNode.config.condition || ''}
                      onChange={(e) => handleUpdateNodeConfig('condition', e.target.value)}
                      placeholder="state.rocAuc >= 0.90"
                      className="w-full bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 font-mono text-cyan-300 text-xs focus:outline-none focus:border-cyan-500 mt-1"
                    />
                  </div>
                ) : null}

                {selectedNode.type === 'trigger' ? (
                  <div>
                    <label className="text-[11px] font-mono text-slate-400 uppercase font-bold">Target Metric & Threshold</label>
                    <div className="grid grid-cols-2 gap-2 mt-1">
                      <input
                        type="text"
                        value={selectedNode.config.targetMetric || 'PSI'}
                        onChange={(e) => handleUpdateNodeConfig('targetMetric', e.target.value)}
                        className="bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 font-mono text-xs text-amber-300"
                        placeholder="Metric Name"
                      />
                      <input
                        type="number"
                        step="0.01"
                        value={selectedNode.config.metricThreshold || 0.25}
                        onChange={(e) => handleUpdateNodeConfig('metricThreshold', parseFloat(e.target.value))}
                        className="bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 font-mono text-xs text-amber-300"
                        placeholder="Threshold"
                      />
                    </div>
                  </div>
                ) : null}

                {selectedNode.type === 'approval' ? (
                  <div>
                    <label className="text-[11px] font-mono text-slate-400 uppercase font-bold">Approval Role Gate</label>
                    <select
                      value={selectedNode.config.approvalRole || 'Lead MLOps Engineer'}
                      onChange={(e) => handleUpdateNodeConfig('approvalRole', e.target.value)}
                      className="w-full bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 text-slate-200 focus:outline-none focus:border-indigo-500 mt-1"
                    >
                      <option value="Lead MLOps Engineer">Lead MLOps Engineer</option>
                      <option value="Compliance Officer">Compliance Officer</option>
                      <option value="Auto Policy Approval">Auto Policy Approval</option>
                    </select>
                  </div>
                ) : null}

                <div>
                  <label className="text-[11px] font-mono text-slate-400 uppercase font-bold">Max Retries & Fault Tolerance</label>
                  <input
                    type="number"
                    value={selectedNode.config.maxRetries || 3}
                    onChange={(e) => handleUpdateNodeConfig('maxRetries', parseInt(e.target.value) || 1)}
                    className="w-full bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 font-mono text-xs text-slate-200 mt-1"
                  />
                </div>

                {/* State Patch Output Viewer */}
                <div className="pt-3 border-t border-slate-800 space-y-2">
                  <span className="text-[11px] font-mono text-slate-400 uppercase font-bold">Node Output State</span>
                  <pre className="bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-[11px] text-emerald-400 overflow-x-auto">
                    {JSON.stringify(selectedNode.outputState || {}, null, 2)}
                  </pre>
                </div>
              </div>
            ) : (
              <div className="text-slate-500 italic py-10 text-center">Select a node to inspect parameters</div>
            )}
          </div>
        </div>
      )}

      {/* Code Script View */}
      {activeTab === 'code' && (
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <FileCode className="w-4 h-4 text-emerald-400" />
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                Generated LangGraph Python Execution Script
              </h3>
            </div>

            <button
              onClick={handleCopyCode}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 font-mono border border-slate-700 transition-colors"
            >
              {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
              <span>{copiedCode ? 'Copied' : 'Copy Python Script'}</span>
            </button>
          </div>

          <pre className="bg-slate-950 p-5 rounded-xl border border-slate-800 font-mono text-xs text-indigo-200 leading-relaxed overflow-x-auto">
            {generateLangGraphCode()}
          </pre>
        </div>
      )}

      {/* Execution Trace Logs View */}
      {activeTab === 'logs' && (
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <Terminal className="w-4 h-4 text-cyan-400" />
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                LangGraph StateGraph Execution Trace Console
              </h3>
            </div>

            <span className="text-xs font-mono text-emerald-400 font-bold">
              Status: {activeWorkflow.status.toUpperCase()}
            </span>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs space-y-2 min-h-[300px]">
            {activeWorkflow.executionLogs && activeWorkflow.executionLogs.length > 0 ? (
              activeWorkflow.executionLogs.map((log, idx) => (
                <div key={idx} className="flex items-start space-x-2">
                  <span className="text-slate-600 select-none">{idx + 1}.</span>
                  <span
                    className={
                      log.includes('[TriggerNode]')
                        ? 'text-amber-300 font-semibold'
                        : log.includes('[RayWorker]') || log.includes('[RetrainTool]')
                        ? 'text-emerald-400 font-semibold'
                        : log.includes('[Router]')
                        ? 'text-cyan-300'
                        : 'text-slate-300'
                    }
                  >
                    {log}
                  </span>
                </div>
              ))
            ) : (
              <div className="text-slate-500 italic py-10 text-center">No trace logs generated yet. Click "Run LangGraph Execution".</div>
            )}
          </div>
        </div>
      )}

      {/* Modal: Add Node */}
      {isAddNodeOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-indigo-400" />
                Add LangGraph State Node
              </h3>
              <button
                onClick={() => setIsAddNodeOpen(false)}
                className="text-slate-400 hover:text-white text-xs font-mono"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-[11px] font-mono text-slate-400 uppercase font-bold">Node Label</label>
                <input
                  type="text"
                  value={newNodeLabel}
                  onChange={(e) => setNewNodeLabel(e.target.value)}
                  placeholder="e.g. Model Evaluation Agent"
                  className="w-full bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 text-white focus:outline-none focus:border-indigo-500 mt-1"
                />
              </div>

              <div>
                <label className="text-[11px] font-mono text-slate-400 uppercase font-bold">Node Type</label>
                <select
                  value={newNodeType}
                  onChange={(e) => setNewNodeType(e.target.value as LangGraphNodeType)}
                  className="w-full bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 text-slate-200 focus:outline-none focus:border-indigo-500 mt-1"
                >
                  <option value="agent">Agent Worker (LLM Guided)</option>
                  <option value="evaluator">Validation & RAGAS Evaluator Agent</option>
                  <option value="retrain_trigger">Retraining Trigger Tool</option>
                  <option value="router">Conditional Router</option>
                  <option value="trigger">Event Trigger Hook</option>
                  <option value="approval">Human-in-the-Loop Approval Gate</option>
                  <option value="memory">State Memory Saver</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end space-x-2 pt-3 border-t border-slate-800">
              <button
                onClick={() => setIsAddNodeOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleAddNode}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow"
              >
                Insert Node
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
