import React, { useState, useEffect } from 'react';
import {
  GitFork,
  Play,
  CheckCircle2,
  Clock,
  XCircle,
  Terminal,
  Sparkles,
  ArrowRight,
  RefreshCw,
  Copy,
  Check,
  Server,
  Layers,
  Brain,
  Download,
  CheckSquare,
  Square,
  Trash2,
  RotateCcw,
  StopCircle,
} from 'lucide-react';
import { MlPipelineRun, PipelineStep, PipelineStepStatus } from '../../types/mlops';
import { GitHubActionsStudio } from './GitHubActionsStudio';
import { LangGraphWorkflowBuilder } from './LangGraphWorkflowBuilder';
import { exportToCSV } from '../../utils/exportUtils';
import { useAlertCenter } from '../../context/AlertCenterContext';

interface PipelineViewProps {
  pipelineRuns: MlPipelineRun[];
  onTriggerPipeline: () => void;
  onOpenCopilotWithContext: (prompt: string) => void;
  onOpenExportModal?: (context?: string) => void;
}

export const PipelineView: React.FC<PipelineViewProps> = ({
  pipelineRuns,
  onTriggerPipeline,
  onOpenCopilotWithContext,
  onOpenExportModal,
}) => {
  const { addAlert } = useAlertCenter();

  const [activeTab, setActiveTab] = useState<'dag' | 'langgraph' | 'github'>('langgraph');
  const [runList, setRunList] = useState<MlPipelineRun[]>(pipelineRuns);
  const [selectedRunIds, setSelectedRunIds] = useState<string[]>([]);

  useEffect(() => {
    setRunList(pipelineRuns);
  }, [pipelineRuns]);

  const [selectedRun, setSelectedRun] = useState<MlPipelineRun>(pipelineRuns[0] || runList[0]);
  const [selectedStep, setSelectedStep] = useState<PipelineStep>(
    (pipelineRuns[0] || runList[0])?.steps[3] || (pipelineRuns[0] || runList[0])?.steps[0]
  );
  const [copiedLogs, setCopiedLogs] = useState(false);

  const activeSelectedRun = runList.find((r) => r.id === selectedRun?.id) || runList[0];

  const toggleSelectRun = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSelectedRunIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSelectAllRuns = () => {
    if (selectedRunIds.length === runList.length && runList.length > 0) {
      setSelectedRunIds([]);
    } else {
      setSelectedRunIds(runList.map((r) => r.id));
    }
  };

  const handleBatchStatusUpdate = (newStatus: PipelineStepStatus) => {
    if (selectedRunIds.length === 0) return;

    setRunList((prev) =>
      prev.map((r) => {
        if (selectedRunIds.includes(r.id)) {
          return {
            ...r,
            status: newStatus,
            steps: r.steps.map((s) => ({ ...s, status: newStatus })),
          };
        }
        return r;
      })
    );

    addAlert({
      type: 'system',
      severity: newStatus === 'failed' ? 'warning' : 'info',
      title: `Batch Pipeline Status Update (${selectedRunIds.length} Runs)`,
      message: `Set status of ${selectedRunIds.length} selected pipeline runs to '${newStatus.toUpperCase()}'.`,
      source: 'Pipeline Batch Manager',
    });

    setSelectedRunIds([]);
  };

  const handleBatchDelete = () => {
    if (selectedRunIds.length === 0) return;
    const count = selectedRunIds.length;

    setRunList((prev) => prev.filter((r) => !selectedRunIds.includes(r.id)));

    addAlert({
      type: 'system',
      severity: 'warning',
      title: `Batch Archived (${count} Pipeline Runs)`,
      message: `Archived ${count} selected pipeline execution runs from active view.`,
      source: 'Pipeline Batch Manager',
    });

    setSelectedRunIds([]);
  };

  const handleCopyLogs = () => {
    if (selectedStep?.logs) {
      navigator.clipboard.writeText(selectedStep.logs.join('\n'));
      setCopiedLogs(true);
      setTimeout(() => setCopiedLogs(false), 2000);
    }
  };

  return (
    <div className="p-6 space-y-6 text-slate-100 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 p-5 rounded-2xl border border-slate-800">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center gap-2">
            <GitFork className="w-5 h-5 text-indigo-400" />
            Automated ML Pipelines, LangGraph Agent Flow & CI/CD Engine
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            LangGraph autonomous agent sequences for automated retraining/validation, Kubeflow DAGs, and GitHub Actions CI/CD workflows.
          </p>
        </div>

        {/* Tab Switch & Export */}
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
            <button
              onClick={() => setActiveTab('langgraph')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
                activeTab === 'langgraph'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Brain className="w-3.5 h-3.5 text-purple-300" />
              <span>LangGraph Agent Builder</span>
            </button>

            <button
              onClick={() => setActiveTab('dag')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
                activeTab === 'dag'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <GitFork className="w-3.5 h-3.5" />
              <span>Kubeflow / Airflow DAGs</span>
            </button>

            <button
              onClick={() => setActiveTab('github')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
                activeTab === 'github'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Server className="w-3.5 h-3.5" />
              <span>GitHub Actions CI/CD</span>
            </button>
          </div>

          <button
            onClick={() => {
              if (onOpenExportModal) {
                onOpenExportModal('pipeline_runs');
              } else {
                exportToCSV(
                  pipelineRuns.map((p) => ({
                    id: p.id,
                    pipelineName: p.pipelineName,
                    trigger: p.trigger,
                    status: p.status,
                    durationSeconds: p.durationSeconds,
                    startedAt: p.startedAt,
                    stepsCount: p.steps.length,
                  })),
                  'pipeline_runs_export.csv'
                );
              }
            }}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 border border-indigo-500/30 font-bold text-xs flex items-center space-x-1.5 transition-colors shadow-sm shrink-0"
            title="Export Pipeline Runs Data"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            <span>Export Data</span>
          </button>
        </div>
      </div>

      {activeTab === 'langgraph' ? (
        <LangGraphWorkflowBuilder
          onOpenCopilotWithContext={onOpenCopilotWithContext}
          onTriggerPipeline={onTriggerPipeline}
        />
      ) : activeTab === 'github' ? (
        <GitHubActionsStudio
          onTriggerPipeline={onTriggerPipeline}
          onOpenCopilotWithContext={onOpenCopilotWithContext}
        />
      ) : (
        <div className="space-y-6">
          {/* Action Trigger & Multi-Select Batch Bar */}
          <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 space-y-3 font-mono text-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center space-x-3">
                <button
                  onClick={handleSelectAllRuns}
                  className="flex items-center space-x-2 text-slate-300 hover:text-white font-bold transition-colors"
                >
                  {selectedRunIds.length === runList.length && runList.length > 0 ? (
                    <CheckSquare className="w-4 h-4 text-indigo-400" />
                  ) : (
                    <Square className="w-4 h-4 text-slate-500" />
                  )}
                  <span>
                    {selectedRunIds.length > 0
                      ? `${selectedRunIds.length} Runs Selected`
                      : 'Select All Pipeline Runs'}
                  </span>
                </button>

                {selectedRunIds.length > 0 && (
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleBatchStatusUpdate('running')}
                      className="px-2.5 py-1 rounded bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 border border-indigo-500/40 text-[10px] font-bold flex items-center gap-1"
                      title="Re-run / Retry Selected Pipelines"
                    >
                      <RotateCcw className="w-3 h-3 text-indigo-400" />
                      <span>Re-Run</span>
                    </button>

                    <button
                      onClick={() => handleBatchStatusUpdate('succeeded')}
                      className="px-2.5 py-1 rounded bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold flex items-center gap-1"
                      title="Mark Selected as Succeeded"
                    >
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      <span>Mark Passed</span>
                    </button>

                    <button
                      onClick={() => handleBatchStatusUpdate('failed')}
                      className="px-2.5 py-1 rounded bg-amber-600/30 hover:bg-amber-600/50 text-amber-300 border border-amber-500/40 text-[10px] font-bold flex items-center gap-1"
                      title="Cancel / Stop Selected"
                    >
                      <StopCircle className="w-3 h-3 text-amber-400" />
                      <span>Stop</span>
                    </button>

                    <button
                      onClick={handleBatchDelete}
                      className="px-2.5 py-1 rounded bg-rose-600/30 hover:bg-rose-600/50 text-rose-300 border border-rose-500/40 text-[10px] font-bold flex items-center gap-1"
                      title="Archive Selected Pipeline Runs"
                    >
                      <Trash2 className="w-3 h-3 text-rose-400" />
                      <span>Archive</span>
                    </button>
                  </div>
                )}
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={onTriggerPipeline}
                  className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center space-x-1.5 shadow transition-all border border-emerald-400/30 active:scale-95"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Trigger Run</span>
                </button>

                <button
                  onClick={() =>
                    onOpenCopilotWithContext(
                      `Analyze pipeline logs for step ${selectedStep?.name || 'current'} in run ${activeSelectedRun?.id || 'run-1'}. Suggest optimizations.`
                    )
                  }
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center space-x-1.5 transition-all border border-slate-700"
                >
                  <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
                  <span>Copilot Debug</span>
                </button>
              </div>
            </div>

            {/* Pipeline Execution Runs Selector Strip */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2.5 pt-2 border-t border-slate-800">
              {runList.map((run) => {
                const isSelected = activeSelectedRun?.id === run.id;
                const isChecked = selectedRunIds.includes(run.id);

                return (
                  <div
                    key={run.id}
                    onClick={() => {
                      setSelectedRun(run);
                      if (run.steps && run.steps[0]) {
                        setSelectedStep(run.steps[0]);
                      }
                    }}
                    className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'bg-slate-800 border-indigo-500 ring-1 ring-indigo-500/50 text-white'
                        : isChecked
                        ? 'bg-indigo-950/40 border-indigo-500/40'
                        : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-800/60 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center space-x-2 truncate">
                      <button
                        onClick={(e) => toggleSelectRun(run.id, e)}
                        className="text-slate-400 hover:text-white transition-colors shrink-0"
                      >
                        {isChecked ? (
                          <CheckSquare className="w-3.5 h-3.5 text-indigo-400" />
                        ) : (
                          <Square className="w-3.5 h-3.5 text-slate-600" />
                        )}
                      </button>

                      <div className="truncate">
                        <span className="font-bold block truncate text-[11px]">{run.pipelineName}</span>
                        <span className="text-[9px] text-slate-400 block truncate font-sans">
                          {run.id} • {run.triggerType}
                        </span>
                      </div>
                    </div>

                    <span
                      className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase shrink-0 ${
                        run.status === 'succeeded'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : run.status === 'running'
                          ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                          : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                      }`}
                    >
                      {run.status}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Interactive DAG Graph Visualizer */}
          <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-mono text-indigo-400 uppercase font-bold">Selected DAG Execution</span>
                <h2 className="text-sm font-bold text-white">{selectedRun.pipelineName}</h2>
              </div>

              <div className="flex items-center space-x-3 text-xs font-mono">
                <span className="text-slate-400">Trigger: <strong className="text-slate-200">{selectedRun.triggerType}</strong></span>
                <span className="text-slate-400">Status: <strong className="text-emerald-400 uppercase">{selectedRun.status}</strong></span>
              </div>
            </div>

            {/* DAG Step Nodes horizontally linked */}
            <div className="overflow-x-auto py-4">
              <div className="flex items-center space-x-3 min-w-max">
                {selectedRun.steps.map((step, idx) => {
                  const isSelected = selectedStep.id === step.id;
                  return (
                    <React.Fragment key={step.id}>
                      <div
                        onClick={() => setSelectedStep(step)}
                        className={`p-3.5 rounded-xl border transition-all cursor-pointer w-48 flex flex-col justify-between ${
                          isSelected
                            ? 'bg-slate-800 border-indigo-500 ring-2 ring-indigo-500/40 shadow-xl'
                            : step.status === 'succeeded'
                            ? 'bg-slate-950/80 border-slate-800 hover:border-slate-700'
                            : step.status === 'running'
                            ? 'bg-indigo-950/40 border-indigo-500/60 shadow-md'
                            : 'bg-slate-950/40 border-slate-900 opacity-60'
                        }`}
                      >
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-mono text-[10px] font-bold text-slate-500">Step 0{idx + 1}</span>
                          {step.status === 'succeeded' ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                          ) : step.status === 'running' ? (
                            <div className="w-4 h-4 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin" />
                          ) : step.status === 'failed' ? (
                            <XCircle className="w-4 h-4 text-red-400" />
                          ) : (
                            <Clock className="w-4 h-4 text-slate-600" />
                          )}
                        </div>

                        <div className="mt-2">
                          <h4 className="text-xs font-bold text-slate-200 line-clamp-1">{step.name}</h4>
                          <p className="text-[10px] font-mono text-slate-400 mt-1 uppercase">{step.type}</p>
                        </div>

                        <div className="mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-500 font-mono">
                          <span>{step.durationSec ? `${step.durationSec}s` : step.status}</span>
                          <span className="text-indigo-400">{step.logs ? `${step.logs.length} logs` : '0 logs'}</span>
                        </div>
                      </div>

                      {idx < selectedRun.steps.length - 1 && (
                        <ArrowRight className="w-4 h-4 text-slate-600 shrink-0" />
                      )}
                    </React.Fragment>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Selected Step Logs Console */}
          <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center space-x-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                  Step Logs: {selectedStep.name}
                </h3>
              </div>

              <button
                onClick={handleCopyLogs}
                className="flex items-center space-x-1.5 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[11px] text-slate-300 font-mono border border-slate-700 transition-colors"
              >
                {copiedLogs ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                <span>{copiedLogs ? 'Copied' : 'Copy Logs'}</span>
              </button>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs text-slate-300 space-y-1.5 min-h-[160px] max-h-[300px] overflow-y-auto">
              {selectedStep.logs && selectedStep.logs.length > 0 ? (
                selectedStep.logs.map((logLine, index) => (
                  <div key={index} className="flex space-x-2 hover:bg-slate-900/50 p-0.5 rounded">
                    <span className="text-slate-600 select-none w-8 text-right font-bold">{index + 1}</span>
                    <span className={logLine.includes('[SUCCESS]') ? 'text-emerald-400 font-semibold' : logLine.includes('[INFO]') ? 'text-indigo-300' : 'text-slate-300'}>
                      {logLine}
                    </span>
                  </div>
                ))
              ) : (
                <div className="text-slate-500 italic py-8 text-center">
                  Step is pending execution or has produced no stdouts yet.
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
