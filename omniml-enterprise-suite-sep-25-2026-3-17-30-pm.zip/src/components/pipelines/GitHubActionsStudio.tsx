import React, { useState } from 'react';
import {
  GitFork,
  Play,
  CheckCircle2,
  Clock,
  Terminal,
  Copy,
  Check,
  Download,
  AlertTriangle,
  RefreshCw,
  Box,
  Layers,
  Sparkles,
  ShieldCheck,
  Server,
} from 'lucide-react';

interface GitHubActionsStudioProps {
  onTriggerPipeline?: () => void;
  onOpenCopilotWithContext?: (prompt: string) => void;
}

export const GitHubActionsStudio: React.FC<GitHubActionsStudioProps> = ({
  onTriggerPipeline,
  onOpenCopilotWithContext,
}) => {
  const [activeTab, setActiveTab] = useState<'workflow' | 'live-run' | 'matrix'>('workflow');
  const [copiedYaml, setCopiedYaml] = useState(false);
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionLogs, setExecutionLogs] = useState<string[]>([
    '[INFO] [00:00:01] Initializing GitHub Actions runner: ubuntu-latest-gpu-cuda12.1',
    '[INFO] [00:00:03] git checkout refs/heads/main (commit hash e4a89bc)',
    '[INFO] [00:00:07] Running ruff linting & pytest unit test suite... Passed (142 tests)',
    '[INFO] [00:00:12] dvc pull -r origin_s3_storage... Downloaded 4.2GB feature parquet files',
    '[INFO] [00:00:25] Optuna hyperparameter search on XGBoost framework... Selected best trial #42',
    '[INFO] [00:00:45] MLflow run logged: run_id=mlf_9842a_xgboost, ROC-AUC=0.989',
    '[INFO] [00:00:52] Containerizing Docker image: 844883108369.dkr.ecr.us-east-1.amazonaws.com/mlops/fraud-scoring:v2.1.0-champion',
    '[INFO] [00:01:10] helm upgrade --install fraud-service ./helm/mlops-endpoint --namespace ml-serving',
    '[SUCCESS] [00:01:25] Rolling deployment completed with 0 downtime. All 8 pods healthy.',
  ]);

  const workflowYaml = `# GitHub Actions CI/CD Pipeline for Enterprise MLOps
name: MLOps Automated Training, Containerization & Helm Rolling Deploy

on:
  push:
    branches: [ main, release/* ]
  pull_request:
    branches: [ main ]
  workflow_dispatch:
    inputs:
      force_retrain:
        description: 'Bypass cache and force full AutoML retrain'
        required: false
        default: 'false'
      target_env:
        description: 'Deployment environment'
        required: true
        default: 'production'

jobs:
  lint-and-test:
    name: 1. Code Quality & Unit Tests
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Set up Python 3.11
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - name: Install dependencies & Lint
        run: |
          pip install ruff pytest
          ruff check src/
          pytest tests/unit/

  dvc-and-mlflow-train:
    name: 2. DVC Data Pull & MLflow Training
    needs: lint-and-test
    runs-on: ubuntu-latest-gpu
    steps:
      - uses: actions/checkout@v4
      - name: Pull Dataset via DVC
        run: |
          pip install dvc[s3] mlflow xgboost optuna
          dvc pull -r origin_s3_storage
      - name: Run AutoML Training Pipeline
        env:
          MLFLOW_TRACKING_URI: https://mlflow.mlops.enterprise.ai
          GEMINI_API_KEY: \${{ secrets.GEMINI_API_KEY }}
        run: |
          python src/training/train_optuna.py --framework xgboost --dataset fraud_detection_v2

  container-build-and-push:
    name: 3. Docker Containerization & Security Scan
    needs: dvc-and-mlflow-train
    runs-on: ubuntu-latest
    steps:
      - name: Build Docker Image
        run: |
          docker build -t 844883108369.dkr.ecr.us-east-1.amazonaws.com/mlops/fraud-scoring:\${{ github.sha }} .
      - name: Vulnerability Scan (Trivy)
        uses: aquasecurity/trivy-action@master
        with:
          image-ref: '844883108369.dkr.ecr.us-east-1.amazonaws.com/mlops/fraud-scoring:\${{ github.sha }}'
          exit-code: '0'
          severity: 'CRITICAL,HIGH'

  helm-k8s-deploy:
    name: 4. Helm Upgrade & Kubernetes Rolling Deploy
    needs: container-build-and-push
    runs-on: ubuntu-latest
    steps:
      - name: Set up kubectl & Helm
        uses: azure/setup-helm@v3
      - name: Deploy to Kubernetes Cluster
        run: |
          helm upgrade --install fraud-service ./helm/mlops-endpoint \\
            --namespace ml-serving \\
            --set image.tag=\${{ github.sha }} \\
            --set autoscaling.enabled=true
`;

  const handleCopyYaml = () => {
    navigator.clipboard.writeText(workflowYaml);
    setCopiedYaml(true);
    setTimeout(() => setCopiedYaml(false), 2000);
  };

  const handleRunWorkflow = () => {
    setIsExecuting(true);
    onTriggerPipeline?.();
    const newLog = `[INFO] [${new Date().toISOString().substring(11, 19)}] Manually dispatched CI/CD workflow run #gh-run-${Date.now().toString().slice(-4)} from branch 'main'...`;
    setExecutionLogs((prev) => [newLog, ...prev]);

    setTimeout(() => {
      setIsExecuting(false);
      setExecutionLogs((prev) => [
        `[SUCCESS] [${new Date().toISOString().substring(11, 19)}] GitHub Actions Workflow completed successfully. Target image deployed to Kubernetes.`,
        ...prev,
      ]);
    }, 2000);
  };

  return (
    <div className="space-y-6">
      {/* Navigation */}
      <div className="flex items-center justify-between bg-slate-900 border border-slate-800 rounded-xl p-2 shadow-lg">
        <div className="flex items-center space-x-2">
          {[
            { id: 'workflow', label: '.github/workflows/mlops.yml', icon: GitFork },
            { id: 'live-run', label: 'Live Workflow Execution Logs', icon: Terminal },
            { id: 'matrix', label: 'Runner Matrix & CUDA Specs', icon: Server },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                    : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        <button
          onClick={handleRunWorkflow}
          disabled={isExecuting}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center space-x-2 shadow-lg shadow-emerald-600/20 transition-all border border-emerald-400/30 disabled:opacity-50"
        >
          <Play className={`w-3.5 h-3.5 fill-current ${isExecuting ? 'animate-pulse' : ''}`} />
          <span>{isExecuting ? 'Dispatching GitHub Action...' : 'Dispatch Workflow Run'}</span>
        </button>
      </div>

      {/* TAB 1: WORKFLOW YAML */}
      {activeTab === 'workflow' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <GitFork className="w-4 h-4 text-emerald-400" />
                GitHub Actions Declarative Pipeline Manifest
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Automated continuous integration and continuous deployment specification with DVC, MLflow, Docker, and Helm stages.
              </p>
            </div>

            <button
              onClick={handleCopyYaml}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700"
            >
              {copiedYaml ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedYaml ? 'Copied Workflow!' : 'Copy Workflow YAML'}</span>
            </button>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs text-slate-200 overflow-x-auto max-h-[500px]">
            <pre>{workflowYaml}</pre>
          </div>
        </div>
      )}

      {/* TAB 2: LIVE EXECUTION LOGS */}
      {activeTab === 'live-run' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Terminal className="w-4 h-4 text-indigo-400" />
              GitHub Actions Live Runner Stream Log
            </h3>
            <span className="text-xs font-mono text-emerald-400 font-bold bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
              Runner: ubuntu-latest-gpu (Active)
            </span>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs text-slate-300 space-y-2 max-h-[450px] overflow-y-auto">
            {executionLogs.map((log, idx) => (
              <div
                key={idx}
                className={`py-1 border-b border-slate-900/60 ${
                  log.includes('SUCCESS')
                    ? 'text-emerald-400 font-bold'
                    : log.includes('INFO')
                    ? 'text-slate-300'
                    : 'text-amber-400'
                }`}
              >
                {log}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: MATRIX & CUDA SPECS */}
      {activeTab === 'matrix' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Server className="w-4 h-4 text-cyan-400" />
            GitHub Self-Hosted GPU Runner Infrastructure
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <span className="text-[10px] text-slate-500 uppercase font-bold">OS Runtime</span>
              <div className="text-slate-200 font-bold">Ubuntu 22.04 LTS x86_64</div>
              <span className="text-slate-400 text-[11px]">Kernel: 6.5.0-generic</span>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <span className="text-[10px] text-slate-500 uppercase font-bold">CUDA Acceleration</span>
              <div className="text-emerald-400 font-bold">NVIDIA CUDA 12.1 + cuDNN 8.9</div>
              <span className="text-slate-400 text-[11px]">Driver Version: 535.129.03</span>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <span className="text-[10px] text-slate-500 uppercase font-bold">Runner Concurrency</span>
              <div className="text-indigo-400 font-bold">8 Matrix Workers</div>
              <span className="text-slate-400 text-[11px]">Parallel Job Execution</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
