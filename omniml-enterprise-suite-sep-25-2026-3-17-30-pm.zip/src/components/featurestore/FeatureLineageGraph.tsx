import React, { useState } from 'react';
import {
  Database,
  Layers,
  Cpu,
  ArrowRight,
  Sparkles,
  Search,
  Filter,
  RefreshCw,
  Zap,
  Info,
  CheckCircle2,
  AlertTriangle,
  Play,
  Share2,
  Maximize2,
  Shield,
  Server,
  Activity,
} from 'lucide-react';

export interface LineageNode {
  id: string;
  name: string;
  category: 'raw_dataset' | 'feature_group' | 'consuming_model';
  type: string; // e.g., 'Snowflake', 'Feast Redis', 'PyTorch Endpoint'
  freshness: string;
  ownerTeam: string;
  recordCount: string;
  driftStatus: 'Healthy' | 'Drifting' | 'Degraded';
  x: number;
  y: number;
}

export interface LineageLink {
  sourceId: string;
  targetId: string;
  label?: string;
}

const INITIAL_NODES: LineageNode[] = [
  // Raw Datasets (Column 1: X = 100)
  {
    id: 'ds-1',
    name: 'Snowflake_Txn_Raw',
    category: 'raw_dataset',
    type: 'Snowflake Table',
    freshness: '15s',
    ownerTeam: 'Data Eng',
    recordCount: '14.2M rows',
    driftStatus: 'Healthy',
    x: 100,
    y: 80,
  },
  {
    id: 'ds-2',
    name: 'Kafka_Clickstream_Stream',
    category: 'raw_dataset',
    type: 'Kafka Topic',
    freshness: '250ms',
    ownerTeam: 'Streaming Platform',
    recordCount: '4.8M events/hr',
    driftStatus: 'Healthy',
    x: 100,
    y: 220,
  },
  {
    id: 'ds-3',
    name: 'Postgres_Users_DB',
    category: 'raw_dataset',
    type: 'PostgreSQL DB',
    freshness: '1m',
    ownerTeam: 'Core Backend',
    recordCount: '1.2M users',
    driftStatus: 'Healthy',
    x: 100,
    y: 360,
  },

  // Processed Feature Groups (Column 2: X = 420)
  {
    id: 'fg-1',
    name: 'user_transaction_behavior_realtime',
    category: 'feature_group',
    type: 'Feast Online (Redis)',
    freshness: '100ms',
    ownerTeam: 'Fraud ML Team',
    recordCount: '14 Features',
    driftStatus: 'Healthy',
    x: 420,
    y: 110,
  },
  {
    id: 'fg-2',
    name: 'device_fingerprint_store',
    category: 'feature_group',
    type: 'Hopsworks Online',
    freshness: '500ms',
    ownerTeam: 'Security AI',
    recordCount: '8 Features',
    driftStatus: 'Drifting',
    x: 420,
    y: 250,
  },
  {
    id: 'fg-3',
    name: 'user_credit_profile_offline',
    category: 'feature_group',
    type: 'BigQuery / Snowflake',
    freshness: '24h',
    ownerTeam: 'Risk Modeling',
    recordCount: '22 Features',
    driftStatus: 'Healthy',
    x: 420,
    y: 380,
  },

  // Consuming ML Models & Endpoints (Column 3: X = 740)
  {
    id: 'm-1',
    name: 'Fraud_Detection_XGBoost_v2.2.0',
    category: 'consuming_model',
    type: 'Triton Serving Endpoint',
    freshness: 'Sub-ms',
    ownerTeam: 'Payments Risk',
    recordCount: '18.4k QPS',
    driftStatus: 'Healthy',
    x: 740,
    y: 90,
  },
  {
    id: 'm-2',
    name: 'Gemini_Fraud_Copilot_RAG',
    category: 'consuming_model',
    type: 'GenAI Agent Workflow',
    freshness: 'Real-time',
    ownerTeam: 'LLMOps Team',
    recordCount: '3.2k QPS',
    driftStatus: 'Healthy',
    x: 740,
    y: 220,
  },
  {
    id: 'm-3',
    name: 'Credit_Approval_LightGBM',
    category: 'consuming_model',
    type: 'SageMaker Endpoint',
    freshness: 'Batch / Daily',
    ownerTeam: 'Credit Ops',
    recordCount: '450 QPS',
    driftStatus: 'Healthy',
    x: 740,
    y: 350,
  },
];

const INITIAL_LINKS: LineageLink[] = [
  { sourceId: 'ds-1', targetId: 'fg-1', label: 'PySpark Ingestion' },
  { sourceId: 'ds-2', targetId: 'fg-1', label: 'Flink Streaming' },
  { sourceId: 'ds-2', targetId: 'fg-2', label: 'Kafka Connect' },
  { sourceId: 'ds-3', targetId: 'fg-3', label: 'dbt Batch Pipeline' },

  { sourceId: 'fg-1', targetId: 'm-1', label: 'Point-in-Time Join' },
  { sourceId: 'fg-1', targetId: 'm-2', label: 'Embedding Vector Search' },
  { sourceId: 'fg-2', targetId: 'm-1', label: 'Low Latency Read' },
  { sourceId: 'fg-2', targetId: 'm-2', label: 'RAG Context Injection' },
  { sourceId: 'fg-3', targetId: 'm-3', label: 'Offline Feature Matrix' },
];

interface FeatureLineageGraphProps {
  onOpenCopilotWithContext?: (prompt: string) => void;
}

export const FeatureLineageGraph: React.FC<FeatureLineageGraphProps> = ({
  onOpenCopilotWithContext,
}) => {
  const [nodes, setNodes] = useState<LineageNode[]>(INITIAL_NODES);
  const [links] = useState<LineageLink[]>(INITIAL_LINKS);
  const [selectedNode, setSelectedNode] = useState<LineageNode>(INITIAL_NODES[3]);
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isFlowActive, setIsFlowActive] = useState<boolean>(true);

  // Filter nodes
  const filteredNodes = nodes.filter((n) => {
    const matchesCategory = filterCategory === 'ALL' || n.category === filterCategory;
    const matchesSearch =
      n.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      n.type.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Highlight connected nodes for selected node
  const connectedNodeIds = new Set<string>([selectedNode.id]);
  links.forEach((l) => {
    if (l.sourceId === selectedNode.id) connectedNodeIds.add(l.targetId);
    if (l.targetId === selectedNode.id) connectedNodeIds.add(l.sourceId);
  });

  // Categorize selected node's upstream & downstream items
  const upstreamLinks = links.filter((l) => l.targetId === selectedNode.id);
  const downstreamLinks = links.filter((l) => l.sourceId === selectedNode.id);

  const upstreamNodes = nodes.filter((n) => upstreamLinks.some((l) => l.sourceId === n.id));
  const downstreamNodes = nodes.filter((n) => downstreamLinks.some((l) => l.targetId === n.id));

  return (
    <div className="space-y-6 text-slate-100">
      {/* Top Controls Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 p-4 rounded-2xl border border-slate-800">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 bg-indigo-600/20 border border-indigo-500/40 rounded-xl text-indigo-400">
            <Share2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              End-to-End Feature Lineage DAG (Raw Datasets → Feature Store → ML Models)
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Interactive dependency graph tracking data origin, point-in-time transformations, and downstream AI model consumers.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter nodes..."
              className="bg-slate-950 pl-8 pr-3 py-1.5 rounded-xl border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500 w-40"
            />
          </div>

          {/* Category Filter */}
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-slate-200 focus:outline-none focus:border-indigo-500"
          >
            <option value="ALL">All DAG Layers</option>
            <option value="raw_dataset">1. Raw Datasets</option>
            <option value="feature_group">2. Feature Groups</option>
            <option value="consuming_model">3. Consuming Models</option>
          </select>

          {/* Flow Animation Toggle */}
          <button
            onClick={() => setIsFlowActive(!isFlowActive)}
            className={`px-3 py-1.5 rounded-xl font-bold flex items-center space-x-1.5 border transition-all ${
              isFlowActive
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : 'bg-slate-950 text-slate-400 border-slate-800'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>{isFlowActive ? 'Live Particles ON' : 'Flow Paused'}</span>
          </button>
        </div>
      </div>

      {/* Main Split View: Interactive Force-Directed SVG Canvas (8 Cols) vs Inspector Panel (4 Cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Interactive Force-Directed SVG Lineage Canvas (8 Cols) */}
        <div className="lg:col-span-8 bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4 relative overflow-hidden">
          {/* Layer Labels Header */}
          <div className="grid grid-cols-3 gap-2 text-center text-[10px] font-mono font-bold uppercase border-b border-slate-800 pb-2">
            <span className="text-cyan-400 bg-cyan-950/30 py-1 rounded border border-cyan-500/20">
              1. Raw Source Datasets
            </span>
            <span className="text-indigo-400 bg-indigo-950/30 py-1 rounded border border-indigo-500/20">
              2. Feast Feature Groups
            </span>
            <span className="text-purple-400 bg-purple-950/30 py-1 rounded border border-purple-500/20">
              3. Consuming Models & Endpoints
            </span>
          </div>

          {/* SVG Lineage Canvas */}
          <div className="relative w-full h-[450px] bg-slate-950/90 rounded-xl border border-slate-800 overflow-hidden">
            <svg className="w-full h-full">
              <defs>
                <linearGradient id="linkGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.6" />
                  <stop offset="50%" stopColor="#6366f1" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#a855f7" stopOpacity="0.6" />
                </linearGradient>

                <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="3" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
              </defs>

              {/* Render Connection Edges / Paths */}
              {links.map((link, idx) => {
                const source = nodes.find((n) => n.id === link.sourceId);
                const target = nodes.find((n) => n.id === link.targetId);
                if (!source || !target) return null;

                const isConnectedToSelected =
                  link.sourceId === selectedNode.id || link.targetId === selectedNode.id;

                // Curved cubic bezier path calculation
                const dx = target.x - source.x;
                const controlX1 = source.x + dx * 0.5;
                const controlX2 = source.x + dx * 0.5;
                const pathD = `M ${source.x + 90} ${source.y + 25} C ${controlX1} ${source.y + 25}, ${controlX2} ${target.y + 25}, ${target.x} ${target.y + 25}`;

                return (
                  <g key={`link-${idx}`}>
                    <path
                      d={pathD}
                      fill="none"
                      stroke={isConnectedToSelected ? '#818cf8' : '#334155'}
                      strokeWidth={isConnectedToSelected ? 3 : 1.5}
                      strokeDasharray={isFlowActive && isConnectedToSelected ? '6 4' : 'none'}
                      className={isFlowActive && isConnectedToSelected ? 'animate-pulse' : ''}
                      filter={isConnectedToSelected ? 'url(#glow)' : undefined}
                    />
                  </g>
                );
              })}

              {/* Render Nodes as Interactive Cards */}
              {filteredNodes.map((node) => {
                const isSelected = selectedNode.id === node.id;
                const isConnected = connectedNodeIds.has(node.id);

                const badgeBg =
                  node.category === 'raw_dataset'
                    ? 'fill-cyan-950 stroke-cyan-500'
                    : node.category === 'feature_group'
                    ? 'fill-indigo-950 stroke-indigo-500'
                    : 'fill-purple-950 stroke-purple-500';

                return (
                  <g
                    key={node.id}
                    transform={`translate(${node.x}, ${node.y})`}
                    onClick={() => setSelectedNode(node)}
                    className="cursor-pointer transition-all duration-200"
                  >
                    {/* Outer glow ring if selected */}
                    {isSelected && (
                      <rect
                        x="-4"
                        y="-4"
                        width="188"
                        height="58"
                        rx="14"
                        fill="none"
                        stroke="#a855f7"
                        strokeWidth="2.5"
                        filter="url(#glow)"
                      />
                    )}

                    {/* Node Container Card */}
                    <rect
                      x="0"
                      y="0"
                      width="180"
                      height="50"
                      rx="12"
                      className={`${
                        isSelected
                          ? 'fill-slate-900 stroke-indigo-400'
                          : isConnected
                          ? 'fill-slate-900/90 stroke-slate-700'
                          : 'fill-slate-950/70 stroke-slate-800/80 opacity-60'
                      }`}
                      strokeWidth="1.5"
                    />

                    {/* Category Indicator Pill */}
                    <circle
                      cx="16"
                      cy="25"
                      r="6"
                      className={
                        node.category === 'raw_dataset'
                          ? 'fill-cyan-400'
                          : node.category === 'feature_group'
                          ? 'fill-indigo-400'
                          : 'fill-purple-400'
                      }
                    />

                    {/* Node Name */}
                    <text
                      x="30"
                      y="21"
                      fill="#f8fafc"
                      fontSize="11"
                      fontWeight="bold"
                      className="font-sans select-none"
                    >
                      {node.name.length > 20 ? `${node.name.slice(0, 18)}...` : node.name}
                    </text>

                    {/* Node Type & Metadata */}
                    <text x="30" y="36" fill="#94a3b8" fontSize="9" className="font-mono select-none">
                      {node.type} • {node.freshness}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Right Column: Selected Lineage Inspector Panel (4 Cols) */}
        <div className="lg:col-span-4 bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <span className="text-[10px] font-mono text-indigo-400 uppercase font-bold">Lineage Node Inspector</span>
              <h3 className="text-xs font-bold text-white">{selectedNode.name}</h3>
            </div>

            <span
              className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                selectedNode.driftStatus === 'Healthy'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
              }`}
            >
              {selectedNode.driftStatus}
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-2 font-mono text-[11px]">
              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block uppercase">Node Type</span>
                <span className="text-indigo-300 font-bold">{selectedNode.type}</span>
              </div>

              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block uppercase">Freshness SLA</span>
                <span className="text-emerald-400 font-bold">{selectedNode.freshness}</span>
              </div>

              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block uppercase">Owner Team</span>
                <span className="text-slate-200 font-semibold">{selectedNode.ownerTeam}</span>
              </div>

              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 block uppercase">Volume / QPS</span>
                <span className="text-cyan-300 font-bold">{selectedNode.recordCount}</span>
              </div>
            </div>

            {/* Upstream Parents List */}
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <span className="text-[11px] font-mono text-slate-400 uppercase font-bold flex items-center gap-1.5">
                <ArrowRight className="w-3.5 h-3.5 text-cyan-400" />
                Upstream Dependencies ({upstreamNodes.length})
              </span>

              {upstreamNodes.length > 0 ? (
                <div className="space-y-1.5 font-mono text-[11px]">
                  {upstreamNodes.map((uNode) => (
                    <div
                      key={uNode.id}
                      onClick={() => setSelectedNode(uNode)}
                      className="p-2 bg-slate-950 rounded-lg border border-slate-800 hover:border-cyan-500/50 cursor-pointer flex items-center justify-between text-slate-200"
                    >
                      <span className="font-bold text-cyan-300 truncate">{uNode.name}</span>
                      <span className="text-[9px] text-slate-500">{uNode.type}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-[11px] text-slate-500 font-mono">This is a primary raw data source (Root node).</p>
              )}
            </div>

            {/* Downstream Consumers List */}
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <span className="text-[11px] font-mono text-slate-400 uppercase font-bold flex items-center gap-1.5">
                <ArrowRight className="w-3.5 h-3.5 text-purple-400" />
                Downstream Consumers ({downstreamNodes.length})
              </span>

              {downstreamNodes.length > 0 ? (
                <div className="space-y-1.5 font-mono text-[11px]">
                  {downstreamNodes.map((dNode) => (
                    <div
                      key={dNode.id}
                      onClick={() => setSelectedNode(dNode)}
                      className="p-2 bg-slate-950 rounded-lg border border-slate-800 hover:border-purple-500/50 cursor-pointer flex items-center justify-between text-slate-200"
                    >
                      <span className="font-bold text-purple-300 truncate">{dNode.name}</span>
                      <span className="text-[9px] text-slate-500">{dNode.type}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-[11px] text-slate-500 font-mono">This is a leaf serving node or final AI endpoint.</p>
              )}
            </div>

            {/* Action Copilot */}
            {onOpenCopilotWithContext && (
              <button
                onClick={() =>
                  onOpenCopilotWithContext(
                    `Analyze feature lineage for node '${selectedNode.name}' (${selectedNode.type}). Verify if upstream schema changes impact downstream model ${downstreamNodes.map((d) => d.name).join(', ')}.`
                  )
                }
                className="w-full py-2 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 font-bold text-xs flex items-center justify-center space-x-1.5 transition-colors mt-2"
              >
                <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
                <span>Ask Copilot to Audit Schema Impact</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
