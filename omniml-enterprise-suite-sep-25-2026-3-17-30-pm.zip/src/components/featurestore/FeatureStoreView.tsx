import React, { useState } from 'react';
import {
  Database,
  RefreshCw,
  Zap,
  Activity,
  Code,
  CheckCircle2,
  AlertCircle,
  Sliders,
  Sparkles,
  ArrowRight,
  Server,
  Share2,
  Table,
} from 'lucide-react';
import { FeatureView, FeatureItem } from '../../types/mlops';
import { FeatureLineageGraph } from './FeatureLineageGraph';

interface FeatureStoreViewProps {
  featureViews: FeatureView[];
  onOpenCopilotWithContext: (prompt: string) => void;
}

export const FeatureStoreView: React.FC<FeatureStoreViewProps> = ({
  featureViews,
  onOpenCopilotWithContext,
}) => {
  const [activeTab, setActiveTab] = useState<'catalog' | 'lineage'>('catalog');
  const [selectedView, setSelectedView] = useState<FeatureView>(featureViews[0]);
  const [joinSimulationCode, setJoinSimulationCode] = useState<string>(`# Feast / Enterprise Feature Store Point-in-Time Join
from feast import FeatureStore
import pandas as pd

store = FeatureStore(repo_path="./feature_repo")

entity_df = pd.DataFrame({
    "user_id": [10042, 10043, 10044],
    "timestamp": pd.to_datetime(["2026-08-01 07:00:00", "2026-08-01 07:05:00", "2026-08-01 07:10:00"])
})

training_data = store.get_historical_features(
    entity_df=entity_df,
    features=[
        "user_transaction_behavior_realtime:avg_txn_amount_30d",
        "user_transaction_behavior_realtime:txn_velocity_1h",
        "user_transaction_behavior_realtime:unique_device_ip_count_7d"
    ]
).to_df()

print(f"Retrieved {len(training_data)} rows with zero data leakage.")`);

  return (
    <div className="p-6 space-y-6 text-slate-100 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 p-5 rounded-2xl border border-slate-800">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center gap-2">
            <Database className="w-5 h-5 text-indigo-400" />
            Enterprise Feature Store (Feast & Hopsworks Engine)
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Low-latency online store (Redis / Milvus) & point-in-time point-join offline store (Snowflake / BigQuery).
          </p>
        </div>

        {/* Sub-tab switcher */}
        <div className="flex items-center space-x-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveTab('catalog')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1.5 ${
              activeTab === 'catalog'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Table className="w-3.5 h-3.5" />
            <span>Feature Catalog & Schemas</span>
          </button>

          <button
            onClick={() => setActiveTab('lineage')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1.5 ${
              activeTab === 'lineage'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Feature Lineage Graph</span>
          </button>
        </div>
      </div>

      {/* Render Lineage Tab or Catalog Tab */}
      {activeTab === 'lineage' ? (
        <FeatureLineageGraph onOpenCopilotWithContext={onOpenCopilotWithContext} />
      ) : (
        <>
          {/* Feature View Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {featureViews.map((fv) => {
              const isSelected = selectedView.id === fv.id;
              return (
                <div
                  key={fv.id}
                  onClick={() => setSelectedView(fv)}
                  className={`p-5 rounded-2xl border transition-all cursor-pointer space-y-3 ${
                    isSelected
                      ? 'bg-slate-900 border-indigo-500 ring-1 ring-indigo-500/40 shadow-lg'
                      : 'bg-slate-900/60 border-slate-800 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-mono text-indigo-400 uppercase font-bold">Entity: {fv.entity}</span>
                      <h3 className="text-sm font-bold text-white">{fv.name}</h3>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      {fv.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-xs font-mono bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                    <div>
                      <span className="text-[10px] text-slate-500 block">Online Store</span>
                      <span className="text-cyan-300 font-bold">{fv.onlineStoreType}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block">Offline Store</span>
                      <span className="text-indigo-300 font-bold">{fv.offlineStoreType}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block">Serving QPS</span>
                      <span className="text-emerald-400 font-bold">{fv.readQps.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Selected Feature View Table & Join Simulator */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Table of Features in View (7 Cols) */}
            <div className="lg:col-span-7 bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-bold text-white flex items-center gap-2">
                  <Server className="w-4 h-4 text-cyan-400" />
                  Features Schema & Drift Statistics ({selectedView.features.length} Features)
                </h2>
                <span className="text-[11px] font-mono text-slate-400">Synced: {selectedView.lastSyncedAt}</span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
                    <tr>
                      <th className="py-2.5 px-3">Feature Name</th>
                      <th className="py-2.5 px-3">Type</th>
                      <th className="py-2.5 px-3">Freshness</th>
                      <th className="py-2.5 px-3">Null Ratio</th>
                      <th className="py-2.5 px-3">PSI Drift</th>
                      <th className="py-2.5 px-3">Serving Latency</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {selectedView.features.map((feat) => (
                      <tr key={feat.name} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-2.5 px-3 font-semibold text-white font-sans">{feat.name}</td>
                        <td className="py-2.5 px-3 text-indigo-300">{feat.dataType}</td>
                        <td className="py-2.5 px-3 text-slate-300">{feat.freshnessSec}s</td>
                        <td className="py-2.5 px-3 text-slate-300">{(feat.nullRatio * 100).toFixed(1)}%</td>
                        <td className="py-2.5 px-3">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                              feat.driftScore > 0.2
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                : 'bg-emerald-500/20 text-emerald-300'
                            }`}
                          >
                            {feat.driftScore}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-cyan-300">{feat.onlineServingLatencyMs}ms</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Right 5 Cols: Point-in-time Join Simulator Code */}
            <div className="lg:col-span-5 bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <h2 className="text-sm font-bold text-white flex items-center gap-2">
                    <Code className="w-4 h-4 text-emerald-400" />
                    Point-in-Time Join Code Generator
                  </h2>
                  <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-300 font-mono">Python / Feast</span>
                </div>

                <p className="text-xs text-slate-400 mt-2">
                  Eliminates data leakage by fetching historical features strictly corresponding to transaction event timestamps.
                </p>

                <pre className="mt-3 p-3.5 bg-slate-950 rounded-xl border border-slate-800 text-[11px] font-mono text-emerald-300 overflow-x-auto leading-relaxed">
                  {joinSimulationCode}
                </pre>
              </div>

              <div className="p-3 bg-indigo-950/40 rounded-xl border border-indigo-500/30 text-xs text-indigo-200 flex items-center justify-between">
                <span>Online Redis Latency SLA: <strong>&lt; 0.8ms P99</strong></span>
                <span className="text-emerald-400 font-bold">Passed</span>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
