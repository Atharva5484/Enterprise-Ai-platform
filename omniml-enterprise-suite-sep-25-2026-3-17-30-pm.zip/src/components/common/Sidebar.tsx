import React from 'react';
import {
  LayoutDashboard,
  Layers,
  Database,
  GitFork,
  Zap,
  Activity,
  Sparkles,
  Cpu,
  ShieldCheck,
  ChevronRight,
  FolderGit2,
  Brain,
  HardDrive,
  Users,
  FileText,
} from 'lucide-react';

export type NavTab =
  | 'overview'
  | 'datasets'
  | 'training'
  | 'registry'
  | 'featurestore'
  | 'pipelines'
  | 'serving'
  | 'monitoring'
  | 'llmops'
  | 'cluster'
  | 'storage'
  | 'users'
  | 'governance'
  | 'docs';

interface SidebarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  modelsCount: number;
  pipelinesCount: number;
  endpointsCount: number;
  driftAlertsCount: number;
  datasetsCount?: number;
  isMobileOpen?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  modelsCount,
  pipelinesCount,
  endpointsCount,
  driftAlertsCount,
  datasetsCount,
  isMobileOpen,
  onCloseMobile,
}) => {
  const navItems = [
    {
      id: 'overview',
      label: 'Executive Overview',
      icon: LayoutDashboard,
      badge: null,
    },
    {
      id: 'datasets',
      label: 'Dataset & DVC Hub',
      icon: FolderGit2,
      badge: datasetsCount ? `${datasetsCount} Sets` : 'DVC Active',
      badgeColor: 'bg-teal-500/20 text-teal-300 border-teal-500/30',
    },
    {
      id: 'training',
      label: 'Model Training & MLflow',
      icon: Brain,
      badge: '6 Engines',
      badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
    },
    {
      id: 'registry',
      label: 'Model Registry',
      icon: Layers,
      badge: modelsCount > 0 ? `${modelsCount}` : null,
      badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
    },
    {
      id: 'featurestore',
      label: 'Feature Store',
      icon: Database,
      badge: '2 Views',
      badgeColor: 'bg-slate-800 text-slate-300 border-slate-700',
    },
    {
      id: 'pipelines',
      label: 'ML Pipelines & CI/CD',
      icon: GitFork,
      badge: '1 Active',
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    },
    {
      id: 'serving',
      label: 'Model Serving',
      icon: Zap,
      badge: `${endpointsCount} Live`,
      badgeColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
    },
    {
      id: 'monitoring',
      label: 'Observability & Drift',
      icon: Activity,
      badge: driftAlertsCount > 0 ? `${driftAlertsCount} Drift` : null,
      badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30 animate-pulse',
    },
    {
      id: 'llmops',
      label: 'LLMOps & GenAI Hub',
      icon: Sparkles,
      badge: 'New',
      badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
    },
    {
      id: 'cluster',
      label: 'GPU Clusters & K8s',
      icon: Cpu,
      badge: '87% Load',
      badgeColor: 'bg-slate-800 text-slate-300 border-slate-700',
    },
    {
      id: 'storage',
      label: 'Storage & DB Engine',
      icon: HardDrive,
      badge: 'Postgres/S3',
      badgeColor: 'bg-teal-500/20 text-teal-300 border-teal-500/30',
    },
    {
      id: 'users',
      label: 'Users & RBAC Studio',
      icon: Users,
      badge: '5 Members',
      badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
    },
    {
      id: 'governance',
      label: 'Governance & Audits',
      icon: ShieldCheck,
      badge: 'Passed',
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    },
    {
      id: 'docs',
      label: 'Docs & OpenAPI',
      icon: FileText,
      badge: 'Swagger',
      badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
    },
  ];

  const renderNavContent = () => (
    <>
      <div className="p-3 space-y-1">
        <div className="px-3 py-1.5 text-[11px] font-bold text-slate-500 tracking-wider uppercase">
          Enterprise Control Plane
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id as NavTab);
                onCloseMobile?.();
              }}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all group ${
                isActive
                  ? 'bg-gradient-to-r from-indigo-600/30 to-blue-600/10 text-white border border-indigo-500/40 shadow-sm font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <Icon
                  className={`w-4 h-4 transition-colors ${
                    isActive ? 'text-indigo-400' : 'text-slate-500 group-hover:text-slate-300'
                  }`}
                />
                <span>{item.label}</span>
              </div>

              <div className="flex items-center space-x-1.5">
                {item.badge && (
                  <span
                    className={`text-[10px] font-medium px-2 py-0.5 rounded-full border ${item.badgeColor}`}
                  >
                    {item.badge}
                  </span>
                )}
                <ChevronRight
                  className={`w-3.5 h-3.5 transition-transform ${
                    isActive ? 'text-indigo-400 translate-x-0.5' : 'text-slate-600 opacity-0 group-hover:opacity-100'
                  }`}
                />
              </div>
            </button>
          );
        })}
      </div>

      {/* Footer System Telemetry Box */}
      <div className="p-3 m-3 bg-slate-950/80 rounded-xl border border-slate-800/80 text-xs space-y-2">
        <div className="flex items-center justify-between text-slate-400 text-[11px]">
          <span>SDK Version</span>
          <span className="font-mono text-slate-200">v3.4.0-genai</span>
        </div>
        <div className="flex items-center justify-between text-slate-400 text-[11px]">
          <span>Security Scan</span>
          <span className="text-emerald-400 font-medium flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            0 Vulns
          </span>
        </div>
        <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
          <div className="bg-gradient-to-r from-indigo-500 to-cyan-400 h-full w-[88%]" />
        </div>
      </div>
    </>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden lg:flex w-64 bg-slate-900/95 border-r border-slate-800 text-slate-300 flex-col justify-between shrink-0 select-none h-[calc(100vh-53px)] overflow-y-auto sticky top-[53px]">
        {renderNavContent()}
      </aside>

      {/* Mobile & Tablet Drawer Overlay */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-xs transition-opacity"
            onClick={onCloseMobile}
          />

          {/* Slide-over Drawer */}
          <div className="relative w-72 max-w-[85vw] bg-slate-900 text-slate-300 h-full overflow-y-auto border-r border-slate-800 shadow-2xl flex flex-col justify-between z-10 animate-in slide-in-from-left duration-200">
            {renderNavContent()}
          </div>
        </div>
      )}
    </>
  );
};
