import React from 'react';
import {
  ShieldCheck,
  Activity,
  Sparkles,
  Search,
  Bell,
  Cpu,
  RefreshCw,
  Sliders,
  Key,
  User,
  Shield,
  Menu,
  X,
  Download,
} from 'lucide-react';
import { Environment, UserRole, AuthUser } from '../../types/mlops';

interface HeaderProps {
  environment: Environment;
  setEnvironment: (env: Environment) => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  onOpenCopilot: () => void;
  onOpenExportModal?: () => void;
  onOpenAlertCenter?: () => void;
  unreadAuditCount: number;
  currentUser?: AuthUser;
  onOpenAuthModal?: () => void;
  jwtToken?: string;
  isMobileMenuOpen: boolean;
  setIsMobileMenuOpen: (open: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({
  environment,
  setEnvironment,
  userRole,
  setUserRole,
  onOpenCopilot,
  onOpenExportModal,
  onOpenAlertCenter,
  unreadAuditCount,
  currentUser,
  onOpenAuthModal,
  jwtToken,
  isMobileMenuOpen,
  setIsMobileMenuOpen,
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-40 px-3 sm:px-4 py-2.5 flex items-center justify-between shadow-md">
      {/* Left: Mobile Toggle, Brand & Core Telemetry */}
      <div className="flex items-center space-x-2 sm:space-x-4">
        {/* Mobile Sidebar Hamburger Toggle */}
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white lg:hidden border border-slate-700 transition-colors"
          title="Toggle Mobile Navigation"
        >
          {isMobileMenuOpen ? <X className="w-5 h-5 text-indigo-400" /> : <Menu className="w-5 h-5 text-slate-300" />}
        </button>

        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-indigo-600 via-blue-500 to-cyan-400 flex items-center justify-center font-bold text-white shadow-lg shadow-indigo-500/20 shrink-0">
            <Activity className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-extrabold text-base sm:text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
                NexusML
              </span>
              <span className="text-[10px] font-semibold tracking-wider uppercase px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 hidden xs:inline-block">
                Enterprise
              </span>
            </div>
            <p className="text-[10px] sm:text-[11px] text-slate-400 font-medium hidden md:block">
              Autonomous AI & MLOps Infrastructure Platform
            </p>
          </div>
        </div>

        {/* Vertical Divider */}
        <div className="h-6 w-px bg-slate-800 hidden xl:block" />

        {/* Cluster Status Pills */}
        <div className="hidden xl:flex items-center space-x-3 text-xs text-slate-300">
          <div className="flex items-center space-x-1.5 bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700/60">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-slate-400">Cluster:</span>
            <span className="font-mono font-medium text-slate-200">us-central1</span>
          </div>

          <div className="flex items-center space-x-1.5 bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700/60">
            <Cpu className="w-3.5 h-3.5 text-indigo-400" />
            <span className="text-slate-400">GPUs:</span>
            <span className="font-mono font-medium text-emerald-400">28 / 32 Active (87.5%)</span>
          </div>
        </div>
      </div>

      {/* Right Controls: Env Switcher, Role, Copilot, Audit */}
      <div className="flex items-center space-x-2 sm:space-x-3">
        {/* Environment Switcher */}
        <div className="hidden sm:flex items-center bg-slate-950 p-0.5 rounded-lg border border-slate-800">
          {(['production', 'staging', 'development'] as Environment[]).map((env) => (
            <button
              key={env}
              onClick={() => setEnvironment(env)}
              className={`px-2 sm:px-2.5 py-1 rounded-md text-[11px] sm:text-xs font-medium capitalize transition-all ${
                environment === env
                  ? env === 'production'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                    : env === 'staging'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                    : 'bg-blue-500/20 text-blue-300 border border-blue-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {env === 'development' ? 'Dev' : env}
            </button>
          ))}
        </div>

        {/* User JWT & RBAC Profile Badge */}
        {currentUser && onOpenAuthModal && (
          <button
            onClick={onOpenAuthModal}
            className="flex items-center space-x-2 bg-slate-800 hover:bg-slate-750 px-2.5 py-1 rounded-lg border border-indigo-500/40 text-xs transition-all group"
          >
            {currentUser.avatarUrl ? (
              <img
                src={currentUser.avatarUrl}
                alt={currentUser.name}
                className="w-5 h-5 rounded-full object-cover border border-indigo-400"
              />
            ) : (
              <User className="w-3.5 h-3.5 text-indigo-400" />
            )}
            <div className="text-left hidden md:block">
              <span className="font-bold text-slate-200 text-[11px] block truncate max-w-[100px]">
                {currentUser.name.split(' ')[0]}
              </span>
              <span className="text-[9px] font-mono text-indigo-300 font-semibold block uppercase">
                {userRole}
              </span>
            </div>
            <Key className="w-3.5 h-3.5 text-yellow-400 shrink-0 group-hover:scale-110 transition-transform hidden sm:block" />
          </button>
        )}

        {/* Role Switcher */}
        <div className="hidden md:flex items-center space-x-1 bg-slate-800/90 px-2 py-1 rounded-lg border border-slate-700/70 text-xs">
          <Sliders className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={userRole}
            onChange={(e) => setUserRole(e.target.value as UserRole)}
            className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer text-xs"
          >
            <option value="Admin" className="bg-slate-900 text-slate-200">Admin</option>
            <option value="ML Engineer" className="bg-slate-900 text-slate-200">ML Engineer</option>
            <option value="Data Scientist" className="bg-slate-900 text-slate-200">Data Scientist</option>
            <option value="Viewer" className="bg-slate-900 text-slate-200">Viewer (Read Only)</option>
            <option value="MLOps Admin" className="bg-slate-900 text-slate-200">MLOps Admin</option>
            <option value="Lead Data Scientist" className="bg-slate-900 text-slate-200">Lead Data Scientist</option>
            <option value="Compliance Officer" className="bg-slate-900 text-slate-200">Compliance Officer</option>
          </select>
        </div>

        {/* Export Data Button */}
        {onOpenExportModal && (
          <button
            onClick={onOpenExportModal}
            className="flex items-center space-x-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700/80 text-indigo-300 font-semibold text-xs border border-indigo-500/30 transition-all active:scale-95 shadow-sm"
            title="Export Data & Work Logs"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden sm:inline">Export Data</span>
          </button>
        )}

        {/* AI Copilot Launcher */}
        <button
          onClick={onOpenCopilot}
          className="flex items-center space-x-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-gradient-to-r from-indigo-600 via-indigo-500 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-medium text-xs shadow-lg shadow-indigo-600/30 transition-all border border-indigo-400/30 active:scale-95"
        >
          <Sparkles className="w-3.5 h-3.5 text-yellow-300 animate-pulse" />
          <span className="font-semibold hidden sm:inline">NexusCopilot</span>
        </button>

        {/* Alert Center Launcher Badge */}
        <div className="relative">
          <button
            onClick={onOpenAlertCenter}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700/80 text-slate-300 border border-slate-700 transition-colors relative"
            title="Open Alert Center"
          >
            <Bell className="w-4 h-4 text-slate-300" />
            {unreadAuditCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-bounce">
                {unreadAuditCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
