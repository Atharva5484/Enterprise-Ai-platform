import React, { useState, useEffect } from 'react';
import {
  Download,
  FileJson,
  FileSpreadsheet,
  FileText,
  Copy,
  Check,
  X,
  Database,
  GitFork,
  Bot,
  Activity,
  Layers,
  Sparkles,
  ShieldCheck,
  Clock,
  Cpu,
  CheckCircle2,
  Loader2,
  ArrowRight,
  Code,
} from 'lucide-react';
import { exportToCSV, exportToJSON, exportToText } from '../../utils/exportUtils';

interface ExportDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeModuleContext?: string;
}

export const ExportDataModal: React.FC<ExportDataModalProps> = ({
  isOpen,
  onClose,
  activeModuleContext = 'agent_orchestration',
}) => {
  const [exportCategory, setExportCategory] = useState<string>(activeModuleContext || 'agent_orchestration');
  const [exportFormat, setExportFormat] = useState<'json' | 'csv' | 'markdown' | 'yaml'>('json');
  const [includeAuditHeader, setIncludeAuditHeader] = useState<boolean>(true);
  const [includeMemoryBuffers, setIncludeMemoryBuffers] = useState<boolean>(true);
  const [isCopied, setIsCopied] = useState<boolean>(false);
  
  // Progress State for File Preparation
  const [isPreparing, setIsPreparing] = useState<boolean>(false);
  const [exportProgress, setExportProgress] = useState<number>(0);
  const [progressStatusText, setProgressStatusText] = useState<string>('Initializing export job...');
  const [downloadSuccessMessage, setDownloadSuccessMessage] = useState<string | null>(null);

  // Sync category if prop context changes when modal opens
  useEffect(() => {
    if (activeModuleContext) {
      if (activeModuleContext.includes('model')) setExportCategory('model_registry');
      else if (activeModuleContext.includes('monitoring') || activeModuleContext.includes('drift')) setExportCategory('ragas_evals');
      else if (activeModuleContext.includes('pipeline')) setExportCategory('training_runs');
      else setExportCategory('agent_orchestration');
    }
  }, [activeModuleContext, isOpen]);

  if (!isOpen) return null;

  // Raw structured object data for real CSV / JSON export
  const getRawDataForCategory = (): Record<string, any>[] => {
    const timestamp = new Date().toISOString();

    if (exportCategory === 'model_registry') {
      return [
        {
          ModelID: 'mdl-gemini-finetuned-v3',
          Name: 'Financial-LLM-Gemini-1.5-Pro',
          Version: 'v3.1.0',
          Stage: 'Production',
          Framework: 'PyTorch / Gemini',
          AccuracyF1: 0.942,
          LatencyMs: 240,
          Vulnerabilities: 0,
          ComplianceStatus: 'PASSED',
          ApprovedBy: 'Sarah Chen (Lead Admin)',
          ExportedAt: timestamp,
        },
        {
          ModelID: 'mdl-xgboost-fraud-v2',
          Name: 'XGBoost Risk Scoring Engine',
          Version: 'v2.0.4',
          Stage: 'Staging',
          Framework: 'XGBoost',
          AccuracyF1: 0.915,
          LatencyMs: 45,
          Vulnerabilities: 0,
          ComplianceStatus: 'APPROVED',
          ApprovedBy: 'Security Lead',
          ExportedAt: timestamp,
        },
        {
          ModelID: 'mdl-bert-intent-v1',
          Name: 'Customer Intent Classifier',
          Version: 'v1.2.0',
          Stage: 'Archived',
          Framework: 'HuggingFace',
          AccuracyF1: 0.884,
          LatencyMs: 110,
          Vulnerabilities: 1,
          ComplianceStatus: 'AUDITED',
          ApprovedBy: 'MLOps Lead',
          ExportedAt: timestamp,
        },
      ];
    } else if (exportCategory === 'ragas_evals') {
      return [
        {
          MetricID: 'eval-001',
          Dataset: 'Financial Q2 Risk Reports',
          FaithfulnessScore: 0.984,
          AnswerRelevance: 0.952,
          ContextPrecision: 0.941,
          ContextRecall: 0.920,
          HallucinationsDetected: false,
          Status: 'PASSED_SENTINEL',
          Timestamp: timestamp,
        },
        {
          MetricID: 'eval-002',
          Dataset: 'Customer Support Knowledge Base',
          FaithfulnessScore: 0.912,
          AnswerRelevance: 0.890,
          ContextPrecision: 0.885,
          ContextRecall: 0.870,
          HallucinationsDetected: false,
          Status: 'WARNING_DRIFT',
          Timestamp: timestamp,
        },
      ];
    } else if (exportCategory === 'training_runs') {
      return [
        {
          RunID: 'run-9941',
          PipelineName: 'LangGraph Autonomous Retraining DAG',
          Framework: 'LangGraph / PyTorch',
          Epochs: 25,
          TrainingLoss: 0.042,
          ValidationAccuracy: 0.968,
          GPUHoursUsed: 4.5,
          ClusterNodes: 8,
          Status: 'COMPLETED',
          Timestamp: timestamp,
        },
        {
          RunID: 'run-9942',
          PipelineName: 'XGBoost Feature Re-indexing Job',
          Framework: 'XGBoost',
          Epochs: 100,
          TrainingLoss: 0.012,
          ValidationAccuracy: 0.945,
          GPUHoursUsed: 1.2,
          ClusterNodes: 4,
          Status: 'COMPLETED',
          Timestamp: timestamp,
        },
      ];
    } else if (exportCategory === 'feature_store') {
      return [
        {
          FeatureSet: 'user_transaction_embeddings_v2',
          VectorDimensions: 1536,
          IndexType: 'Qdrant HNSW',
          TotalVectors: 1450000,
          SimilarityMetric: 'Cosine',
          AvgQueryLatencyMs: 12,
          Status: 'HEALTHY',
          Timestamp: timestamp,
        },
      ];
    } else {
      // agent_orchestration
      return [
        {
          WorkflowID: 'wf-langgraph-rag',
          WorkflowName: 'LangGraph Multi-Agent RAG & Quality Sentinel',
          Framework: 'LangGraph',
          ActiveAgents: 4,
          TotalTokens: 14250,
          AvgStepLatencyMs: 480,
          CheckpointerStatus: 'Postgres Synced',
          Status: 'RUNNING',
          Timestamp: timestamp,
        },
        {
          WorkflowID: 'wf-autogen-devteam',
          WorkflowName: 'AutoGen Autonomous Software Dev Swarm',
          Framework: 'AutoGen',
          ActiveAgents: 4,
          TotalTokens: 28900,
          AvgStepLatencyMs: 820,
          CheckpointerStatus: 'Docker Sandbox Executed',
          Status: 'IDLE',
          Timestamp: timestamp,
        },
      ];
    }
  };

  // Sample Generated Export Content for Live Preview
  const getGeneratedExportContent = (): string => {
    const timestamp = new Date().toISOString();
    const rawData = getRawDataForCategory();

    if (exportFormat === 'json') {
      return JSON.stringify(
        {
          nexus_ml_export_version: '2.4.0',
          exported_at: timestamp,
          module: exportCategory,
          environment: 'Production',
          include_audit_metadata: includeAuditHeader,
          include_memory_buffers: includeMemoryBuffers,
          records_count: rawData.length,
          data: rawData,
        },
        null,
        2
      );
    } else if (exportFormat === 'csv') {
      if (rawData.length === 0) return '';
      const headers = Object.keys(rawData[0]);
      const csvRows = [
        headers.join(','),
        ...rawData.map((row) =>
          headers.map((h) => `"${String(row[h]).replace(/"/g, '""')}"`).join(',')
        ),
      ];
      return csvRows.join('\n');
    } else if (exportFormat === 'markdown') {
      return `# NexusML ${exportCategory.toUpperCase()} Export Report
**Generated At:** ${timestamp}  
**Environment:** Production | **Audit Header:** ${includeAuditHeader ? 'Enabled' : 'Disabled'}  

## Data Records Summary (${rawData.length} Items)
${rawData
  .map(
    (item, idx) =>
      `### Record #${idx + 1}: ${item.Name || item.WorkflowName || item.PipelineName || item.MetricID || 'Item'}
- **ID/Version:** \`${item.ModelID || item.WorkflowID || item.RunID || item.FeatureSet || 'N/A'}\`
- **Framework/Type:** ${item.Framework || item.IndexType || 'Standard'}
- **Key Metrics / Status:** ${item.ComplianceStatus || item.Status || 'COMPLETED'}
`
  )
  .join('\n')}

---
*Signed off by NexusML Automated MLOps Sentinel Engine*
`;
    } else {
      return `nexus_ml_version: "2.4.0"
timestamp: "${timestamp}"
category: "${exportCategory}"
include_audit: ${includeAuditHeader}
records_count: ${rawData.length}
`;
    }
  };

  const handleCopyContent = () => {
    navigator.clipboard.writeText(getGeneratedExportContent());
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  // Handle Export with Realistic Step Progress Bar
  const handleStartExportDownload = () => {
    setIsPreparing(true);
    setExportProgress(0);
    setProgressStatusText('Querying database tables & vector indices...');

    // Progress Stage 1
    const timer1 = setTimeout(() => {
      setExportProgress(35);
      setProgressStatusText('Formatting schema & encrypting compliance headers...');
    }, 400);

    // Progress Stage 2
    const timer2 = setTimeout(() => {
      setExportProgress(75);
      setProgressStatusText('Compiling final bundle artifact...');
    }, 800);

    // Final Stage
    const timer3 = setTimeout(() => {
      setExportProgress(100);
      setProgressStatusText('Download starting...');

      const rawData = getRawDataForCategory();
      const dateStr = new Date().toISOString().slice(0, 10);
      const filenameBase = `nexusml_${exportCategory}_${dateStr}`;

      if (exportFormat === 'csv') {
        exportToCSV(rawData, `${filenameBase}.csv`);
      } else if (exportFormat === 'json') {
        const payload = {
          nexus_ml_export_version: '2.4.0',
          exported_at: new Date().toISOString(),
          module: exportCategory,
          include_audit_metadata: includeAuditHeader,
          include_memory_buffers: includeMemoryBuffers,
          records_count: rawData.length,
          data: rawData,
        };
        exportToJSON(payload, `${filenameBase}.json`);
      } else if (exportFormat === 'markdown') {
        exportToText(getGeneratedExportContent(), `${filenameBase}.md`, 'text/markdown');
      } else {
        exportToText(getGeneratedExportContent(), `${filenameBase}.yaml`, 'text/yaml');
      }

      setIsPreparing(false);
      setDownloadSuccessMessage(`Export complete! Downloaded ${filenameBase}.${exportFormat === 'markdown' ? 'md' : exportFormat}`);
      setTimeout(() => setDownloadSuccessMessage(null), 4000);
    }, 1200);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-6 shadow-2xl text-slate-100">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div>
            <span className="text-[10px] font-mono text-indigo-400 uppercase font-bold tracking-wider">
              NexusML Data Export Center
            </span>
            <h3 className="text-base font-bold text-white flex items-center gap-2 mt-0.5">
              <Download className="w-5 h-5 text-indigo-400" />
              Export Work, Workflow Logs & System Telemetry
            </h3>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body with Clean Layout & Spacing */}
        <div className="space-y-5">
          {/* Form Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs font-mono">
            {/* Export Module Category */}
            <div className="space-y-1.5">
              <label className="text-[10px] text-slate-400 uppercase font-bold block">
                Data Category / Module
              </label>
              <select
                value={exportCategory}
                onChange={(e) => setExportCategory(e.target.value)}
                className="w-full bg-slate-950 px-3 py-2.5 rounded-xl border border-slate-800 text-white font-medium focus:outline-none focus:border-indigo-500 transition-colors"
              >
                <option value="agent_orchestration">LangGraph & AutoGen Workflows</option>
                <option value="model_registry">Model Registry & Governance Lineage</option>
                <option value="ragas_evals">RAGAS Quality & Faithfulness Evals</option>
                <option value="training_runs">ML Training & Fine-Tuning Runs</option>
                <option value="feature_store">Feature Store Vectors & Embeddings</option>
              </select>
            </div>

            {/* Export Format Selector */}
            <div className="space-y-1.5">
              <label className="text-[10px] text-slate-400 uppercase font-bold block">
                Export Format
              </label>
              <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
                <button
                  type="button"
                  onClick={() => setExportFormat('json')}
                  className={`flex-1 py-1.5 rounded-lg font-bold transition-all flex items-center justify-center gap-1.5 ${
                    exportFormat === 'json' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <FileJson className="w-3.5 h-3.5" />
                  <span>JSON</span>
                </button>

                <button
                  type="button"
                  onClick={() => setExportFormat('csv')}
                  className={`flex-1 py-1.5 rounded-lg font-bold transition-all flex items-center justify-center gap-1.5 ${
                    exportFormat === 'csv' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  <span>CSV</span>
                </button>

                <button
                  type="button"
                  onClick={() => setExportFormat('markdown')}
                  className={`flex-1 py-1.5 rounded-lg font-bold transition-all flex items-center justify-center gap-1.5 ${
                    exportFormat === 'markdown' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Report</span>
                </button>
              </div>
            </div>
          </div>

          {/* Configuration Toggles */}
          <div className="flex flex-wrap items-center gap-6 text-xs font-mono text-slate-300 pt-1">
            <label className="flex items-center space-x-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={includeAuditHeader}
                onChange={(e) => setIncludeAuditHeader(e.target.checked)}
                className="w-4 h-4 rounded bg-slate-950 border-slate-700 text-indigo-600 focus:ring-0 cursor-pointer"
              />
              <span>Include Compliance Audit Metadata</span>
            </label>

            <label className="flex items-center space-x-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={includeMemoryBuffers}
                onChange={(e) => setIncludeMemoryBuffers(e.target.checked)}
                className="w-4 h-4 rounded bg-slate-950 border-slate-700 text-indigo-600 focus:ring-0 cursor-pointer"
              />
              <span>Include Memory Buffers & State Vectors</span>
            </label>
          </div>

          {/* Progress Indicator Component (When Preparing Export) */}
          {isPreparing && (
            <div className="p-4 bg-slate-950 rounded-xl border border-indigo-500/30 space-y-2.5 font-mono">
              <div className="flex items-center justify-between text-xs">
                <span className="text-indigo-300 font-bold flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />
                  {progressStatusText}
                </span>
                <span className="text-emerald-400 font-bold">{exportProgress}%</span>
              </div>

              {/* Progress Bar Track */}
              <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-300 ease-out rounded-full"
                  style={{ width: `${exportProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* Live Export Code Preview */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
              <span className="flex items-center gap-1.5">
                <Code className="w-3.5 h-3.5 text-indigo-400" />
                Live Payload Preview ({exportFormat.toUpperCase()}):
              </span>
              <button
                onClick={handleCopyContent}
                className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-bold transition-colors"
              >
                {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{isCopied ? 'Copied to Clipboard!' : 'Copy Preview'}</span>
              </button>
            </div>

            <pre className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 text-emerald-300 font-mono text-[11px] max-h-48 overflow-y-auto leading-relaxed shadow-inner">
              {getGeneratedExportContent()}
            </pre>
          </div>

          {/* Success Alert */}
          {downloadSuccessMessage && (
            <div className="p-3.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-xl text-xs font-mono flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{downloadSuccessMessage}</span>
            </div>
          )}
        </div>

        {/* Modal Footer Actions */}
        <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors"
          >
            Cancel
          </button>

          <button
            onClick={handleStartExportDownload}
            disabled={isPreparing}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold text-xs flex items-center space-x-2 shadow-lg shadow-indigo-600/30 transition-all disabled:opacity-50"
          >
            {isPreparing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
            <span>{isPreparing ? 'Preparing File...' : 'Download Export Bundle'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
