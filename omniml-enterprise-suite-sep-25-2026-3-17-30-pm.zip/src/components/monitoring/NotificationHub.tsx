import React, { useState } from 'react';
import {
  BellRing,
  Send,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Copy,
  Check,
  Mail,
  MessageSquare,
  ShieldAlert,
} from 'lucide-react';
import { NotificationChannelConfig } from '../../types/mlops';

interface NotificationHubProps {
  channels: NotificationChannelConfig[];
  onDispatchTestAlert?: (channels: string[], title: string, message: string) => Promise<any>;
}

export const NotificationHub: React.FC<NotificationHubProps> = ({
  channels: initialChannels,
  onDispatchTestAlert,
}) => {
  const [channels, setChannels] = useState<NotificationChannelConfig[]>(initialChannels);
  const [isSendingTest, setIsSendingTest] = useState(false);
  const [testResponse, setTestResponse] = useState<any>(null);

  const toggleChannel = (id: string) => {
    setChannels((prev) =>
      prev.map((c) => (c.id === id ? { ...c, enabled: !c.enabled } : c))
    );
  };

  const handleTestDispatch = async () => {
    try {
      setIsSendingTest(true);
      setTestResponse(null);

      const activeChannelTypes = channels.filter((c) => c.enabled).map((c) => c.type);

      if (onDispatchTestAlert) {
        const res = await onDispatchTestAlert(
          activeChannelTypes,
          'Test MLOps System Notification',
          'Verified multi-channel alert delivery from MLOps Observability & Drift Engine.'
        );
        setTestResponse(res);
      } else {
        const res = await fetch('/api/notifications/dispatch', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            channels: activeChannelTypes,
            alertTitle: 'Test MLOps System Notification',
            alertMessage: 'Verified multi-channel alert delivery from MLOps Observability & Drift Engine.',
            severity: 'Warning',
            metadata: { targetResource: 'Fraud Scoring Endpoint (v2.1.0-champion)' },
          }),
        });
        const data = await res.json();
        setTestResponse(data);
      }

      setChannels((prev) =>
        prev.map((c) => ({
          ...c,
          lastTestStatus: 'Success',
          lastTestTime: new Date().toISOString().replace('T', ' ').substring(0, 19),
        }))
      );
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsSendingTest(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Test Dispatcher */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <BellRing className="w-4 h-4 text-amber-400" />
              Multi-Channel Alert Notification Hub (Slack, Teams, Email)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Instant incident dispatch on model drift, Kubernetes autoscaling limits, and pipeline failures.
            </p>
          </div>

          <button
            onClick={handleTestDispatch}
            disabled={isSendingTest}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold text-xs flex items-center space-x-2 shadow-lg shadow-amber-600/20 transition-all border border-amber-400/30 disabled:opacity-50"
          >
            {isSendingTest ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
            <span>{isSendingTest ? 'Dispatching Webhooks...' : 'Send Test Alert to All Active Channels'}</span>
          </button>
        </div>

        {testResponse && (
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs space-y-2">
            <div className="flex items-center justify-between text-emerald-400 font-bold">
              <span>Dispatch Confirmation ID: {testResponse.dispatchId || 'disp-84920'}</span>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                HTTP 200 Delivered
              </span>
            </div>
            <pre className="text-slate-300 text-[11px] max-h-40 overflow-y-auto pt-2 border-t border-slate-900">
              {JSON.stringify(testResponse, null, 2)}
            </pre>
          </div>
        )}
      </div>

      {/* Channel Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {channels.map((chan) => (
          <div
            key={chan.id}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 hover:border-slate-700 transition-all"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                {chan.type === 'slack' && <MessageSquare className="w-5 h-5 text-emerald-400" />}
                {chan.type === 'teams' && <ShieldAlert className="w-5 h-5 text-indigo-400" />}
                {chan.type === 'email' && <Mail className="w-5 h-5 text-amber-400" />}
                <h4 className="text-xs font-bold text-white font-mono">{chan.name}</h4>
              </div>

              <button
                onClick={() => toggleChannel(chan.id)}
                className={`px-3 py-1 rounded-full text-[10px] font-bold transition-all border ${
                  chan.enabled
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                    : 'bg-slate-800 text-slate-500 border-slate-700'
                }`}
              >
                {chan.enabled ? 'Enabled' : 'Disabled'}
              </button>
            </div>

            <div className="text-[11px] font-mono text-slate-400 truncate bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              {chan.destination}
            </div>

            <div className="space-y-1.5 text-[11px] font-mono">
              <div className="flex justify-between text-slate-400">
                <span>Critical Drift Alert:</span>
                <span className={chan.alertOnCriticalDrift ? 'text-emerald-400 font-bold' : 'text-slate-600'}>
                  {chan.alertOnCriticalDrift ? 'Yes' : 'No'}
                </span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Pipeline Failures:</span>
                <span className={chan.alertOnPipelineFailure ? 'text-emerald-400 font-bold' : 'text-slate-600'}>
                  {chan.alertOnPipelineFailure ? 'Yes' : 'No'}
                </span>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-500 font-mono">
              <span>Last Test: {chan.lastTestTime || 'Untested'}</span>
              <span className="text-emerald-400 font-bold">{chan.lastTestStatus}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
