import React, { useState } from 'react';
import {
  RotateCcw,
  Zap,
  Play,
  CheckCircle2,
  AlertTriangle,
  BellRing,
  Sliders,
  ShieldAlert,
  Clock,
  Sparkles,
  RefreshCw,
} from 'lucide-react';
import { AutoRetrainPolicy } from '../../types/mlops';

interface AutoRetrainControllerProps {
  policies: AutoRetrainPolicy[];
  onTriggerRetrainPipeline?: () => void;
  onSendNotification?: (channels: string[], title: string, message: string) => void;
  onOpenCopilotWithContext?: (prompt: string) => void;
}

export const AutoRetrainController: React.FC<AutoRetrainControllerProps> = ({
  policies: initialPolicies,
  onTriggerRetrainPipeline,
  onSendNotification,
  onOpenCopilotWithContext,
}) => {
  const [policies, setPolicies] = useState<AutoRetrainPolicy[]>(initialPolicies);
  const [isSimulating, setIsSimulating] = useState(false);
  const [lastEventMsg, setLastEventMsg] = useState<string | null>(null);

  const selectedPolicy = policies[0];

  const handleSimulateDriftAndAutoRetrain = async () => {
    setIsSimulating(true);
    setLastEventMsg(null);

    // 1. Simulate drift escalation
    setTimeout(() => {
      onSendNotification?.(
        selectedPolicy.notifyChannels,
        `Evidently AI Critical Drift Triggered: ${selectedPolicy.modelName}`,
        `Population Stability Index (PSI) exceeded threshold (${selectedPolicy.psiThreshold}). Automated retrain DAG pipeline execution initiated.`
      );

      // 2. Trigger retrain pipeline
      onTriggerRetrainPipeline?.();

      setPolicies((prev) =>
        prev.map((p, i) =>
          i === 0
            ? {
                ...p,
                lastTriggeredAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
                totalTriggersCount: p.totalTriggersCount + 1,
              }
            : p
        )
      );

      setIsSimulating(false);
      setLastEventMsg(
        `Automated retrain pipeline successfully spawned for '${selectedPolicy.modelName}'. Trigger reason: PSI > ${selectedPolicy.psiThreshold}. Sent alerts to ${selectedPolicy.notifyChannels.join(', ')}.`
      );
    }, 1200);
  };

  const togglePolicy = (policyId: string) => {
    setPolicies((prev) =>
      prev.map((p) => (p.id === policyId ? { ...p, enabled: !p.enabled } : p))
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Banner Control */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-emerald-400" />
              Automated Model Retraining & Closed-Loop Policy Engine
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Continuously trigger new ML pipeline DAG training runs when Evidently AI detects data drift, concept drift, or accuracy degradation.
            </p>
          </div>

          <button
            onClick={handleSimulateDriftAndAutoRetrain}
            disabled={isSimulating}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 via-orange-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white font-bold text-xs flex items-center space-x-2 shadow-lg shadow-rose-600/20 transition-all border border-rose-400/30 disabled:opacity-50"
          >
            {isSimulating ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Zap className="w-4 h-4 fill-current text-yellow-300" />
            )}
            <span>{isSimulating ? 'Evaluating Drift & Triggering DAG...' : 'Simulate Drift Event & Trigger Auto-Retrain'}</span>
          </button>
        </div>

        {lastEventMsg && (
          <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 font-mono flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{lastEventMsg}</span>
          </div>
        )}
      </div>

      {/* Active Policies List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {policies.map((p) => (
          <div
            key={p.id}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 hover:border-slate-700 transition-all"
          >
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono text-slate-400 uppercase font-bold">Policy ID: {p.id}</span>
                <h4 className="text-sm font-bold text-white">{p.modelName}</h4>
              </div>

              <button
                onClick={() => togglePolicy(p.id)}
                className={`px-3 py-1 rounded-full text-xs font-bold transition-all border ${
                  p.enabled
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                    : 'bg-slate-800 text-slate-500 border-slate-700'
                }`}
              >
                {p.enabled ? 'Policy Active' : 'Disabled'}
              </button>
            </div>

            {/* Threshold Rules */}
            <div className="grid grid-cols-3 gap-2 text-xs font-mono bg-slate-950 p-3 rounded-xl border border-slate-800">
              <div>
                <span className="text-slate-500 text-[10px] block">PSI Drift Limit</span>
                <span className="text-amber-400 font-bold">&gt; {p.psiThreshold}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block font-mono">Accuracy Drop</span>
                <span className="text-rose-400 font-bold">&gt; {(p.accuracyDropThreshold * 100).toFixed(0)}%</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">P-Value Threshold</span>
                <span className="text-cyan-400 font-bold">&lt; {p.conceptDriftPValue}</span>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-1">
              <span>Cooldown: <strong>{p.cooldownPeriodHours}h</strong></span>
              <span>Total Auto-Triggers: <strong className="text-indigo-400">{p.totalTriggersCount}</strong></span>
              <span>Last: <strong>{p.lastTriggeredAt || 'Never'}</strong></span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
