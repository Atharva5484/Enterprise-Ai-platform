import React, { useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Sparkles,
  BarChart2,
  RefreshCw,
  Search,
  CheckCircle2,
  AlertCircle,
  TrendingDown,
  RotateCcw,
  BellRing,
  Layers,
  Download,
  ShieldAlert,
  GitFork,
  Zap,
} from 'lucide-react';
import { DriftMetric, AutoRetrainPolicy, NotificationChannelConfig } from '../../types/mlops';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  AreaChart,
  Area,
  LineChart,
  Line,
  CartesianGrid,
  ReferenceLine,
} from 'recharts';
import { PrometheusGrafanaStudio } from './PrometheusGrafanaStudio';
import { AutoRetrainController } from './AutoRetrainController';
import { NotificationHub } from './NotificationHub';
import { INITIAL_AUTO_RETRAIN_POLICIES, INITIAL_NOTIFICATION_CHANNELS } from '../../data/mockOpsData';
import { exportToCSV } from '../../utils/exportUtils';
import { useAlertCenter } from '../../context/AlertCenterContext';

const HISTORICAL_PSI_TREND_DATA = [
  { timestamp: '07/15', 'Fraud Scoring (XGBoost)': 0.03, 'Customer Churn (LightGBM)': 0.02, 'LLM Safeguard (PyTorch)': 0.04, 'Credit Rating (CatBoost)': 0.01 },
  { timestamp: '07/19', 'Fraud Scoring (XGBoost)': 0.05, 'Customer Churn (LightGBM)': 0.03, 'LLM Safeguard (PyTorch)': 0.05, 'Credit Rating (CatBoost)': 0.02 },
  { timestamp: '07/23', 'Fraud Scoring (XGBoost)': 0.08, 'Customer Churn (LightGBM)': 0.04, 'LLM Safeguard (PyTorch)': 0.06, 'Credit Rating (CatBoost)': 0.02 },
  { timestamp: '07/27', 'Fraud Scoring (XGBoost)': 0.12, 'Customer Churn (LightGBM)': 0.06, 'LLM Safeguard (PyTorch)': 0.07, 'Credit Rating (CatBoost)': 0.03 },
  { timestamp: '07/31', 'Fraud Scoring (XGBoost)': 0.18, 'Customer Churn (LightGBM)': 0.08, 'LLM Safeguard (PyTorch)': 0.09, 'Credit Rating (CatBoost)': 0.03 },
  { timestamp: '08/04', 'Fraud Scoring (XGBoost)': 0.24, 'Customer Churn (LightGBM)': 0.11, 'LLM Safeguard (PyTorch)': 0.10, 'Credit Rating (CatBoost)': 0.04 },
  { timestamp: '08/08', 'Fraud Scoring (XGBoost)': 0.29, 'Customer Churn (LightGBM)': 0.13, 'LLM Safeguard (PyTorch)': 0.11, 'Credit Rating (CatBoost)': 0.05 },
  { timestamp: '08/11', 'Fraud Scoring (XGBoost)': 0.38, 'Customer Churn (LightGBM)': 0.15, 'LLM Safeguard (PyTorch)': 0.12, 'Credit Rating (CatBoost)': 0.05 },
];

interface MonitoringViewProps {
  driftMetrics: DriftMetric[];
  onOpenCopilotWithContext: (prompt: string) => void;
  onTriggerPipeline?: () => void;
  onOpenExportModal?: (context?: string) => void;
}

export const MonitoringView: React.FC<MonitoringViewProps> = ({
  driftMetrics,
  onOpenCopilotWithContext,
  onTriggerPipeline,
  onOpenExportModal,
}) => {
  const { addAlert } = useAlertCenter();

  const [activeTab, setActiveTab] = useState<'evidently' | 'prometheus' | 'autoretrain' | 'notifications'>('evidently');
  const [selectedMetric, setSelectedMetric] = useState<DriftMetric>(driftMetrics[0]);
  const [selectedTrendModel, setSelectedTrendModel] = useState<string>('All Models');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);

  const [autoRetrainPolicies] = useState<AutoRetrainPolicy[]>(INITIAL_AUTO_RETRAIN_POLICIES);
  const [notificationChannels] = useState<NotificationChannelConfig[]>(INITIAL_NOTIFICATION_CHANNELS);

  // Manual Trigger Alert Handlers for Testing & Live Demonstration
  const handleTriggerDriftAlert = () => {
    addAlert({
      type: 'drift',
      severity: 'critical',
      title: 'Critical Covariate Shift (PSI = 0.382)',
      message: `Feature '${selectedMetric.featureName}' distribution deviated significantly from baseline training dataset. Auto-retraining requested.`,
      source: 'Evidently AI Monitoring Engine',
      actionLabel: 'Analyze Drift',
    });
  };

  const handleTriggerPipelineFailureAlert = () => {
    addAlert({
      type: 'pipeline_failure',
      severity: 'critical',
      title: 'LangGraph Autonomous Retraining Failed',
      message: 'Pipeline run-9821 failed at Step 03 (Hyperparameter Tuning). Optuna worker memory limit exceeded.',
      source: 'LangGraph Orchestration Pipeline',
      actionLabel: 'Inspect Logs',
    });
  };

  const handleTriggerPiiBreachAlert = () => {
    addAlert({
      type: 'pii_breach',
      severity: 'critical',
      title: 'PII Detection & Compliance Breach',
      message: 'Unredacted SSN/Email address detected in incoming payload batch #88412. Sentinel blocked payload.',
      source: 'Privacy & Governance Sentinel',
      actionLabel: 'View Safeguards',
    });
  };

  // Analyze drift root cause via Copilot endpoint
  const handleAnalyzeRootCause = async () => {
    try {
      setIsAnalyzing(true);
      setAnalysisResult(null);

      const res = await fetch('/api/monitoring/evidently-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          modelName: 'Fraud Scoring Model (XGBoost)',
          driftMetrics: driftMetrics,
        }),
      });

      const data = await res.json();
      setAnalysisResult(data.driftSummary + ' ' + (data.recommendedAction || ''));
    } catch (err: any) {
      console.error(err);
      setAnalysisResult('Evidently AI Analysis: Covariate shift detected in transaction_amount_usd (PSI = 0.284). Recommend triggering automated retrain pipeline.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="p-6 space-y-6 text-slate-100 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 p-5 rounded-2xl border border-slate-800">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center gap-2">
            <Activity className="w-5 h-5 text-amber-400" />
            Model Observability, Evidently AI & Multi-Channel Alerting Hub
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Monitor Evidently AI covariate shift, Prometheus / Grafana metrics, closed-loop auto-retraining, and Slack/Teams/Email notifications.
          </p>
        </div>

        {/* Top Navigation Tabs & Export */}
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
            {[
              { id: 'evidently', label: 'Evidently AI Drift', icon: Activity },
              { id: 'prometheus', label: 'Prometheus & Grafana', icon: BarChart2 },
              { id: 'autoretrain', label: 'Auto-Retrain Engine', icon: RotateCcw },
              { id: 'notifications', label: 'Notifications (Slack/Teams/Email)', icon: BellRing },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
                    isActive
                      ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          <button
            onClick={() => {
              if (onOpenExportModal) {
                onOpenExportModal('monitoring_metrics');
              } else {
                exportToCSV(
                  driftMetrics.map((dm) => ({
                    featureName: dm.featureName,
                    pVal: dm.pVal,
                    psiScore: dm.psiScore,
                    driftDetected: dm.driftDetected,
                    featureImportance: dm.featureImportance,
                    timestamp: dm.timestamp,
                  })),
                  'monitoring_drift_metrics.csv'
                );
              }
            }}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 border border-indigo-500/30 font-bold text-xs flex items-center space-x-1.5 transition-colors shadow-sm shrink-0"
            title="Export Monitoring & Telemetry Data"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            <span>Export Data</span>
          </button>
        </div>
      </div>

      {/* Global Alert Simulation controls banner */}
      <div className="bg-slate-900/90 border border-amber-500/30 p-4 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-3 font-mono text-xs shadow-lg">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <Zap className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <span className="font-bold text-white block">Interactive Alert Center Event Simulator</span>
            <span className="text-[11px] text-slate-400">Trigger critical events to verify toast notifications & global Alert Center telemetry</span>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleTriggerDriftAlert}
            className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 font-bold text-[11px] flex items-center gap-1.5 transition-all active:scale-95"
          >
            <Activity className="w-3.5 h-3.5 text-amber-400" />
            <span>Simulate Model Drift</span>
          </button>

          <button
            onClick={handleTriggerPipelineFailureAlert}
            className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 font-bold text-[11px] flex items-center gap-1.5 transition-all active:scale-95"
          >
            <GitFork className="w-3.5 h-3.5 text-rose-400" />
            <span>Simulate Pipeline Failure</span>
          </button>

          <button
            onClick={handleTriggerPiiBreachAlert}
            className="px-3 py-1.5 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/40 font-bold text-[11px] flex items-center gap-1.5 transition-all active:scale-95"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
            <span>Simulate PII Breach</span>
          </button>
        </div>
      </div>

      {/* TAB 1: EVIDENTLY AI DRIFT */}
      {activeTab === 'evidently' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xs font-bold text-slate-400 font-mono uppercase tracking-wider">
              Feature Data Drift & Kolmogorov-Smirnov Statistical Test Suite
            </h3>

            <button
              onClick={handleAnalyzeRootCause}
              disabled={isAnalyzing}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold text-xs flex items-center space-x-2 shadow transition-all disabled:opacity-50"
            >
              {isAnalyzing ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Sparkles className="w-3.5 h-3.5 text-yellow-200" />
              )}
              <span>{isAnalyzing ? 'Analyzing Drift...' : 'Evidently AI Diagnostic Audit'}</span>
            </button>
          </div>

          {analysisResult && (
            <div className="p-4 bg-amber-950/30 border border-amber-500/40 rounded-xl text-xs text-amber-200 space-y-2">
              <div className="flex items-center gap-2 font-bold text-amber-300">
                <Sparkles className="w-4 h-4 text-yellow-300" />
                <span>Evidently AI Root Cause Diagnostic Result</span>
              </div>
              <p className="leading-relaxed font-mono">{analysisResult}</p>
            </div>
          )}

          {/* Metrics Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {driftMetrics.map((dm) => {
              const isSelected = selectedMetric.featureName === dm.featureName;
              const isAlert = dm.status === 'Critical' || dm.status === 'Warning';
              return (
                <div
                  key={dm.featureName}
                  onClick={() => setSelectedMetric(dm)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer space-y-3 ${
                    isSelected
                      ? 'bg-slate-900 border-amber-500 ring-1 ring-amber-500/40 shadow-lg'
                      : 'bg-slate-900/60 border-slate-800 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono text-slate-400 uppercase font-bold">{dm.metricName} Test</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        dm.status === 'Critical'
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                          : dm.status === 'Warning'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      }`}
                    >
                      {dm.status}
                    </span>
                  </div>

                  <div>
                    <h4 className="text-xs font-bold text-white font-mono truncate">{dm.featureName}</h4>
                    <div className="flex items-baseline space-x-2 mt-1 font-mono">
                      <span className="text-xl font-extrabold text-amber-400">{dm.currentValue.toFixed(3)}</span>
                      <span className="text-xs text-slate-500">/ Threshold: {dm.threshold.toFixed(2)}</span>
                    </div>
                  </div>

                  <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                    <div
                      style={{ width: `${Math.min(100, (dm.currentValue / (dm.threshold * 1.5)) * 100)}%` }}
                      className={`h-full ${
                        dm.status === 'Critical' ? 'bg-rose-500' : dm.status === 'Warning' ? 'bg-amber-400' : 'bg-emerald-400'
                      }`}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Detailed Feature Distribution Overlay Chart */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono text-indigo-400 uppercase font-bold">Evidently AI Distribution Inspector</span>
                <h3 className="text-sm font-bold text-white font-mono">{selectedMetric.featureName} (Baseline vs Production)</h3>
              </div>

              <button
                onClick={() =>
                  onOpenCopilotWithContext(
                    `Explain the distribution shift for feature '${selectedMetric.featureName}' with PSI = ${selectedMetric.currentValue}.`
                  )
                }
                className="text-xs font-semibold text-yellow-300 hover:text-yellow-200 bg-yellow-500/10 border border-yellow-500/30 px-3 py-1.5 rounded-lg flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
                <span>Explain Distribution Shift</span>
              </button>
            </div>

            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={selectedMetric.distributionData}>
                  <XAxis dataKey="bin" stroke="#64748b" fontSize={10} />
                  <YAxis stroke="#64748b" fontSize={10} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px' }} />
                  <Legend />
                  <Bar dataKey="baseline" name="Baseline Dataset (Reference)" fill="#6366f1" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="production" name="Production Stream (Current)" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Historical Population Stability Index (PSI) Trend Chart Panel */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-amber-400" />
                  <span className="text-[10px] font-mono text-amber-400 uppercase font-bold">
                    Historical PSI Trend Analytics
                  </span>
                </div>
                <h3 className="text-sm font-bold text-white font-mono mt-0.5">
                  Model Population Stability Index (PSI) Progression Over Time
                </h3>
              </div>

              {/* Model Filter Pills */}
              <div className="flex items-center gap-1.5 flex-wrap font-mono text-[11px]">
                {[
                  'All Models',
                  'Fraud Scoring (XGBoost)',
                  'Customer Churn (LightGBM)',
                  'LLM Safeguard (PyTorch)',
                  'Credit Rating (CatBoost)',
                ].map((m) => (
                  <button
                    key={m}
                    onClick={() => setSelectedTrendModel(m)}
                    className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                      selectedTrendModel === m
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                        : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            {/* Threshold Legend Bar */}
            <div className="flex items-center justify-between text-[11px] font-mono bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-slate-400">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-0.5 bg-emerald-400 inline-block" />
                  <span>PSI &lt; 0.10: Stable</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-0.5 bg-amber-400 inline-block" />
                  <span>0.10 &le; PSI &lt; 0.25: Moderate Shift</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-0.5 bg-rose-500 inline-block" />
                  <span>PSI &ge; 0.25: Significant Drift</span>
                </span>
              </div>
              <span className="text-slate-500 hidden md:inline">Threshold Reference Lines Included</span>
            </div>

            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={HISTORICAL_PSI_TREND_DATA} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorXgb" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0} />
                    </linearGradient>
                    <linearGradient id="colorLgbm" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0.0} />
                    </linearGradient>
                    <linearGradient id="colorTorch" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>

                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                  <XAxis dataKey="timestamp" stroke="#64748b" fontSize={11} fontStyle="monospace" />
                  <YAxis stroke="#64748b" fontSize={11} domain={[0, 0.45]} tickFormatter={(v) => v.toFixed(2)} />

                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: '#334155',
                      borderRadius: '12px',
                      color: '#f8fafc',
                      fontFamily: 'monospace',
                      fontSize: '11px',
                    }}
                    formatter={(value: any, name: any) => [
                      `${Number(value).toFixed(3)} ${
                        Number(value) >= 0.25 ? '(Critical Shift)' : Number(value) >= 0.10 ? '(Warning)' : '(Stable)'
                      }`,
                      name,
                    ]}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px', fontFamily: 'monospace' }} />

                  {/* Reference Threshold Lines */}
                  <ReferenceLine
                    y={0.10}
                    stroke="#f59e0b"
                    strokeDasharray="4 4"
                    label={{ value: 'Warning (0.10)', fill: '#f59e0b', fontSize: 10, position: 'right' }}
                  />
                  <ReferenceLine
                    y={0.25}
                    stroke="#f43f5e"
                    strokeDasharray="4 4"
                    label={{ value: 'Critical Shift (0.25)', fill: '#f43f5e', fontSize: 10, position: 'right' }}
                  />

                  {(selectedTrendModel === 'All Models' || selectedTrendModel === 'Fraud Scoring (XGBoost)') && (
                    <Area
                      type="monotone"
                      dataKey="Fraud Scoring (XGBoost)"
                      stroke="#f59e0b"
                      strokeWidth={2.5}
                      fillOpacity={1}
                      fill="url(#colorXgb)"
                    />
                  )}

                  {(selectedTrendModel === 'All Models' || selectedTrendModel === 'Customer Churn (LightGBM)') && (
                    <Area
                      type="monotone"
                      dataKey="Customer Churn (LightGBM)"
                      stroke="#6366f1"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorLgbm)"
                    />
                  )}

                  {(selectedTrendModel === 'All Models' || selectedTrendModel === 'LLM Safeguard (PyTorch)') && (
                    <Area
                      type="monotone"
                      dataKey="LLM Safeguard (PyTorch)"
                      stroke="#10b981"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorTorch)"
                    />
                  )}

                  {(selectedTrendModel === 'All Models' || selectedTrendModel === 'Credit Rating (CatBoost)') && (
                    <Line
                      type="monotone"
                      dataKey="Credit Rating (CatBoost)"
                      stroke="#06b6d4"
                      strokeWidth={2}
                      dot={true}
                    />
                  )}
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: PROMETHEUS & GRAFANA */}
      {activeTab === 'prometheus' && <PrometheusGrafanaStudio />}

      {/* TAB 3: AUTO RETRAIN */}
      {activeTab === 'autoretrain' && (
        <AutoRetrainController
          policies={autoRetrainPolicies}
          onTriggerRetrainPipeline={onTriggerPipeline}
          onSendNotification={async (channels, title, msg) => {
            fetch('/api/notifications/dispatch', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                channels,
                alertTitle: title,
                alertMessage: msg,
                severity: 'Critical',
                metadata: { targetResource: 'Automated Retrain Engine' },
              }),
            });
          }}
          onOpenCopilotWithContext={onOpenCopilotWithContext}
        />
      )}

      {/* TAB 4: NOTIFICATIONS */}
      {activeTab === 'notifications' && <NotificationHub channels={notificationChannels} />}
    </div>
  );
};
