import React, { useState } from 'react';
import {
  Activity,
  BarChart2,
  AlertTriangle,
  Zap,
  CheckCircle2,
  Copy,
  Check,
  RefreshCw,
  Clock,
  Cpu,
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, Legend, LineChart, Line } from 'recharts';

const METRICS_SERIES = [
  { time: '00:00', qps: 340, p99LatencyMs: 14, gpuUtil: 68, psiDrift: 0.08, errorRate: 0.1 },
  { time: '04:00', qps: 210, p99LatencyMs: 12, gpuUtil: 45, psiDrift: 0.09, errorRate: 0.0 },
  { time: '08:00', qps: 580, p99LatencyMs: 28, gpuUtil: 84, psiDrift: 0.14, errorRate: 0.2 },
  { time: '12:00', qps: 890, p99LatencyMs: 42, gpuUtil: 92, psiDrift: 0.22, errorRate: 0.4 },
  { time: '16:00', qps: 1120, p99LatencyMs: 65, gpuUtil: 96, psiDrift: 0.28, errorRate: 1.2 },
  { time: '20:00', qps: 760, p99LatencyMs: 34, gpuUtil: 78, psiDrift: 0.21, errorRate: 0.3 },
  { time: '24:00', qps: 450, p99LatencyMs: 18, gpuUtil: 62, psiDrift: 0.18, errorRate: 0.1 },
];

export const PrometheusGrafanaStudio: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'grafana' | 'prometheus'>('grafana');
  const [copiedYaml, setCopiedYaml] = useState(false);

  const prometheusRulesYaml = `# Prometheus Alerting Rules for MLOps Serving Infrastructure
groups:
  - name: mlops_inference_alerts
    rules:
      - alert: ModelInferenceLatencySpike
        expr: histogram_quantile(0.99, sum(rate(http_request_duration_seconds_bucket[5m])) by (le)) > 0.15
        for: 2m
        labels:
          severity: critical
        annotations:
          summary: "P99 Inference Latency exceeds 150ms"
          description: "Serving endpoint {{ $labels.endpoint }} P99 latency is {{ $value }}s."

      - alert: HighGpuVramExhaustion
        expr: container_gpu_memory_used_bytes / container_gpu_memory_total_bytes > 0.95
        for: 3m
        labels:
          severity: critical
        annotations:
          summary: "GPU VRAM pressure > 95%"
          description: "Cluster node {{ $labels.node }} VRAM is near capacity."

      - alert: FeatureDataDriftPSIExceeded
        expr: mlops_feature_psi_score > 0.25
        for: 1m
        labels:
          severity: warning
          auto_retrain: "true"
        annotations:
          summary: "Evidently AI PSI threshold breached (PSI = {{ $value }})"
          description: "Data drift detected on feature {{ $labels.feature_name }}. Triggering automated retrain."
`;

  const handleCopyRules = () => {
    navigator.clipboard.writeText(prometheusRulesYaml);
    setCopiedYaml(true);
    setTimeout(() => setCopiedYaml(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Sub Header Navigation */}
      <div className="flex items-center justify-between bg-slate-900 border border-slate-800 rounded-xl p-2 shadow-lg">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setActiveTab('grafana')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 ${
              activeTab === 'grafana'
                ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30'
                : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
            }`}
          >
            <BarChart2 className="w-4 h-4" />
            <span>Grafana Live Metrics Dashboard</span>
          </button>

          <button
            onClick={() => setActiveTab('prometheus')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 ${
              activeTab === 'prometheus'
                ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30'
                : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>Prometheus Alert Rules (`prometheus.rules.yml`)</span>
          </button>
        </div>

        <span className="text-xs font-mono text-slate-400 bg-slate-950 px-3 py-1 rounded-lg border border-slate-800">
          Scrape Interval: <strong className="text-emerald-400">15s</strong>
        </span>
      </div>

      {activeTab === 'grafana' && (
        <div className="space-y-6">
          {/* Top Key Metrics Banner */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-500 font-mono">Inference Throughput</span>
              <div className="text-xl font-extrabold text-white font-mono">890 QPS</div>
              <span className="text-[11px] text-emerald-400 font-mono">Peak: 1,120 QPS</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-500 font-mono">P99 Latency</span>
              <div className="text-xl font-extrabold text-indigo-400 font-mono">28.4 ms</div>
              <span className="text-[11px] text-slate-400 font-mono">P50: 6.2 ms</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-500 font-mono">GPU VRAM Load</span>
              <div className="text-xl font-extrabold text-amber-400 font-mono">84.2 %</div>
              <span className="text-[11px] text-slate-400 font-mono">28x H100 Active</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-500 font-mono">Evidently PSI Drift</span>
              <div className="text-xl font-extrabold text-rose-400 font-mono">0.284</div>
              <span className="text-[11px] text-rose-400 font-mono">Breached (&gt;0.25)</span>
            </div>
          </div>

          {/* Charts Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* QPS & Latency Chart */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
              <h3 className="text-xs font-bold text-slate-200 font-mono uppercase tracking-wider flex items-center justify-between">
                <span>Inference Throughput (QPS) & P99 Latency (ms)</span>
                <span className="text-[10px] text-indigo-400">Prometheus Metric: rate(http_requests_total)</span>
              </h3>

              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={METRICS_SERIES}>
                    <defs>
                      <linearGradient id="qpsGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6366f1" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="time" stroke="#64748b" fontSize={10} />
                    <YAxis stroke="#64748b" fontSize={10} />
                    <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px' }} />
                    <Legend />
                    <Area type="monotone" dataKey="qps" name="Requests/sec (QPS)" stroke="#6366f1" fillOpacity={1} fill="url(#qpsGrad)" />
                    <Area type="monotone" dataKey="p99LatencyMs" name="P99 Latency (ms)" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.2} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Drift PSI Score Chart */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
              <h3 className="text-xs font-bold text-slate-200 font-mono uppercase tracking-wider flex items-center justify-between">
                <span>Evidently AI Feature Population Stability Index (PSI)</span>
                <span className="text-[10px] text-rose-400 font-bold">Threshold: 0.25</span>
              </h3>

              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={METRICS_SERIES}>
                    <XAxis dataKey="time" stroke="#64748b" fontSize={10} />
                    <YAxis stroke="#64748b" fontSize={10} domain={[0, 0.4]} />
                    <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px' }} />
                    <Legend />
                    <Line type="monotone" dataKey="psiDrift" name="PSI Score" stroke="#f43f5e" strokeWidth={3} dot={{ r: 4 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'prometheus' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-amber-400" />
                Prometheus Declarative Alerting Rules Configuration
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Automated alert generation for Alertmanager, firing Slack, Teams, and Email webhooks on metric breaches.
              </p>
            </div>

            <button
              onClick={handleCopyRules}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700"
            >
              {copiedYaml ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedYaml ? 'Copied Rules!' : 'Copy Prometheus Config'}</span>
            </button>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs text-slate-200 overflow-x-auto max-h-[450px]">
            <pre>{prometheusRulesYaml}</pre>
          </div>
        </div>
      )}
    </div>
  );
};
