import React, { useState } from 'react';
import {
  Shield,
  Key,
  UserCheck,
  Lock,
  X,
  CheckCircle2,
  Copy,
  Check,
  User,
  Sliders,
  AlertTriangle,
  Code,
} from 'lucide-react';
import { AuthUser, UserRole } from '../../types/mlops';
import { PRESET_USERS } from '../../data/mockDatasetsData';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: AuthUser;
  onLoginSuccess: (user: AuthUser, token: string) => void;
  jwtToken: string;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onLoginSuccess,
  jwtToken,
}) => {
  const [selectedPreset, setSelectedPreset] = useState<AuthUser>(currentUser);
  const [activeTab, setActiveTab] = useState<'login' | 'claims'>('login');
  const [customEmail, setCustomEmail] = useState('');
  const [customRole, setCustomRole] = useState<UserRole>('Data Scientist');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [copiedToken, setCopiedToken] = useState(false);

  if (!isOpen) return null;

  const handleLogin = async (userToLogin: AuthUser) => {
    try {
      setIsLoggingIn(true);
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: userToLogin.email,
          role: userToLogin.role,
        }),
      });

      const data = await res.json();
      if (data.token) {
        onLoginSuccess(
          {
            ...userToLogin,
            jwtToken: data.token,
          },
          data.token
        );
      }
    } catch (err) {
      console.error('Login failed', err);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleCustomLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customEmail) return;
    const customUser: AuthUser = {
      id: `usr-${Date.now()}`,
      email: customEmail,
      name: customEmail.split('@')[0],
      role: customRole,
      department: 'Custom MLOps Team',
    };
    handleLogin(customUser);
  };

  const handleCopyToken = () => {
    if (jwtToken) {
      navigator.clipboard.writeText(jwtToken);
      setCopiedToken(true);
      setTimeout(() => setCopiedToken(false), 2000);
    }
  };

  // Decode JWT payload for claim inspector
  let decodedPayload: any = null;
  if (jwtToken) {
    try {
      const parts = jwtToken.split('.');
      if (parts.length === 3) {
        decodedPayload = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
      }
    } catch {
      decodedPayload = null;
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-lg">
              <Key className="w-5 h-5 text-indigo-200" />
            </div>
            <div>
              <h2 className="font-bold text-white text-sm">Enterprise JWT Auth & RBAC Security</h2>
              <p className="text-[11px] text-slate-400">JSON Web Token Issuance & Role Claims Matrix</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-900 px-4 pt-2">
          <button
            onClick={() => setActiveTab('login')}
            className={`px-4 py-2 text-xs font-semibold border-b-2 transition-all ${
              activeTab === 'login'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Authenticate User / Role Preset
          </button>
          <button
            onClick={() => setActiveTab('claims')}
            className={`px-4 py-2 text-xs font-semibold border-b-2 transition-all ${
              activeTab === 'claims'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            JWT Token & Claims Inspector
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {activeTab === 'login' && (
            <div className="space-y-4">
              <div className="text-xs text-slate-400">
                Select an enterprise role preset to simulate instant JWT token signing and test RBAC permissions across the MLOps platform:
              </div>

              {/* Preset Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {PRESET_USERS.map((user) => {
                  const isCurrent = currentUser.id === user.id;
                  return (
                    <div
                      key={user.id}
                      onClick={() => {
                        setSelectedPreset(user);
                        handleLogin(user);
                      }}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center space-x-3 ${
                        isCurrent
                          ? 'bg-indigo-950/60 border-indigo-500 ring-1 ring-indigo-500/50 shadow-lg'
                          : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <img
                        src={user.avatarUrl}
                        alt={user.name}
                        className="w-10 h-10 rounded-full object-cover border border-slate-700 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-mono text-indigo-400 font-bold uppercase">{user.role}</span>
                          {isCurrent && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
                        </div>
                        <h4 className="text-xs font-bold text-white truncate">{user.name}</h4>
                        <p className="text-[10px] text-slate-400 truncate">{user.email}</p>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Custom Login Form */}
              <div className="pt-3 border-t border-slate-800 space-y-3">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                  Or Issue Custom JWT Token
                </span>
                <form onSubmit={handleCustomLogin} className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <input
                    type="email"
                    placeholder="user@organization.io"
                    value={customEmail}
                    onChange={(e) => setCustomEmail(e.target.value)}
                    className="sm:col-span-2 bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                  <select
                    value={customRole}
                    onChange={(e) => setCustomRole(e.target.value as UserRole)}
                    className="bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 text-xs text-slate-200 focus:outline-none"
                  >
                    <option value="Admin">Admin</option>
                    <option value="ML Engineer">ML Engineer</option>
                    <option value="Data Scientist">Data Scientist</option>
                    <option value="Viewer">Viewer</option>
                  </select>
                  <button
                    type="submit"
                    disabled={isLoggingIn || !customEmail}
                    className="sm:col-span-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow transition-all disabled:opacity-50"
                  >
                    {isLoggingIn ? 'Issuing JWT...' : 'Issue Custom JWT Token'}
                  </button>
                </form>
              </div>
            </div>
          )}

          {activeTab === 'claims' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Bearer Token</span>
                  <p className="text-xs font-mono text-indigo-300 truncate max-w-md">{jwtToken || 'No Token'}</p>
                </div>
                <button
                  onClick={handleCopyToken}
                  className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center space-x-1"
                >
                  {copiedToken ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                  <span>{copiedToken ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              {decodedPayload ? (
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-950 p-3 rounded-xl border border-slate-800">
                    <div>
                      <span className="text-slate-500 text-[10px] block">Subject (Sub)</span>
                      <span className="text-white font-bold">{decodedPayload.sub}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[10px] block">Role Claim</span>
                      <span className="text-indigo-400 font-bold">{decodedPayload.role}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[10px] block">Issued At (iat)</span>
                      <span className="text-slate-300">{new Date(decodedPayload.iat * 1000).toLocaleTimeString()}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[10px] block">Expires (exp)</span>
                      <span className="text-emerald-400 font-bold">24 Hours (Valid)</span>
                    </div>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5 font-mono text-xs">
                    <span className="text-slate-400 font-bold uppercase text-[10px] block">Granted RBAC Permissions</span>
                    <div className="flex flex-wrap gap-1.5">
                      {decodedPayload.permissions?.map((perm: string) => (
                        <span key={perm} className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px]">
                          {perm}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-6 text-slate-500 italic text-xs">
                  No JWT token active. Select a user preset to sign a token.
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
