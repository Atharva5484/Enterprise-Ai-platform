import React, { useState } from 'react';
import { ShieldCheck, Lock, CheckCircle2, AlertTriangle, FileText, UserCheck, Shield, Cpu, Layers, Sparkles, SlidersHorizontal, CheckSquare } from 'lucide-react';
import { AuditLogItem, UserRole } from '../../types/mlops';
import { ResourceGovernanceModule } from './ResourceGovernanceModule';
import { ComplianceScannerTool } from './ComplianceScannerTool';

interface GovernanceViewProps {
  auditLogs: AuditLogItem[];
  userRole: UserRole;
  onOpenCopilotWithContext?: (prompt: string) => void;
}

export const GovernanceView: React.FC<GovernanceViewProps> = ({
  auditLogs,
  userRole,
  onOpenCopilotWithContext,
}) => {
  const [activeTab, setActiveTab] = useState<'scanner' | 'compliance' | 'resources'>('scanner');
  const [filterAction, setFilterAction] = useState<string>('All');

  const filteredLogs = auditLogs.filter((log) => filterAction === 'All' || log.action.includes(filterAction));

  return (
    <div className="p-6 space-y-6 text-slate-100 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 p-5 rounded-2xl border border-slate-800">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            Governance, RBAC Security & Compliance Benchmarks
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            CIS Kubernetes, SOC 2 Type II, EU AI Act, NIST AI RMF policy auditing, cryptographic logs, and K8s quotas.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Sub-tab Switcher */}
          <div className="flex items-center space-x-1 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
            <button
              onClick={() => setActiveTab('scanner')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1.5 ${
                activeTab === 'scanner'
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Compliance & Policy Scanner</span>
            </button>

            <button
              onClick={() => setActiveTab('compliance')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1.5 ${
                activeTab === 'compliance'
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Audit Logs & RBAC</span>
            </button>

            <button
              onClick={() => setActiveTab('resources')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1.5 ${
                activeTab === 'resources'
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>Resource Governance</span>
            </button>
          </div>

          <div className="flex items-center space-x-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs">
            <UserCheck className="w-4 h-4 text-indigo-400" />
            <span className="text-slate-400">Current Role:</span>
            <span className="font-bold text-white font-mono">{userRole}</span>
          </div>
        </div>
      </div>

      {activeTab === 'scanner' && (
        <ComplianceScannerTool
          auditLogs={auditLogs}
          userRole={userRole}
          onOpenCopilot={onOpenCopilotWithContext}
        />
      )}

      {activeTab === 'resources' && <ResourceGovernanceModule />}

      {activeTab === 'compliance' && (
        <>
          {/* Compliance Checklists & RBAC Matrix Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Compliance Gates Card */}
            <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-3">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-400" />
                Enterprise Compliance Framework Status
              </h2>

              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="font-semibold text-slate-200">EU AI Act (High-Risk AI Systems)</span>
                  <span className="text-emerald-400 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Compliant
                  </span>
                </div>
                <div className="flex items-center justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="font-semibold text-slate-200">GDPR Data Minimization & Right to Explanation</span>
                  <span className="text-emerald-400 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Compliant
                  </span>
                </div>
                <div className="flex items-center justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="font-semibold text-slate-200">SOC2 Type II Immutable Audit Vault</span>
                  <span className="text-emerald-400 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Compliant
                  </span>
                </div>
              </div>
            </div>

            {/* RBAC Matrix Card */}
            <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-3">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <Lock className="w-4 h-4 text-indigo-400" />
                Role-Based Access Control (RBAC) Permissions
              </h2>

              <div className="overflow-x-auto text-xs">
                <table className="w-full text-left">
                  <thead className="bg-slate-950 text-slate-400 text-[10px] uppercase border-b border-slate-800">
                    <tr>
                      <th className="py-2 px-2">Role</th>
                      <th className="py-2 px-2">Promote Model</th>
                      <th className="py-2 px-2">Modify Traffic</th>
                      <th className="py-2 px-2">Trigger Retrain</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                    <tr>
                      <td className="py-2 px-2 font-bold text-white">MLOps Admin</td>
                      <td className="py-2 px-2 text-emerald-400 font-bold">Yes</td>
                      <td className="py-2 px-2 text-emerald-400 font-bold">Yes</td>
                      <td className="py-2 px-2 text-emerald-400 font-bold">Yes</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-2 font-bold text-slate-300">Lead Data Scientist</td>
                      <td className="py-2 px-2 text-emerald-400 font-bold">Yes</td>
                      <td className="py-2 px-2 text-slate-500">Staging Only</td>
                      <td className="py-2 px-2 text-emerald-400 font-bold">Yes</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-2 font-bold text-slate-400">Compliance Officer</td>
                      <td className="py-2 px-2 text-indigo-400">Approve Gate</td>
                      <td className="py-2 px-2 text-slate-500">Read-Only</td>
                      <td className="py-2 px-2 text-slate-500">Read-Only</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Immutable Audit Logs Table */}
          <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-white">Cryptographic Immutable Audit Log Stream</h2>
              <select
                value={filterAction}
                onChange={(e) => setFilterAction(e.target.value)}
                className="bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs text-slate-200 focus:outline-none"
              >
                <option value="All">All Actions</option>
                <option value="PROMOTE">Promote Model</option>
                <option value="RETRAIN">Auto Retrain</option>
                <option value="DELETE">Delete Attempt</option>
              </select>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="py-2.5 px-3">Timestamp</th>
                    <th className="py-2.5 px-3">User</th>
                    <th className="py-2.5 px-3">Role</th>
                    <th className="py-2.5 px-3">Action</th>
                    <th className="py-2.5 px-3">Resource Target</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">IP Address</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {filteredLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-2.5 px-3 text-slate-400">{log.timestamp}</td>
                      <td className="py-2.5 px-3 font-sans font-bold text-white">{log.user}</td>
                      <td className="py-2.5 px-3 text-indigo-300">{log.role}</td>
                      <td className="py-2.5 px-3 font-bold text-indigo-200">{log.action}</td>
                      <td className="py-2.5 px-3 font-sans text-slate-300">{log.targetResource}</td>
                      <td className="py-2.5 px-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            log.status === 'Success'
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : 'bg-red-500/20 text-red-300'
                          }`}
                        >
                          {log.status}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-500">{log.ipAddress}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
