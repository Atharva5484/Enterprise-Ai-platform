import React, { useState } from 'react';
import {
  Cpu,
  HardDrive,
  Activity,
  Shield,
  Sliders,
  AlertTriangle,
  CheckCircle2,
  Server,
  Zap,
  Lock,
  Plus,
  RefreshCw,
  Edit2,
  Save,
  X,
  Gauge,
  Layers,
} from 'lucide-react';

export interface NamespaceQuota {
  id: string;
  orgName: string;
  namespace: string;
  cpuUsedCores: number;
  cpuLimitCores: number;
  memoryUsedGb: number;
  memoryLimitGb: number;
  gpuUsedCount: number;
  gpuLimitCount: number;
  storageUsedTb: number;
  storageLimitTb: number;
  priorityClass: 'Guaranteed' | 'Burstable' | 'BestEffort';
  autoThrottlingEnabled: boolean;
  noisyNeighborRisk: 'Low' | 'Medium' | 'High';
}

const INITIAL_QUOTAS: NamespaceQuota[] = [
  {
    id: 'ns-1',
    orgName: 'Payments & Fraud Detection Org',
    namespace: 'prod-fraud-detection',
    cpuUsedCores: 48,
    cpuLimitCores: 64,
    memoryUsedGb: 180,
    memoryLimitGb: 256,
    gpuUsedCount: 6,
    gpuLimitCount: 8,
    storageUsedTb: 1.2,
    storageLimitTb: 2.0,
    priorityClass: 'Guaranteed',
    autoThrottlingEnabled: true,
    noisyNeighborRisk: 'Low',
  },
  {
    id: 'ns-2',
    orgName: 'GenAI & LLM Research Lab',
    namespace: 'genai-research-lab',
    cpuUsedCores: 58,
    cpuLimitCores: 60,
    memoryUsedGb: 242,
    memoryLimitGb: 256,
    gpuUsedCount: 15,
    gpuLimitCount: 16,
    storageUsedTb: 3.8,
    storageLimitTb: 4.0,
    priorityClass: 'Burstable',
    autoThrottlingEnabled: true,
    noisyNeighborRisk: 'High',
  },
  {
    id: 'ns-3',
    orgName: 'Risk & Compliance Modeling',
    namespace: 'risk-analytics-prod',
    cpuUsedCores: 22,
    cpuLimitCores: 40,
    memoryUsedGb: 84,
    memoryLimitGb: 128,
    gpuUsedCount: 2,
    gpuLimitCount: 4,
    storageUsedTb: 0.8,
    storageLimitTb: 1.5,
    priorityClass: 'Guaranteed',
    autoThrottlingEnabled: true,
    noisyNeighborRisk: 'Low',
  },
  {
    id: 'ns-4',
    orgName: 'Default Developer Sandbox',
    namespace: 'dev-sandbox-shared',
    cpuUsedCores: 28,
    cpuLimitCores: 32,
    memoryUsedGb: 58,
    memoryLimitGb: 64,
    gpuUsedCount: 2,
    gpuLimitCount: 2,
    storageUsedTb: 0.4,
    storageLimitTb: 0.5,
    priorityClass: 'BestEffort',
    autoThrottlingEnabled: true,
    noisyNeighborRisk: 'Medium',
  },
];

const MOCK_NOISY_NEIGHBOR_ALERTS = [
  {
    id: 'alt-1',
    timestamp: '10:42:15 AM',
    namespace: 'genai-research-lab',
    type: 'CPU Burst Limit Reached',
    message: 'Pod genai-trainer-04 burst attempt capped at 60 cores to protect prod-fraud-detection SLA.',
    severity: 'Warning',
  },
  {
    id: 'alt-2',
    timestamp: '10:35:00 AM',
    namespace: 'dev-sandbox-shared',
    type: 'Memory Throttling Triggered',
    message: 'Memory consumption reached 90% quota limit. Auto-throttling cgroups engaged.',
    severity: 'Info',
  },
  {
    id: 'alt-3',
    timestamp: '09:50:22 AM',
    namespace: 'genai-research-lab',
    type: 'GPU VRAM Contention Shield',
    message: 'NVIDIA MPS vGPU partition re-balanced. Priority Guaranteed pods granted unthrottled access.',
    severity: 'Resolved',
  },
];

export const ResourceGovernanceModule: React.FC = () => {
  const [quotas, setQuotas] = useState<NamespaceQuota[]>(INITIAL_QUOTAS);
  const [editingQuota, setEditingQuota] = useState<NamespaceQuota | null>(null);

  // Edit form state
  const [editCpuLimit, setEditCpuLimit] = useState<number>(64);
  const [editMemoryLimit, setEditMemoryLimit] = useState<number>(256);
  const [editGpuLimit, setEditGpuLimit] = useState<number>(8);
  const [editPriorityClass, setEditPriorityClass] = useState<'Guaranteed' | 'Burstable' | 'BestEffort'>('Guaranteed');
  const [editAutoThrottling, setEditAutoThrottling] = useState<boolean>(true);

  // Summary statistics across cluster
  const totalCpuUsed = quotas.reduce((acc, q) => acc + q.cpuUsedCores, 0);
  const totalCpuLimit = quotas.reduce((acc, q) => acc + q.cpuLimitCores, 0);
  const totalMemoryUsed = quotas.reduce((acc, q) => acc + q.memoryUsedGb, 0);
  const totalMemoryLimit = quotas.reduce((acc, q) => acc + q.memoryLimitGb, 0);
  const totalGpuUsed = quotas.reduce((acc, q) => acc + q.gpuUsedCount, 0);
  const totalGpuLimit = quotas.reduce((acc, q) => acc + q.gpuLimitCount, 0);

  const handleStartEdit = (quota: NamespaceQuota) => {
    setEditingQuota(quota);
    setEditCpuLimit(quota.cpuLimitCores);
    setEditMemoryLimit(quota.memoryLimitGb);
    setEditGpuLimit(quota.gpuLimitCount);
    setEditPriorityClass(quota.priorityClass);
    setEditAutoThrottling(quota.autoThrottlingEnabled);
  };

  const handleSaveEdit = () => {
    if (!editingQuota) return;
    setQuotas((prev) =>
      prev.map((q) => {
        if (q.id === editingQuota.id) {
          const newCpuUsagePct = (q.cpuUsedCores / editCpuLimit) * 100;
          const newRisk = newCpuUsagePct >= 90 ? 'High' : newCpuUsagePct >= 75 ? 'Medium' : 'Low';
          return {
            ...q,
            cpuLimitCores: editCpuLimit,
            memoryLimitGb: editMemoryLimit,
            gpuLimitCount: editGpuLimit,
            priorityClass: editPriorityClass,
            autoThrottlingEnabled: editAutoThrottling,
            noisyNeighborRisk: newRisk,
          };
        }
        return q;
      })
    );
    setEditingQuota(null);
  };

  return (
    <div className="space-y-6 text-slate-100">
      {/* Cluster Total Capacity Overview Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* CPU Cluster Gauge */}
        <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono font-bold uppercase text-slate-400 block">
              Kubernetes vCPU Cluster Allocations
            </span>
            <div className="text-xl font-extrabold text-white font-mono mt-1">
              {totalCpuUsed} / {totalCpuLimit} <span className="text-xs text-slate-400 font-sans">Cores</span>
            </div>
            <span className="text-[10px] text-cyan-400 font-mono mt-0.5 block">
              {((totalCpuUsed / totalCpuLimit) * 100).toFixed(1)}% Cluster Capacity
            </span>
          </div>
          <div className="p-3 bg-cyan-950/40 border border-cyan-500/30 rounded-xl text-cyan-400">
            <Cpu className="w-6 h-6" />
          </div>
        </div>

        {/* Memory Cluster Gauge */}
        <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono font-bold uppercase text-slate-400 block">
              Cluster Memory (RAM) Allocations
            </span>
            <div className="text-xl font-extrabold text-white font-mono mt-1">
              {totalMemoryUsed} / {totalMemoryLimit} <span className="text-xs text-slate-400 font-sans">GB</span>
            </div>
            <span className="text-[10px] text-indigo-400 font-mono mt-0.5 block">
              {((totalMemoryUsed / totalMemoryLimit) * 100).toFixed(1)}% Cluster Capacity
            </span>
          </div>
          <div className="p-3 bg-indigo-950/40 border border-indigo-500/30 rounded-xl text-indigo-400">
            <HardDrive className="w-6 h-6" />
          </div>
        </div>

        {/* GPU Cluster Gauge */}
        <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono font-bold uppercase text-slate-400 block">
              NVIDIA GPU Accelerator Partition
            </span>
            <div className="text-xl font-extrabold text-white font-mono mt-1">
              {totalGpuUsed} / {totalGpuLimit} <span className="text-xs text-slate-400 font-sans">A100 / H100 vGPUs</span>
            </div>
            <span className="text-[10px] text-purple-400 font-mono mt-0.5 block">
              {((totalGpuUsed / totalGpuLimit) * 100).toFixed(1)}% GPU Allocation
            </span>
          </div>
          <div className="p-3 bg-purple-950/40 border border-purple-500/30 rounded-xl text-purple-400">
            <Zap className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Multi-Tenant Namespace Resource Quota Table */}
      <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-400" />
              Multi-Tenant Namespace Resource Quotas & Isolation Rules
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Enforce per-organization limits, noisy neighbor anti-starvation cgroups, and Kubernetes PriorityClasses.
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <span className="px-3 py-1 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs font-mono font-bold">
              Noisy Neighbor Shield Active
            </span>
          </div>
        </div>

        {/* Namespace Quota Grid / Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {quotas.map((quota) => {
            const cpuPct = (quota.cpuUsedCores / quota.cpuLimitCores) * 100;
            const memPct = (quota.memoryUsedGb / quota.memoryLimitGb) * 100;

            return (
              <div
                key={quota.id}
                className={`p-4 bg-slate-950 rounded-xl border transition-all space-y-3 ${
                  quota.noisyNeighborRisk === 'High'
                    ? 'border-amber-500/80 ring-1 ring-amber-500/30'
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* Card Header */}
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-mono text-indigo-400 uppercase font-bold">
                      {quota.orgName}
                    </span>
                    <h3 className="text-sm font-bold text-white font-mono">{quota.namespace}</h3>
                  </div>

                  <div className="flex items-center space-x-2">
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                        quota.noisyNeighborRisk === 'High'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      }`}
                    >
                      Risk: {quota.noisyNeighborRisk}
                    </span>

                    <button
                      onClick={() => handleStartEdit(quota)}
                      className="p-1 rounded bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
                      title="Edit Quotas"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Progress Bars for CPU & Memory */}
                <div className="space-y-2 text-xs font-mono">
                  {/* CPU Usage */}
                  <div>
                    <div className="flex justify-between text-[11px] text-slate-300 mb-1">
                      <span>CPU Cores</span>
                      <span>
                        <strong className="text-white">{quota.cpuUsedCores}</strong> / {quota.cpuLimitCores} Cores ({cpuPct.toFixed(0)}%)
                      </span>
                    </div>
                    <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-800">
                      <div
                        className={`h-full transition-all ${
                          cpuPct >= 90
                            ? 'bg-amber-500'
                            : cpuPct >= 75
                            ? 'bg-indigo-500'
                            : 'bg-cyan-500'
                        }`}
                        style={{ width: `${Math.min(cpuPct, 100)}%` }}
                      />
                    </div>
                  </div>

                  {/* Memory Usage */}
                  <div>
                    <div className="flex justify-between text-[11px] text-slate-300 mb-1">
                      <span>RAM Memory</span>
                      <span>
                        <strong className="text-white">{quota.memoryUsedGb}</strong> / {quota.memoryLimitGb} GB ({memPct.toFixed(0)}%)
                      </span>
                    </div>
                    <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-800">
                      <div
                        className={`h-full transition-all ${
                          memPct >= 90
                            ? 'bg-amber-500'
                            : 'bg-emerald-500'
                        }`}
                        style={{ width: `${Math.min(memPct, 100)}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Footer Metadata */}
                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono text-slate-400">
                  <span>Priority: <strong className="text-indigo-300">{quota.priorityClass}</strong></span>
                  <span>GPU Quota: <strong className="text-purple-300">{quota.gpuUsedCount}/{quota.gpuLimitCount}</strong></span>
                  <span>Auto-Throttle: <strong className="text-emerald-400">{quota.autoThrottlingEnabled ? 'Enabled' : 'Off'}</strong></span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Noisy Neighbor Mitigation Logs */}
      <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-3">
        <h2 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400" />
          Real-time Noisy Neighbor Protection Event Logs
        </h2>

        <div className="space-y-2 text-xs font-mono">
          {MOCK_NOISY_NEIGHBOR_ALERTS.map((alert) => (
            <div
              key={alert.id}
              className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
            >
              <div className="flex items-center space-x-3">
                <span className="text-slate-500 text-[10px]">{alert.timestamp}</span>
                <span className="font-bold text-amber-300 px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/20 text-[10px]">
                  {alert.namespace}
                </span>
                <span className="text-slate-200">{alert.message}</span>
              </div>

              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                  alert.severity === 'Warning'
                    ? 'bg-amber-500/20 text-amber-300'
                    : alert.severity === 'Resolved'
                    ? 'bg-emerald-500/20 text-emerald-300'
                    : 'bg-slate-800 text-slate-300'
                }`}
              >
                {alert.severity}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Modal for Editing Quotas */}
      {editingQuota && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl text-slate-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-mono text-indigo-400 uppercase font-bold">Edit Resource Governance</span>
                <h3 className="text-sm font-bold text-white font-mono">{editingQuota.namespace}</h3>
              </div>
              <button onClick={() => setEditingQuota(null)} className="p-1 rounded bg-slate-800 text-slate-400">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="text-[11px] font-mono text-slate-400 block mb-1">CPU Limit (Cores)</label>
                <input
                  type="number"
                  value={editCpuLimit}
                  onChange={(e) => setEditCpuLimit(parseInt(e.target.value) || 8)}
                  className="w-full bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-white font-mono focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-mono text-slate-400 block mb-1">RAM Memory Limit (GB)</label>
                <input
                  type="number"
                  value={editMemoryLimit}
                  onChange={(e) => setEditMemoryLimit(parseInt(e.target.value) || 16)}
                  className="w-full bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-white font-mono focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-mono text-slate-400 block mb-1">GPU Partition Limit (Units)</label>
                <input
                  type="number"
                  value={editGpuLimit}
                  onChange={(e) => setEditGpuLimit(parseInt(e.target.value) || 0)}
                  className="w-full bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-white font-mono focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-mono text-slate-400 block mb-1">Kubernetes PriorityClass</label>
                <select
                  value={editPriorityClass}
                  onChange={(e) => setEditPriorityClass(e.target.value as any)}
                  className="w-full bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-white font-mono focus:outline-none focus:border-indigo-500"
                >
                  <option value="Guaranteed">Guaranteed (Production Critical)</option>
                  <option value="Burstable">Burstable (Standard Analytics)</option>
                  <option value="BestEffort">BestEffort (Non-Critical Sandbox)</option>
                </select>
              </div>

              <label className="flex items-center space-x-2 p-2.5 bg-slate-950 rounded-xl border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={editAutoThrottling}
                  onChange={(e) => setEditAutoThrottling(e.target.checked)}
                  className="accent-emerald-500 w-4 h-4"
                />
                <span className="text-slate-200">Enable Auto-Throttling on 90%+ Usage Spike</span>
              </label>
            </div>

            <div className="flex justify-end space-x-2 pt-3 border-t border-slate-800">
              <button
                onClick={() => setEditingQuota(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-semibold text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveEdit}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold text-xs"
              >
                Save Quota Policy
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
