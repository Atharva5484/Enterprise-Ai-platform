import React, { useState, useMemo, useEffect } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  AlertOctagon,
  RefreshCw,
  Search,
  Filter,
  ExternalLink,
  Lock,
  FileCheck,
  Server,
  Layers,
  HardDrive,
  UserCheck,
  Check,
  Download,
  Sliders,
  Settings,
  Info,
  ChevronDown,
  ChevronUp,
  Cpu,
  Eye,
  Sparkles,
} from 'lucide-react';
import { AuditLogItem, UserRole } from '../../types/mlops';

export type BenchmarkStandard = 'SOC2' | 'CIS-K8S' | 'EU-AI-ACT' | 'NIST-AIRMF' | 'GDPR-HIPAA';
export type FindingSeverity = 'PASS' | 'WARNING' | 'CRITICAL';

export interface SecurityBenchmarkFinding {
  id: string;
  ruleCode: string;
  benchmark: BenchmarkStandard;
  title: string;
  targetType: 'Audit Log' | 'Configuration' | 'RBAC Policy' | 'Infrastructure';
  targetResource: string;
  severity: FindingSeverity;
  description: string;
  evidence: string;
  remediationRecommendation: string;
  canAutoRemediate?: boolean;
  remediationKey?: keyof EnterpriseSystemConfig;
  status: 'Open' | 'Remediated' | 'Suppressed';
}

export interface EnterpriseSystemConfig {
  s3EncryptionAtRest: boolean;
  s3BlockPublicAccess: boolean;
  s3BucketVersioning: boolean;
  modelArtifactImmutability: boolean;
  requireDualApprovalForProd: boolean;
  podSecurityAdmissionRestricted: boolean;
  containerRunAsNonRoot: boolean;
  tlsVersionMinimum: 'TLS 1.2' | 'TLS 1.3';
  mTLSEnforced: boolean;
  auditLogWormRetentionDays: number;
  piiMaskingEnabled: boolean;
  continuousDriftTelemetry: boolean;
}

const DEFAULT_CONFIG: EnterpriseSystemConfig = {
  s3EncryptionAtRest: true,
  s3BlockPublicAccess: true,
  s3BucketVersioning: true,
  modelArtifactImmutability: true,
  requireDualApprovalForProd: false, // Intentional initial warning/gap to show realistic security findings!
  podSecurityAdmissionRestricted: true,
  containerRunAsNonRoot: true,
  tlsVersionMinimum: 'TLS 1.3',
  mTLSEnforced: true,
  auditLogWormRetentionDays: 365,
  piiMaskingEnabled: true,
  continuousDriftTelemetry: true,
};

interface ComplianceScannerToolProps {
  auditLogs: AuditLogItem[];
  userRole: UserRole;
  onOpenCopilot?: (prompt: string) => void;
}

export const ComplianceScannerTool: React.FC<ComplianceScannerToolProps> = ({
  auditLogs,
  userRole,
  onOpenCopilot,
}) => {
  const [config, setConfig] = useState<EnterpriseSystemConfig>(DEFAULT_CONFIG);
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [currentScanningBenchmark, setCurrentScanningBenchmark] = useState('');
  const [lastScanTimestamp, setLastScanTimestamp] = useState('2026-08-01 07:32:15');
  const [selectedSeverity, setSelectedSeverity] = useState<'ALL' | FindingSeverity>('ALL');
  const [selectedBenchmark, setSelectedBenchmark] = useState<'ALL' | BenchmarkStandard>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedFindingId, setExpandedFindingId] = useState<string | null>(null);
  const [showConfigDrawer, setShowConfigDrawer] = useState(false);
  const [remediatedIds, setRemediatedIds] = useState<Set<string>>(new Set());

  // Function to evaluate rules against audit logs and configurations
  const evaluateFindings = useMemo(() => {
    const list: SecurityBenchmarkFinding[] = [];

    // 1. Audit Log Check: SOC2 CC6.8 - Unauthorized Deletion or Tampering
    const deniedDeletions = auditLogs.filter(
      (log) => log.action.includes('DELETE') && log.status === 'Denied'
    );
    const unblockedDeletions = auditLogs.filter(
      (log) => log.action.includes('DELETE') && log.status !== 'Denied'
    );

    if (unblockedDeletions.length > 0) {
      list.push({
        id: 'find-soc2-cc6.8',
        ruleCode: 'SOC2-CC6.8',
        benchmark: 'SOC2',
        title: 'Unauthenticated/Unapproved Artifact Deletion Detected',
        targetType: 'Audit Log',
        targetResource: unblockedDeletions[0].targetResource,
        severity: 'CRITICAL',
        description:
          'Audit stream logged an unblocked deletion of a production model asset without compliance clearance.',
        evidence: `Audit Event #${unblockedDeletions[0].id}: ${unblockedDeletions[0].user} executed ${unblockedDeletions[0].action} on ${unblockedDeletions[0].targetResource}`,
        remediationRecommendation:
          'Enable Model Artifact Immutability lock and enforce WORM retention on S3 ML storage.',
        canAutoRemediate: true,
        remediationKey: 'modelArtifactImmutability',
        status: remediatedIds.has('find-soc2-cc6.8') ? 'Remediated' : 'Open',
      });
    } else if (deniedDeletions.length > 0) {
      list.push({
        id: 'find-soc2-cc6.8',
        ruleCode: 'SOC2-CC6.8',
        benchmark: 'SOC2',
        title: 'Tamper-Resistant Storage & Unauthorized Deletion Interception',
        targetType: 'Audit Log',
        targetResource: deniedDeletions[0].targetResource,
        severity: 'PASS',
        description:
          'System successfully identified, intercepted, and blocked unauthorized artifact deletion attempts.',
        evidence: `Audit Event #${deniedDeletions[0].id}: Attempted deletion by ${deniedDeletions[0].user} (${deniedDeletions[0].ipAddress}) was blocked: "${deniedDeletions[0].details}".`,
        remediationRecommendation: 'Immutability guards active. Continue WORM policy enforcement.',
        status: 'Remediated',
      });
    } else {
      list.push({
        id: 'find-soc2-cc6.8',
        ruleCode: 'SOC2-CC6.8',
        benchmark: 'SOC2',
        title: 'Tamper-Resistant Storage Protection Active',
        targetType: 'Audit Log',
        targetResource: 'Audit Log Stream',
        severity: 'PASS',
        description: 'Zero suspicious or unauthenticated deletion attempts detected in the active log window.',
        evidence: 'Scanned 100% of audit records. No deletion anomalies logged.',
        remediationRecommendation: 'Maintain standard periodic log integrity reviews.',
        status: 'Remediated',
      });
    }

    // 2. Audit Log Check: SOC2 CC7.2 - Cryptographic Audit Trail Continuity
    const hasAuditLogs = auditLogs.length > 0;
    if (hasAuditLogs) {
      list.push({
        id: 'find-soc2-cc7.2',
        ruleCode: 'SOC2-CC7.2',
        benchmark: 'SOC2',
        title: 'Continuous Immutable Audit Logging & Non-Repudiation',
        targetType: 'Audit Log',
        targetResource: 'Central Audit Sink (10.128.0.42)',
        severity: 'PASS',
        description:
          'All administrative operations, role promotions, and auto-retrain events are cryptographically recorded with client IP and timestamps.',
        evidence: `Active stream contains ${auditLogs.length} verified events. All events have valid user IDs and IP addresses.`,
        remediationRecommendation: 'Ensure backup audit replication to a cross-region cold storage vault.',
        status: 'Remediated',
      });
    } else {
      list.push({
        id: 'find-soc2-cc7.2',
        ruleCode: 'SOC2-CC7.2',
        benchmark: 'SOC2',
        title: 'Audit Log Stream Empty or Inaccessible',
        targetType: 'Audit Log',
        targetResource: 'Central Audit Sink',
        severity: 'CRITICAL',
        description: 'No active audit records found. Continuous monitoring stream may be severed.',
        evidence: 'Audit buffer contains 0 records.',
        remediationRecommendation: 'Restart audit daemon and verify ingestion endpoint connectivity.',
        status: 'Open',
      });
    }

    // 3. Configuration Check: Model Immutability Lock
    if (config.modelArtifactImmutability) {
      list.push({
        id: 'find-immutability',
        ruleCode: 'SOC2-CC6.1',
        benchmark: 'SOC2',
        title: 'Production Model Registry Immutability Lock',
        targetType: 'Configuration',
        targetResource: 'ModelRegistry: Production Artifacts',
        severity: 'PASS',
        description:
          'Production-tagged models cannot be overwritten or deleted by any individual account, adhering to strict write-once semantics.',
        evidence: 'Config setting `modelArtifactImmutability: true` active across all registry clusters.',
        remediationRecommendation: 'Configuration meets enterprise SOC2 trust benchmarks.',
        status: 'Remediated',
      });
    } else {
      list.push({
        id: 'find-immutability',
        ruleCode: 'SOC2-CC6.1',
        benchmark: 'SOC2',
        title: 'Model Artifact Immutability Disabled',
        targetType: 'Configuration',
        targetResource: 'ModelRegistry: Production Artifacts',
        severity: 'CRITICAL',
        description:
          'Production models can be overwritten without audit protection, posing supply chain vulnerability.',
        evidence: '`modelArtifactImmutability` is set to false in registry security settings.',
        remediationRecommendation: 'Enable production artifact immutability lock in registry configuration.',
        canAutoRemediate: true,
        remediationKey: 'modelArtifactImmutability',
        status: remediatedIds.has('find-immutability') ? 'Remediated' : 'Open',
      });
    }

    // 4. Configuration Check: EU AI Act Article 14 - Human Oversight & Dual Approval
    if (config.requireDualApprovalForProd) {
      list.push({
        id: 'find-eu-art14',
        ruleCode: 'EU-AI-ACT-ART14',
        benchmark: 'EU-AI-ACT',
        title: 'Dual-Approval Gate for High-Risk Model Production Deployment',
        targetType: 'RBAC Policy',
        targetResource: 'Gate: Staging -> Production Promotion',
        severity: 'PASS',
        description:
          'High-risk AI models require at least two distinct human approvers (Lead Data Scientist + Compliance Officer) prior to production rollout.',
        evidence: 'Dual-approval policy enabled in orchestration pipeline gate rules.',
        remediationRecommendation: 'Policy is fully compliant with EU AI Act High-Risk system standards.',
        status: 'Remediated',
      });
    } else {
      list.push({
        id: 'find-eu-art14',
        ruleCode: 'EU-AI-ACT-ART14',
        benchmark: 'EU-AI-ACT',
        title: 'Single-Operator Production Promotion Risk (Dual Approval Inactive)',
        targetType: 'RBAC Policy',
        targetResource: 'Gate: Staging -> Production Promotion',
        severity: 'WARNING',
        description:
          'A single MLOps Admin or Lead Data Scientist can promote high-risk models to production without secondary compliance sign-off.',
        evidence: '`requireDualApprovalForProd: false`. Single-sign promotion allowed.',
        remediationRecommendation:
          'Enforce dual-signoff policy requiring secondary approval from a Compliance Officer role.',
        canAutoRemediate: true,
        remediationKey: 'requireDualApprovalForProd',
        status: remediatedIds.has('find-eu-art14') ? 'Remediated' : 'Open',
      });
    }

    // 5. Configuration Check: EU AI Act Article 12 - Automated Drift Retraining Gate
    if (config.continuousDriftTelemetry) {
      list.push({
        id: 'find-eu-art12',
        ruleCode: 'EU-AI-ACT-ART12',
        benchmark: 'EU-AI-ACT',
        title: 'Continuous Statistical Drift & Cyber Telemetry Telemetry',
        targetType: 'Configuration',
        targetResource: 'Evidently AI / DriftWatcher Daemon',
        severity: 'PASS',
        description:
          'Automatic telemetry logs data drift (PSI) and accuracy degradation, triggering containment before customer impact occurs.',
        evidence:
          'Continuous drift daemon active. Verified audit event #audit-902 logged auto-retrain trigger.',
        remediationRecommendation: 'Thresholds calibrated to PSI < 0.20.',
        status: 'Remediated',
      });
    } else {
      list.push({
        id: 'find-eu-art12',
        ruleCode: 'EU-AI-ACT-ART12',
        benchmark: 'EU-AI-ACT',
        title: 'Continuous Drift Telemetry Inactive',
        targetType: 'Configuration',
        targetResource: 'Monitoring Daemon',
        severity: 'CRITICAL',
        description: 'No automated drift monitoring configured for active production models.',
        evidence: '`continuousDriftTelemetry: false` in monitoring config.',
        remediationRecommendation: 'Enable automated PSI drift telemetry and alerting hooks.',
        canAutoRemediate: true,
        remediationKey: 'continuousDriftTelemetry',
        status: remediatedIds.has('find-eu-art12') ? 'Remediated' : 'Open',
      });
    }

    // 6. Configuration Check: CIS Kubernetes Benchmark 5.2.2 - Non-Root Container Execution
    if (config.containerRunAsNonRoot) {
      list.push({
        id: 'find-cis-5.2.2',
        ruleCode: 'CIS-K8S-5.2.2',
        benchmark: 'CIS-K8S',
        title: 'Kubernetes Workloads Enforce Non-Root Execution Context',
        targetType: 'Infrastructure',
        targetResource: 'PodSpec: securityContext.runAsNonRoot',
        severity: 'PASS',
        description:
          'All inference serving pods and model training workers run under non-root UID 10001 with read-only root filesystems.',
        evidence: 'K8s admission webhook strictly rejects pods without `runAsNonRoot: true`.',
        remediationRecommendation: 'In alignment with CIS Benchmark Level 2 recommendations.',
        status: 'Remediated',
      });
    } else {
      list.push({
        id: 'find-cis-5.2.2',
        ruleCode: 'CIS-K8S-5.2.2',
        benchmark: 'CIS-K8S',
        title: 'Containers Permitted to Run as Root (UID 0)',
        targetType: 'Infrastructure',
        targetResource: 'PodSpec: securityContext.runAsNonRoot',
        severity: 'CRITICAL',
        description:
          'Model inference pods lack non-root container security context, risking container breakout on untrusted input.',
        evidence: '`containerRunAsNonRoot: false` allows UID 0 processes.',
        remediationRecommendation:
          'Configure Kubernetes securityContext with `runAsNonRoot: true` and specify non-zero `runAsUser`.',
        canAutoRemediate: true,
        remediationKey: 'containerRunAsNonRoot',
        status: remediatedIds.has('find-cis-5.2.2') ? 'Remediated' : 'Open',
      });
    }

    // 7. Configuration Check: CIS Kubernetes Benchmark 1.2.21 - Pod Security Admission
    if (config.podSecurityAdmissionRestricted) {
      list.push({
        id: 'find-cis-1.2.21',
        ruleCode: 'CIS-K8S-1.2.21',
        benchmark: 'CIS-K8S',
        title: 'Pod Security Admission (PSA) Restricted Profile Enforced',
        targetType: 'Infrastructure',
        targetResource: 'Namespace: `prod-fraud-detection`, `model-serving-prod`',
        severity: 'PASS',
        description:
          'Target namespaces enforce `pod-security.kubernetes.io/enforce: restricted`, disabling privilege escalation and host namespaces.',
        evidence: 'Validated admission labels on all active production cluster namespaces.',
        remediationRecommendation: 'Namespace security profiles compliant.',
        status: 'Remediated',
      });
    } else {
      list.push({
        id: 'find-cis-1.2.21',
        ruleCode: 'CIS-K8S-1.2.21',
        benchmark: 'CIS-K8S',
        title: 'Namespace Lacks Restricted Pod Security Admission',
        targetType: 'Infrastructure',
        targetResource: 'Kubernetes Namespaces',
        severity: 'WARNING',
        description:
          'Namespaces are operating in Privileged or Baseline mode, allowing host network and volume mounting.',
        evidence: '`podSecurityAdmissionRestricted: false`.',
        remediationRecommendation:
          'Apply `pod-security.kubernetes.io/enforce=restricted` label to all model serving namespaces.',
        canAutoRemediate: true,
        remediationKey: 'podSecurityAdmissionRestricted',
        status: remediatedIds.has('find-cis-1.2.21') ? 'Remediated' : 'Open',
      });
    }

    // 8. Configuration Check: S3 Storage Encryption at Rest
    if (config.s3EncryptionAtRest && config.s3BlockPublicAccess) {
      list.push({
        id: 'find-s3-enc',
        ruleCode: 'GDPR-ART32',
        benchmark: 'GDPR-HIPAA',
        title: 'Cloud Artifact Bucket Encryption at Rest & Public Block',
        targetType: 'Configuration',
        targetResource: 'S3: `s3://nexus-ml-artifacts/*`',
        severity: 'PASS',
        description:
          'Object storage is encrypted via AWS KMS SSE-KMS customer managed keys. Public access block is strictly enforced.',
        evidence: 'KMS Key ID: `arn:aws:kms:us-central1:74892:key/mlops-prod-master`. Public access ACL disabled.',
        remediationRecommendation: 'Key rotation scheduled every 90 days.',
        status: 'Remediated',
      });
    } else {
      list.push({
        id: 'find-s3-enc',
        ruleCode: 'GDPR-ART32',
        benchmark: 'GDPR-HIPAA',
        title: 'Unencrypted S3 Bucket or Public Ingress Exposure',
        targetType: 'Configuration',
        targetResource: 'S3: `s3://nexus-ml-artifacts/*`',
        severity: 'CRITICAL',
        description:
          'ML training datasets or model checkpoints stored without mandatory KMS encryption or with public bucket ACLs.',
        evidence: `s3EncryptionAtRest: ${config.s3EncryptionAtRest}, s3BlockPublicAccess: ${config.s3BlockPublicAccess}`,
        remediationRecommendation: 'Enforce default SSE-KMS bucket encryption and enable S3 Block Public Access.',
        canAutoRemediate: true,
        remediationKey: 's3EncryptionAtRest',
        status: remediatedIds.has('find-s3-enc') ? 'Remediated' : 'Open',
      });
    }

    // 9. Configuration Check: NIST AI RMF MAP 2.3 - Lineage & Provenance Tracking
    list.push({
      id: 'find-nist-map2.3',
      ruleCode: 'NIST-AIRMF-MAP2.3',
      benchmark: 'NIST-AIRMF',
      title: 'Full Lineage Graph: Git Commit + DVC Hash + Feature Snapshots',
      targetType: 'Audit Log',
      targetResource: 'Provenance Engine / MLflow Tracking',
      severity: 'PASS',
      description:
        'All trained model versions link deterministically to Git commit SHAs, DVC dataset hash states, and training hyperparameter artifacts.',
      evidence: 'Model registry v2.4.0 verified with commit `c89a01f` and DVC dataset tag `dvc-9a88bc3`.',
      remediationRecommendation: 'Audit trail satisfies NIST AI RMF reproducibility guidelines.',
      status: 'Remediated',
    });

    // 10. Configuration Check: Network Transport TLS & mTLS
    if (config.tlsVersionMinimum === 'TLS 1.3' && config.mTLSEnforced) {
      list.push({
        id: 'find-tls',
        ruleCode: 'SOC2-CC6.6',
        benchmark: 'SOC2',
        title: 'Model Serving Ingress Enforces TLS 1.3 & Mutual TLS (mTLS)',
        targetType: 'Infrastructure',
        targetResource: 'Istio Service Mesh Gateway',
        severity: 'PASS',
        description:
          'All incoming scoring requests and inter-service pod calls utilize strict mTLS with forward secrecy cipher suites.',
        evidence: 'TLS 1.3 enforced. Client certificate verification required for all private VPC peering nodes.',
        remediationRecommendation: 'Transport security satisfies FIPS 140-3 and SOC 2 requirements.',
        status: 'Remediated',
      });
    } else {
      list.push({
        id: 'find-tls',
        ruleCode: 'SOC2-CC6.6',
        benchmark: 'SOC2',
        title: 'Legacy TLS Protocols or Unencrypted Internal Service Mesh',
        targetType: 'Infrastructure',
        targetResource: 'Serving Gateway',
        severity: 'WARNING',
        description: 'Service mesh allows TLS 1.2 legacy handshakes or optional plaintext sidecar communication.',
        evidence: `tlsVersionMinimum: ${config.tlsVersionMinimum}, mTLSEnforced: ${config.mTLSEnforced}`,
        remediationRecommendation: 'Upgrade Envoy mesh gateway to reject TLS < 1.3 and require strict mTLS.',
        canAutoRemediate: true,
        remediationKey: 'mTLSEnforced',
        status: remediatedIds.has('find-tls') ? 'Remediated' : 'Open',
      });
    }

    // 11. Configuration Check: PII Scrubbing & Feature Store Anonymization
    if (config.piiMaskingEnabled) {
      list.push({
        id: 'find-pii-mask',
        ruleCode: 'GDPR-ART25',
        benchmark: 'GDPR-HIPAA',
        title: 'Feature Store PII Masking & Differential Privacy Anonymization',
        targetType: 'Configuration',
        targetResource: 'Feature Store: `customer_360_embeddings_v3`',
        severity: 'PASS',
        description:
          'Personally identifiable customer data is hashed with salted SHA-256 prior to online vector embedding ingestion.',
        evidence: 'PII masking filter active on incoming Redis & Milvus feature view writes.',
        remediationRecommendation: 'Review tokenization salt rotation policy annually.',
        status: 'Remediated',
      });
    } else {
      list.push({
        id: 'find-pii-mask',
        ruleCode: 'GDPR-ART25',
        benchmark: 'GDPR-HIPAA',
        title: 'Unmasked Sensitive PII in Online Feature Store Pipelines',
        targetType: 'Configuration',
        targetResource: 'Feature Store Ingestion',
        severity: 'CRITICAL',
        description:
          'Raw customer identifiers may be ingested into vector embeddings without tokenization, violating GDPR Art 25.',
        evidence: '`piiMaskingEnabled: false`.',
        remediationRecommendation: 'Activate automated regex and NLP-based PII scrubbing filter.',
        canAutoRemediate: true,
        remediationKey: 'piiMaskingEnabled',
        status: remediatedIds.has('find-pii-mask') ? 'Remediated' : 'Open',
      });
    }

    // 12. NIST AI RMF GOVERN 1.2: Separation of Duties & Least Privilege
    list.push({
      id: 'find-nist-gov1.2',
      ruleCode: 'NIST-AIRMF-GOV1.2',
      benchmark: 'NIST-AIRMF',
      title: 'Role-Based Access Control Separation of Duties Enforced',
      targetType: 'RBAC Policy',
      targetResource: 'RBAC Matrix (MLOps Admin vs Lead Data Scientist)',
      severity: 'PASS',
      description:
        'Granular permissions isolate production traffic modification from model training routines, avoiding single point of failure.',
      evidence: 'Lead Data Scientists are restricted to Staging deployments; production promotion restricted.',
      remediationRecommendation: 'Perform quarterly access matrix recertification.',
      status: 'Remediated',
    });

    return list;
  }, [auditLogs, config, remediatedIds]);

  // Filtered findings
  const filteredFindings = useMemo(() => {
    return evaluateFindings.filter((finding) => {
      // Severity filter
      if (selectedSeverity !== 'ALL' && finding.severity !== selectedSeverity) {
        return false;
      }
      // Benchmark filter
      if (selectedBenchmark !== 'ALL' && finding.benchmark !== selectedBenchmark) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = finding.title.toLowerCase().includes(query);
        const matchesCode = finding.ruleCode.toLowerCase().includes(query);
        const matchesTarget = finding.targetResource.toLowerCase().includes(query);
        const matchesDesc = finding.description.toLowerCase().includes(query);
        if (!matchesTitle && !matchesCode && !matchesTarget && !matchesDesc) {
          return false;
        }
      }
      return true;
    });
  }, [evaluateFindings, selectedSeverity, selectedBenchmark, searchQuery]);

  // Aggregate stats
  const totalFindings = evaluateFindings.length;
  const passCount = evaluateFindings.filter((f) => f.severity === 'PASS').length;
  const warningCount = evaluateFindings.filter((f) => f.severity === 'WARNING').length;
  const criticalCount = evaluateFindings.filter((f) => f.severity === 'CRITICAL').length;
  const complianceScore = Math.round((passCount / totalFindings) * 100);

  // Trigger simulated scan
  const handleTriggerScan = () => {
    setIsScanning(true);
    setScanProgress(10);
    setCurrentScanningBenchmark('Connecting to Cryptographic Audit Stream...');

    setTimeout(() => {
      setScanProgress(35);
      setCurrentScanningBenchmark('Evaluating SOC 2 Type II CC6/CC7 Security Controls...');
    }, 400);

    setTimeout(() => {
      setScanProgress(60);
      setCurrentScanningBenchmark('Auditing Kubernetes CIS v1.8 Pod Security Standards...');
    }, 800);

    setTimeout(() => {
      setScanProgress(85);
      setCurrentScanningBenchmark('Verifying EU AI Act (Art 12, 14) & NIST AI RMF Policies...');
    }, 1200);

    setTimeout(() => {
      setScanProgress(100);
      setIsScanning(false);
      setCurrentScanningBenchmark('Scan Complete!');
      const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
      setLastScanTimestamp(now);
    }, 1600);
  };

  // Auto-remediate a specific finding
  const handleAutoRemediate = (finding: SecurityBenchmarkFinding) => {
    if (finding.remediationKey) {
      const key = finding.remediationKey;
      setConfig((prev) => ({
        ...prev,
        [key]: true,
      }));
      setRemediatedIds((prev) => new Set(prev).add(finding.id));
    }
  };

  // Export report as JSON
  const handleExportReport = () => {
    const reportData = {
      reportTitle: 'NexusML Enterprise Compliance & Policy Audit Report',
      scanTimestamp: lastScanTimestamp,
      auditedByRole: userRole,
      overallScore: `${complianceScore}%`,
      grade: complianceScore >= 90 ? 'Grade A (Enterprise Ready)' : 'Grade B (Remediation Needed)',
      summary: {
        totalEvaluated: totalFindings,
        passed: passCount,
        warnings: warningCount,
        criticalViolations: criticalCount,
        scannedAuditLogEntries: auditLogs.length,
      },
      systemConfigurations: config,
      findings: evaluateFindings,
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `compliance-audit-scan-${Date.now()}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* TOOLBAR & SCAN LAUNCHER */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 p-5 rounded-2xl border border-slate-800 shadow-sm">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <ShieldCheck className="w-5 h-5 text-indigo-400" />
            </span>
            <h2 className="text-base font-bold text-white tracking-tight">
              Enterprise Compliance & Policy Scanner
            </h2>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              v2.8 Active
            </span>
          </div>
          <p className="text-xs text-slate-400 max-w-2xl">
            Continuously evaluates audit log event streams and infrastructure settings against predefined SOC2,
            CIS Kubernetes, EU AI Act, and NIST AI RMF benchmarks.
          </p>
        </div>

        <div className="flex items-center flex-wrap gap-2.5">
          <button
            onClick={() => setShowConfigDrawer(!showConfigDrawer)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all flex items-center gap-1.5 ${
              showConfigDrawer
                ? 'bg-slate-800 text-white border-slate-700'
                : 'bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-800'
            }`}
          >
            <Settings className="w-3.5 h-3.5 text-slate-400" />
            <span>Config Inspector</span>
          </button>

          <button
            onClick={handleExportReport}
            className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-950 text-slate-300 border border-slate-800 hover:bg-slate-800 transition-all flex items-center gap-1.5"
            title="Download JSON audit report"
          >
            <Download className="w-3.5 h-3.5 text-slate-400" />
            <span>Export Report</span>
          </button>

          <button
            onClick={handleTriggerScan}
            disabled={isScanning}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white shadow-lg shadow-indigo-500/20 transition-all flex items-center gap-2 disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
            <span>{isScanning ? 'Scanning Cluster...' : 'Run Compliance Scan'}</span>
          </button>
        </div>
      </div>

      {/* SCANNING PROGRESS OVERLAY / NOTIFICATION */}
      {isScanning && (
        <div className="bg-slate-900 border border-indigo-500/30 rounded-2xl p-4 shadow-lg animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="flex items-center justify-between text-xs mb-2">
            <div className="flex items-center gap-2 text-indigo-300 font-medium font-mono">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-400" />
              <span>{currentScanningBenchmark}</span>
            </div>
            <span className="font-bold text-white font-mono">{scanProgress}%</span>
          </div>
          <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
            <div
              className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 transition-all duration-300 rounded-full"
              style={{ width: `${scanProgress}%` }}
            />
          </div>
        </div>
      )}

      {/* SYSTEM CONFIGURATION INSPECTOR DRAWER (Collapsible) */}
      {showConfigDrawer && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Sliders className="w-4 h-4 text-indigo-400" />
                Live Configuration Settings Under Policy Audit
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Toggle configuration parameters below to see the scanner immediately test and identify security violations in real-time.
              </p>
            </div>
            <button
              onClick={() => setShowConfigDrawer(false)}
              className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
            >
              <ChevronUp className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
            {/* Toggle 1: Immutability */}
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-semibold text-white">Model Artifact Immutability</div>
                <div className="text-[10px] text-slate-400">Protects prod models from overwrite</div>
              </div>
              <button
                onClick={() =>
                  setConfig((prev) => ({
                    ...prev,
                    modelArtifactImmutability: !prev.modelArtifactImmutability,
                  }))
                }
                className={`w-10 h-5 rounded-full transition-colors relative flex items-center px-0.5 ${
                  config.modelArtifactImmutability ? 'bg-emerald-600' : 'bg-slate-700'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    config.modelArtifactImmutability ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Toggle 2: Dual Approval */}
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-semibold text-white">Dual Approval for Prod (EU AI Act)</div>
                <div className="text-[10px] text-slate-400">Requires secondary compliance sign-off</div>
              </div>
              <button
                onClick={() =>
                  setConfig((prev) => ({
                    ...prev,
                    requireDualApprovalForProd: !prev.requireDualApprovalForProd,
                  }))
                }
                className={`w-10 h-5 rounded-full transition-colors relative flex items-center px-0.5 ${
                  config.requireDualApprovalForProd ? 'bg-emerald-600' : 'bg-slate-700'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    config.requireDualApprovalForProd ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Toggle 3: Pod Security Admission */}
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-semibold text-white">PSA Restricted Profile (CIS K8s)</div>
                <div className="text-[10px] text-slate-400">Blocks privilege escalation in pods</div>
              </div>
              <button
                onClick={() =>
                  setConfig((prev) => ({
                    ...prev,
                    podSecurityAdmissionRestricted: !prev.podSecurityAdmissionRestricted,
                  }))
                }
                className={`w-10 h-5 rounded-full transition-colors relative flex items-center px-0.5 ${
                  config.podSecurityAdmissionRestricted ? 'bg-emerald-600' : 'bg-slate-700'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    config.podSecurityAdmissionRestricted ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Toggle 4: Container Run As Non Root */}
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-semibold text-white">Enforce Non-Root UID 10001</div>
                <div className="text-[10px] text-slate-400">Denies UID 0 root execution</div>
              </div>
              <button
                onClick={() =>
                  setConfig((prev) => ({
                    ...prev,
                    containerRunAsNonRoot: !prev.containerRunAsNonRoot,
                  }))
                }
                className={`w-10 h-5 rounded-full transition-colors relative flex items-center px-0.5 ${
                  config.containerRunAsNonRoot ? 'bg-emerald-600' : 'bg-slate-700'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    config.containerRunAsNonRoot ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Toggle 5: S3 Encryption at Rest */}
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-semibold text-white">S3 KMS Encryption & Block Public</div>
                <div className="text-[10px] text-slate-400">AES-256 SSE-KMS storage key</div>
              </div>
              <button
                onClick={() =>
                  setConfig((prev) => ({
                    ...prev,
                    s3EncryptionAtRest: !prev.s3EncryptionAtRest,
                  }))
                }
                className={`w-10 h-5 rounded-full transition-colors relative flex items-center px-0.5 ${
                  config.s3EncryptionAtRest ? 'bg-emerald-600' : 'bg-slate-700'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    config.s3EncryptionAtRest ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Toggle 6: Strict mTLS */}
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-semibold text-white">Strict mTLS & TLS 1.3 Ingress</div>
                <div className="text-[10px] text-slate-400">Cryptographic transport mesh</div>
              </div>
              <button
                onClick={() =>
                  setConfig((prev) => ({
                    ...prev,
                    mTLSEnforced: !prev.mTLSEnforced,
                  }))
                }
                className={`w-10 h-5 rounded-full transition-colors relative flex items-center px-0.5 ${
                  config.mTLSEnforced ? 'bg-emerald-600' : 'bg-slate-700'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    config.mTLSEnforced ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* COMPLIANCE & POLICY FINDINGS STATUS CARD (The Primary Executive Status Card) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-md relative overflow-hidden">
        <div className="absolute -right-16 -top-16 w-56 h-56 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* Gauge & Score Column */}
          <div className="lg:col-span-4 flex items-center gap-5 border-b lg:border-b-0 lg:border-r border-slate-800 pb-5 lg:pb-0 lg:pr-5">
            <div className="relative w-24 h-24 flex-shrink-0 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                <path
                  className="text-slate-800"
                  strokeWidth="3.5"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                <path
                  className={
                    complianceScore >= 90
                      ? 'text-emerald-400'
                      : complianceScore >= 75
                      ? 'text-amber-400'
                      : 'text-red-400'
                  }
                  strokeDasharray={`${complianceScore}, 100`}
                  strokeLinecap="round"
                  strokeWidth="3.5"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
              </svg>
              <div className="absolute flex flex-col items-center justify-center text-center">
                <span className="text-2xl font-black text-white font-mono">{complianceScore}%</span>
                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Score</span>
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span
                  className={`px-2.5 py-0.5 rounded-full text-xs font-bold font-mono tracking-wide ${
                    criticalCount === 0 && warningCount === 0
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : criticalCount > 0
                      ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  }`}
                >
                  {criticalCount === 0 && warningCount === 0
                    ? 'FULL COMPLIANCE'
                    : criticalCount > 0
                    ? 'CRITICAL DEFICIT'
                    : 'AUDIT WARNINGS'}
                </span>
              </div>
              <h3 className="text-sm font-bold text-white">Enterprise Security Posture</h3>
              <p className="text-[11px] text-slate-400">
                Audited against CIS K8s v1.8, SOC 2 Type II, EU AI Act, & NIST AI RMF.
              </p>
              <div className="text-[10px] text-slate-500 font-mono">Last Evaluated: {lastScanTimestamp}</div>
            </div>
          </div>

          {/* Quick Metrics Breakdown */}
          <div className="lg:col-span-8 grid grid-cols-2 sm:grid-cols-4 gap-3">
            {/* Metric 1: Passed */}
            <div
              onClick={() => setSelectedSeverity(selectedSeverity === 'PASS' ? 'ALL' : 'PASS')}
              className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                selectedSeverity === 'PASS'
                  ? 'bg-emerald-950/40 border-emerald-500/50 shadow-sm'
                  : 'bg-slate-950 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Passed</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-xl font-bold font-mono text-emerald-400">{passCount}</div>
              <div className="text-[10px] text-slate-500">Verified Benchmarks</div>
            </div>

            {/* Metric 2: Warnings */}
            <div
              onClick={() => setSelectedSeverity(selectedSeverity === 'WARNING' ? 'ALL' : 'WARNING')}
              className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                selectedSeverity === 'WARNING'
                  ? 'bg-amber-950/40 border-amber-500/50 shadow-sm'
                  : 'bg-slate-950 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Warnings</span>
                <AlertTriangle className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-xl font-bold font-mono text-amber-400">{warningCount}</div>
              <div className="text-[10px] text-slate-500">Policy Exceptions</div>
            </div>

            {/* Metric 3: Critical Violations */}
            <div
              onClick={() => setSelectedSeverity(selectedSeverity === 'CRITICAL' ? 'ALL' : 'CRITICAL')}
              className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                selectedSeverity === 'CRITICAL'
                  ? 'bg-red-950/40 border-red-500/50 shadow-sm'
                  : 'bg-slate-950 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Violations</span>
                <AlertOctagon className="w-4 h-4 text-red-400" />
              </div>
              <div className="text-xl font-bold font-mono text-red-400">{criticalCount}</div>
              <div className="text-[10px] text-slate-500">Immediate Action</div>
            </div>

            {/* Metric 4: Audit Logs Scanned */}
            <div className="p-3.5 rounded-xl border bg-slate-950 border-slate-800">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Audit Scope</span>
                <FileCheck className="w-4 h-4 text-indigo-400" />
              </div>
              <div className="text-xl font-bold font-mono text-white">{auditLogs.length}</div>
              <div className="text-[10px] text-slate-500">Live Audit Logs Inspected</div>
            </div>
          </div>
        </div>
      </div>

      {/* FILTER & BENCHMARK NAVIGATION */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-900/60 p-3 rounded-2xl border border-slate-800">
        <div className="flex items-center flex-wrap gap-1.5">
          <button
            onClick={() => setSelectedBenchmark('ALL')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
              selectedBenchmark === 'ALL'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            All Benchmarks ({evaluateFindings.length})
          </button>
          <button
            onClick={() => setSelectedBenchmark('SOC2')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
              selectedBenchmark === 'SOC2'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            SOC 2 Type II
          </button>
          <button
            onClick={() => setSelectedBenchmark('CIS-K8S')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
              selectedBenchmark === 'CIS-K8S'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            CIS Kubernetes
          </button>
          <button
            onClick={() => setSelectedBenchmark('EU-AI-ACT')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
              selectedBenchmark === 'EU-AI-ACT'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            EU AI Act
          </button>
          <button
            onClick={() => setSelectedBenchmark('NIST-AIRMF')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
              selectedBenchmark === 'NIST-AIRMF'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            NIST AI RMF
          </button>
          <button
            onClick={() => setSelectedBenchmark('GDPR-HIPAA')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
              selectedBenchmark === 'GDPR-HIPAA'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            GDPR / HIPAA
          </button>
        </div>

        {/* Search Input */}
        <div className="relative min-w-[240px]">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search findings, rules, targets..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 pl-9 pr-3 py-1.5 rounded-xl border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* FINDINGS DETAILED CARD LIST */}
      <div className="space-y-3">
        {filteredFindings.length === 0 ? (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-400">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2 opacity-80" />
            <p className="text-sm font-semibold text-white">No Matching Security Findings</p>
            <p className="text-xs mt-1">All scanned benchmarks satisfied the selected criteria.</p>
          </div>
        ) : (
          filteredFindings.map((finding) => {
            const isExpanded = expandedFindingId === finding.id;

            return (
              <div
                key={finding.id}
                className={`bg-slate-900 rounded-2xl border transition-all ${
                  finding.severity === 'CRITICAL'
                    ? 'border-red-900/40 bg-red-950/10'
                    : finding.severity === 'WARNING'
                    ? 'border-amber-900/40 bg-amber-950/10'
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* Header Row */}
                <div
                  onClick={() => setExpandedFindingId(isExpanded ? null : finding.id)}
                  className="p-4 flex items-center justify-between gap-4 cursor-pointer"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {/* Severity Icon */}
                    <div className="flex-shrink-0">
                      {finding.severity === 'PASS' && (
                        <div className="w-8 h-8 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                          <CheckCircle2 className="w-4 h-4" />
                        </div>
                      )}
                      {finding.severity === 'WARNING' && (
                        <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                          <AlertTriangle className="w-4 h-4" />
                        </div>
                      )}
                      {finding.severity === 'CRITICAL' && (
                        <div className="w-8 h-8 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-400 animate-pulse">
                          <AlertOctagon className="w-4 h-4" />
                        </div>
                      )}
                    </div>

                    {/* Title & Metadata */}
                    <div className="min-w-0">
                      <div className="flex items-center flex-wrap gap-2 mb-1">
                        <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-indigo-300">
                          {finding.ruleCode}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded font-semibold bg-slate-800 text-slate-300">
                          {finding.benchmark}
                        </span>
                        <span className="text-[10px] font-mono text-slate-400">
                          Target: <span className="text-slate-200">{finding.targetResource}</span>
                        </span>
                      </div>
                      <h4 className="text-sm font-bold text-white truncate">{finding.title}</h4>
                    </div>
                  </div>

                  {/* Actions / Status Pill */}
                  <div className="flex items-center gap-3 flex-shrink-0">
                    {finding.status === 'Remediated' && (
                      <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 flex items-center gap-1">
                        <Check className="w-3 h-3" /> Remediated
                      </span>
                    )}

                    {finding.canAutoRemediate && finding.severity !== 'PASS' && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleAutoRemediate(finding);
                        }}
                        className="px-3 py-1 rounded-lg text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white transition-all shadow flex items-center gap-1.5"
                      >
                        <Sparkles className="w-3 h-3 text-indigo-200" />
                        <span>Quick Remediate</span>
                      </button>
                    )}

                    <span className="text-slate-500 p-1 hover:text-white transition-colors">
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </span>
                  </div>
                </div>

                {/* Expanded Details Body */}
                {isExpanded && (
                  <div className="px-5 pb-5 pt-1 border-t border-slate-800/80 space-y-3.5 text-xs text-slate-300">
                    <div className="p-3 bg-slate-950/70 rounded-xl border border-slate-800">
                      <div className="font-semibold text-slate-200 mb-1">Audit Finding Description:</div>
                      <p className="text-slate-400 leading-relaxed">{finding.description}</p>
                    </div>

                    <div className="p-3 bg-slate-950/70 rounded-xl border border-slate-800 space-y-1">
                      <div className="font-semibold text-indigo-300 flex items-center gap-1.5">
                        <FileCheck className="w-3.5 h-3.5 text-indigo-400" />
                        <span>Inspected Telemetry & Evidence:</span>
                      </div>
                      <p className="text-slate-300 font-mono text-[11px] bg-slate-900/90 p-2.5 rounded-lg border border-slate-800/80 overflow-x-auto">
                        {finding.evidence}
                      </p>
                    </div>

                    <div className="p-3 bg-indigo-950/20 rounded-xl border border-indigo-900/30 flex items-start gap-2.5">
                      <Info className="w-4 h-4 text-indigo-400 flex-shrink-0 mt-0.5" />
                      <div className="space-y-1">
                        <div className="font-bold text-indigo-200 text-xs">Policy Remediation Guide</div>
                        <p className="text-slate-300 text-[11px] leading-relaxed">
                          {finding.remediationRecommendation}
                        </p>
                      </div>
                    </div>

                    {/* Copilot Deep Dive Link */}
                    {onOpenCopilot && (
                      <div className="flex justify-end pt-1">
                        <button
                          onClick={() =>
                            onOpenCopilot(
                              `Explain compliance remediation for ${finding.ruleCode} (${finding.title}) and recommend policy updates.`
                            )
                          }
                          className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 hover:underline"
                        >
                          <Sparkles className="w-3 h-3 text-indigo-400" />
                          <span>Ask Copilot for Remediation Plan</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
