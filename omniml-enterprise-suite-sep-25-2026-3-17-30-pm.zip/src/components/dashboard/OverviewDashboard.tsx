import React from 'react';
import {
  Layers,
  Zap,
  Activity,
  GitFork,
  Cpu,
  ShieldCheck,
  TrendingUp,
  AlertTriangle,
  Play,
  CheckCircle2,
  Clock,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import {
  RegisteredModel,
  MlPipelineRun,
  ServingEndpoint,
  DriftMetric,
  AuditLogItem,
} from '../../types/mlops';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  BarChart,
  Bar,
} from 'recharts';

interface OverviewDashboardProps {
  models: RegisteredModel[];
  pipelines: MlPipelineRun[];
  endpoints: ServingEndpoint[];
  driftMetrics: DriftMetric[];
  auditLogs: AuditLogItem[];
  onNavigateTab: (tab: any) => void;
  onOpenCopilot: () => void;
}

const TELEMETRY_DATA = [
  { time: '00:00', qps: 18200, latencyP99: 8.2, gpuLoad: 78 },
  { time: '04:00', qps: 12400, latencyP99: 6.9, gpuLoad: 64 },
  { time: '08:00', qps: 24100, latencyP99: 7.5, gpuLoad: 89 },
  { time: '12:00', qps: 28040, latencyP99: 7.8, gpuLoad: 87 },
  { time: '16:00', qps: 26500, latencyP99: 7.4, gpuLoad: 85 },
  { time: '20:00', qps: 22100, latencyP99: 7.1, gpuLoad: 80 },
];

export const OverviewDashboard: React.FC<OverviewDashboardProps> = ({
  models,
  pipelines,
  endpoints,
  driftMetrics,
  auditLogs,
  onNavigateTab,
  onOpenCopilot,
}) => {
  const activePipeline = pipelines.find((p) => p.status === 'running') || pipelines[0];
  const criticalDrifts = driftMetrics.filter((d) => d.status === 'Critical' || d.status === 'Warning');

  return (
    <div className="p-6 space-y-6 text-slate-100 max-w-[1600px] mx-auto">
      {/* Top Banner / Hero Metric Strip */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-5 rounded-2xl border border-indigo-500/30 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <h1 className="text-xl font-bold tracking-tight text-white">
              Enterprise Infrastructure Status: Optimal
            </h1>
          </div>
          <p className="text-xs text-slate-300">
            Real-time telemetry across 3 regional clusters. 28,040 QPS served with 7.8ms P99 SLA.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => onNavigateTab('pipelines')}
            className="flex items-center space-x-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 transition-all"
          >
            <GitFork className="w-4 h-4 text-emerald-400" />
            <span>View Active Pipeline</span>
          </button>

          <button
            onClick={onOpenCopilot}
            className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white shadow-lg shadow-indigo-600/30 transition-all border border-indigo-400/40"
          >
            <Sparkles className="w-4 h-4 text-yellow-300" />
            <span>Ask NexusCopilot</span>
          </button>
        </div>
      </div>

      {/* Grid of Key Enterprise Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Stat 1: Registered Models */}
        <div
          onClick={() => onNavigateTab('registry')}
          className="bg-slate-900/90 p-4 rounded-xl border border-slate-800 hover:border-indigo-500/50 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Model Registry</span>
            <div className="p-2 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 group-hover:scale-110 transition-transform">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-extrabold text-white">{models.length}</span>
            <span className="text-xs font-medium text-emerald-400 flex items-center">
              <TrendingUp className="w-3 h-3 mr-0.5" /> +2 new v2.5.0
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">100% compliant with EU AI Act</p>
        </div>

        {/* Stat 2: Active Throughput */}
        <div
          onClick={() => onNavigateTab('serving')}
          className="bg-slate-900/90 p-4 rounded-xl border border-slate-800 hover:border-cyan-500/50 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Serving Throughput</span>
            <div className="p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 group-hover:scale-110 transition-transform">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-extrabold text-white">28.0k QPS</span>
            <span className="text-xs font-mono text-cyan-300">7.8ms P99</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">3 active gateways (Canary active)</p>
        </div>

        {/* Stat 3: Model Drift Alerts */}
        <div
          onClick={() => onNavigateTab('monitoring')}
          className="bg-slate-900/90 p-4 rounded-xl border border-slate-800 hover:border-amber-500/50 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Drift & Observability</span>
            <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 group-hover:scale-110 transition-transform">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-extrabold text-amber-400">{criticalDrifts.length} Alert</span>
            <span className="text-xs text-amber-300 bg-amber-500/20 px-1.5 py-0.5 rounded border border-amber-500/30">
              PSI = 0.218
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Auto-retrain pipeline triggered</p>
        </div>

        {/* Stat 4: GPU Cluster Load */}
        <div
          onClick={() => onNavigateTab('cluster')}
          className="bg-slate-900/90 p-4 rounded-xl border border-slate-800 hover:border-purple-500/50 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">GPU Cluster Load</span>
            <div className="p-2 rounded-lg bg-purple-500/10 border border-purple-500/20 text-purple-400 group-hover:scale-110 transition-transform">
              <Cpu className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-extrabold text-white">87.5%</span>
            <span className="text-xs text-purple-300">28/32 H100s</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Ray Distributed Cluster healthy</p>
        </div>
      </div>

      {/* Main Charts & Pipeline Active Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Telemetry Chart */}
        <div className="lg:col-span-2 bg-slate-900/90 p-5 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Activity className="w-4 h-4 text-indigo-400" />
                Live Ingestion & Serving Performance (24h)
              </h2>
              <p className="text-xs text-slate-400">
                Throughput QPS vs Latency P99 SLA thresholds
              </p>
            </div>
            <span className="text-[11px] font-mono bg-slate-800 px-2.5 py-1 rounded text-slate-300 border border-slate-700">
              Interval: 5m
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={TELEMETRY_DATA} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="qpsGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="latencyGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: '#f8fafc',
                  }}
                />
                <Area type="monotone" dataKey="qps" stroke="#6366f1" strokeWidth={2} fillOpacity={1} fill="url(#qpsGrad)" name="Throughput (QPS)" />
                <Area type="monotone" dataKey="latencyP99" stroke="#06b6d4" strokeWidth={2} fillOpacity={1} fill="url(#latencyGrad)" name="P99 Latency (ms)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right 1 Col: Active ML Pipeline Progress Card */}
        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800 flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2">
                <GitFork className="w-4 h-4 text-emerald-400" />
                <h2 className="text-sm font-bold text-white">Active ML Pipeline</h2>
              </div>
              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                Running
              </span>
            </div>

            {activePipeline && (
              <div className="space-y-3">
                <div>
                  <div className="text-xs font-semibold text-slate-200">{activePipeline.pipelineName}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5 flex items-center justify-between">
                    <span>Trigger: {activePipeline.triggerType}</span>
                    <span className="font-mono text-slate-300">Commit: {activePipeline.gitCommitHash}</span>
                  </div>
                </div>

                {/* Steps Visual List */}
                <div className="space-y-2 mt-2">
                  {activePipeline.steps.slice(0, 5).map((step, idx) => (
                    <div
                      key={step.id}
                      className="flex items-center justify-between bg-slate-950 p-2 rounded-lg border border-slate-800/80 text-xs"
                    >
                      <div className="flex items-center space-x-2">
                        {step.status === 'succeeded' ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        ) : step.status === 'running' ? (
                          <div className="w-3.5 h-3.5 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <Clock className="w-3.5 h-3.5 text-slate-600" />
                        )}
                        <span className={step.status === 'running' ? 'font-semibold text-indigo-300' : 'text-slate-300'}>
                          Step {idx + 1}: {step.name}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {step.durationSec ? `${step.durationSec}s` : step.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <button
            onClick={() => onNavigateTab('pipelines')}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-xs font-semibold text-slate-200 flex items-center justify-center space-x-1.5 border border-slate-700 transition-all"
          >
            <span>Open Pipeline DAG Visualizer</span>
            <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
          </button>
        </div>
      </div>

      {/* Audit Log Stream */}
      <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            Live Enterprise Audit Log & Governance Activity
          </h2>
          <button
            onClick={() => onNavigateTab('governance')}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-medium"
          >
            View Full Audit Matrix →
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3">User & Role</th>
                <th className="py-2.5 px-3">Action</th>
                <th className="py-2.5 px-3">Target Resource</th>
                <th className="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {auditLogs.slice(0, 4).map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-3 text-slate-400">{log.timestamp}</td>
                  <td className="py-2.5 px-3 font-sans font-medium text-slate-200">{log.user}</td>
                  <td className="py-2.5 px-3 font-bold text-indigo-300">{log.action}</td>
                  <td className="py-2.5 px-3 text-slate-300 font-sans">{log.targetResource}</td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        log.status === 'Success'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : log.status === 'Denied'
                          ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      }`}
                    >
                      {log.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
