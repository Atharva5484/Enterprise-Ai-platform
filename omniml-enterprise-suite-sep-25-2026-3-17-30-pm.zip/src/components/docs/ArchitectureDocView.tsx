import React, { useState } from 'react';
import {
  FileText,
  GitBranch,
  Database,
  Layers,
  Server,
  Shield,
  Zap,
  Code,
  Copy,
  Check,
  Play,
  Terminal,
  Cpu,
  Globe,
  ArrowRight,
  Box,
  Lock,
  Activity,
  CheckCircle2,
} from 'lucide-react';

export const ArchitectureDocView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'diagrams' | 'openapi'>('diagrams');
  const [activeDiagram, setActiveDiagram] = useState<'hld' | 'lld' | 'er' | 'sequence' | 'multicloud'>('hld');

  // OpenAPI Tester State
  const [selectedEndpoint, setSelectedEndpoint] = useState<string>('POST /api/eval-prompt');
  const [requestBody, setRequestBody] = useState<string>(
    JSON.stringify(
      {
        promptText: "You are an AI financial auditor. Analyze context: {inputContext}",
        sampleInput: "Company: Acme Corp, Wire Transfer: $2,450,000",
      },
      null,
      2
    )
  );
  const [responseOutput, setResponseOutput] = useState<string | null>(null);
  const [isExecutingApi, setIsExecutingApi] = useState<boolean>(false);
  const [copiedCurl, setCopiedCurl] = useState<boolean>(false);

  const handleTestApi = async () => {
    setIsExecutingApi(true);
    setResponseOutput(null);

    try {
      if (selectedEndpoint.includes('/api/eval-prompt')) {
        const parsed = JSON.parse(requestBody);
        const res = await fetch('/api/eval-prompt', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(parsed),
        });
        const data = await res.json();
        setResponseOutput(JSON.stringify(data, null, 2));
      } else if (selectedEndpoint.includes('/api/health')) {
        const res = await fetch('/api/health');
        const data = await res.json();
        setResponseOutput(JSON.stringify(data, null, 2));
      } else {
        // Mock execution for demo endpoints
        setTimeout(() => {
          setResponseOutput(
            JSON.stringify(
              {
                status: 200,
                message: "Mock enterprise API endpoint response executed successfully.",
                timestamp: new Date().toISOString(),
                requestId: `req-${Math.random().toString(36).substring(2, 9)}`,
              },
              null,
              2
            )
          );
          setIsExecutingApi(false);
        }, 600);
        return;
      }
    } catch (err: any) {
      setResponseOutput(JSON.stringify({ error: err.message }, null, 2));
    } finally {
      setIsExecutingApi(false);
    }
  };

  const handleCopyCurl = () => {
    const curl = `curl -X POST "https://nexusml.io/api/eval-prompt" \\
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiI..." \\
  -H "Content-Type: application/json" \\
  -d '${requestBody.replace(/\n/g, '')}'`;
    navigator.clipboard.writeText(curl);
    setCopiedCurl(true);
    setTimeout(() => setCopiedCurl(false), 2000);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100 max-w-[1600px] mx-auto">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 p-5 rounded-2xl border border-slate-800">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-indigo-400" />
            Enterprise Architecture & OpenAPI Documentation
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Interactive High-Level/Low-Level design diagrams, ER schemas, sequence flows, and live Swagger/OpenAPI test suite.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center space-x-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800 text-xs font-mono">
          <button
            onClick={() => setActiveTab('diagrams')}
            className={`px-3.5 py-1.5 rounded-lg font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'diagrams'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <GitBranch className="w-3.5 h-3.5" />
            <span>Architecture Diagrams</span>
          </button>

          <button
            onClick={() => setActiveTab('openapi')}
            className={`px-3.5 py-1.5 rounded-lg font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'openapi'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>OpenAPI / Swagger Explorer</span>
          </button>
        </div>
      </div>

      {activeTab === 'diagrams' ? (
        <div className="space-y-6">
          {/* Sub-Diagram Selector */}
          <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
            {[
              { id: 'hld', label: 'HLD (High-Level Design)', icon: Layers },
              { id: 'lld', label: 'LLD (Serving Engine)', icon: Cpu },
              { id: 'er', label: 'ER Database Schema', icon: Database },
              { id: 'sequence', label: 'Inference Sequence Diagram', icon: GitBranch },
              { id: 'multicloud', label: 'Multi-Cloud & GitOps Topology', icon: Globe },
            ].map((d) => {
              const Icon = d.icon;
              const isSelected = activeDiagram === d.id;
              return (
                <button
                  key={d.id}
                  onClick={() => setActiveDiagram(d.id as any)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 border ${
                    isSelected
                      ? 'bg-indigo-600/30 text-indigo-200 border-indigo-500/60 shadow'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-slate-200'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{d.label}</span>
                </button>
              );
            })}
          </div>

          {/* Diagram Canvas Box */}
          <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-6 shadow-2xl">
            {activeDiagram === 'hld' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <h2 className="text-sm font-bold text-white flex items-center gap-2">
                      <Layers className="w-4 h-4 text-indigo-400" />
                      High-Level Platform Architecture (HLD)
                    </h2>
                    <p className="text-xs text-slate-400">
                      End-to-end request routing from client SDKs to edge API gateways, Ray clusters, and vector feature stores.
                    </p>
                  </div>
                  <span className="px-2.5 py-1 rounded bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-mono">
                    System v3.4.0
                  </span>
                </div>

                {/* HLD Flow Diagram Blocks */}
                <div className="grid grid-cols-1 md:grid-cols-5 gap-3 font-mono text-xs">
                  {/* Step 1: Clients */}
                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3 flex flex-col justify-between">
                    <div className="space-y-1">
                      <span className="text-[10px] text-indigo-400 uppercase font-bold">1. Ingress Layer</span>
                      <h3 className="font-bold text-white">Client Apps & SDKs</h3>
                    </div>
                    <ul className="text-[11px] text-slate-400 space-y-1">
                      <li>• React Web Portal</li>
                      <li>• Python SDK Client</li>
                      <li>• REST/gRPC Clients</li>
                    </ul>
                    <div className="pt-2 border-t border-slate-800/80 text-[10px] text-slate-500">
                      TLS 1.3 mTLS Encrypted
                    </div>
                  </div>

                  {/* Step 2: Gateway */}
                  <div className="p-4 bg-slate-950 rounded-xl border border-indigo-500/40 space-y-3 flex flex-col justify-between relative">
                    <div className="space-y-1">
                      <span className="text-[10px] text-indigo-400 uppercase font-bold">2. Security Gateway</span>
                      <h3 className="font-bold text-white">API Gateway & WAF</h3>
                    </div>
                    <ul className="text-[11px] text-slate-400 space-y-1">
                      <li>• OAuth2 / JWT Auth</li>
                      <li>• Token Bucket Rate Limiter</li>
                      <li>• HashiCorp Vault Secrets</li>
                    </ul>
                    <div className="pt-2 border-t border-slate-800/80 text-[10px] text-emerald-400 font-bold">
                      Shield & DDoS Protection
                    </div>
                  </div>

                  {/* Step 3: Compute */}
                  <div className="p-4 bg-slate-950 rounded-xl border border-cyan-500/40 space-y-3 flex flex-col justify-between">
                    <div className="space-y-1">
                      <span className="text-[10px] text-cyan-400 uppercase font-bold">3. Execution Layer</span>
                      <h3 className="font-bold text-white">Serving & Ray Worker</h3>
                    </div>
                    <ul className="text-[11px] text-slate-400 space-y-1">
                      <li>• Triton/vLLM Serving</li>
                      <li>• Ray Distributed Cluster</li>
                      <li>• MLflow Experiment Engine</li>
                    </ul>
                    <div className="pt-2 border-t border-slate-800/80 text-[10px] text-cyan-300 font-bold">
                      Auto-scaling H100 GPUs
                    </div>
                  </div>

                  {/* Step 4: Storage */}
                  <div className="p-4 bg-slate-950 rounded-xl border border-purple-500/40 space-y-3 flex flex-col justify-between">
                    <div className="space-y-1">
                      <span className="text-[10px] text-purple-400 uppercase font-bold">4. Data Engine</span>
                      <h3 className="font-bold text-white">Feast & Vector DB</h3>
                    </div>
                    <ul className="text-[11px] text-slate-400 space-y-1">
                      <li>• Redis Online Cache</li>
                      <li>• Pinecone / Qdrant RAG</li>
                      <li>• DVC Artifact Store</li>
                    </ul>
                    <div className="pt-2 border-t border-slate-800/80 text-[10px] text-purple-300 font-bold">
                      Sub-5ms Cache Lookup
                    </div>
                  </div>

                  {/* Step 5: Observability */}
                  <div className="p-4 bg-slate-950 rounded-xl border border-emerald-500/40 space-y-3 flex flex-col justify-between">
                    <div className="space-y-1">
                      <span className="text-[10px] text-emerald-400 uppercase font-bold">5. Governance</span>
                      <h3 className="font-bold text-white">Audit & Monitoring</h3>
                    </div>
                    <ul className="text-[11px] text-slate-400 space-y-1">
                      <li>• OpenTelemetry Traces</li>
                      <li>• Evidently Drift Engine</li>
                      <li>• Cryptographic Vault Logs</li>
                    </ul>
                    <div className="pt-2 border-t border-slate-800/80 text-[10px] text-emerald-400 font-bold">
                      SOC2 & EU AI Act
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeDiagram === 'lld' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <h2 className="text-sm font-bold text-white flex items-center gap-2">
                      <Cpu className="w-4 h-4 text-cyan-400" />
                      Low-Level Serving Engine Micro-Architecture (LLD)
                    </h2>
                    <p className="text-xs text-slate-400">
                      Triton Inference Server execution loop with dynamic batching and GPU VRAM memory paging.
                    </p>
                  </div>
                </div>

                <div className="p-5 bg-slate-950 rounded-xl border border-slate-800 space-y-4 font-mono text-xs">
                  <div className="p-3 bg-slate-900 rounded-lg border border-cyan-500/30 flex items-center justify-between">
                    <span className="text-cyan-300 font-bold">gRPC / HTTP Inference Request</span>
                    <ArrowRight className="w-4 h-4 text-slate-500" />
                    <span className="text-slate-200">Dynamic Batching Scheduler (Window: 5ms, Max: 64)</span>
                    <ArrowRight className="w-4 h-4 text-slate-500" />
                    <span className="text-purple-300 font-bold">CUDA Stream Dispatcher</span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 space-y-1">
                      <span className="text-[10px] text-slate-400 uppercase block">Memory Paging</span>
                      <strong className="text-white block">vLLM PagedAttention</strong>
                      <p className="text-[11px] text-slate-400">96% reduction in KV cache fragmentation across continuous batching.</p>
                    </div>

                    <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 space-y-1">
                      <span className="text-[10px] text-slate-400 uppercase block">Model Repositories</span>
                      <strong className="text-white block">On-Demand S3 Sync</strong>
                      <p className="text-[11px] text-slate-400">Zero-downtime hot-reloading of ONNX/TensorRT compiled weights.</p>
                    </div>

                    <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 space-y-1">
                      <span className="text-[10px] text-slate-400 uppercase block">Hardware Accelerators</span>
                      <strong className="text-white block">NVIDIA MPS Partitioning</strong>
                      <p className="text-[11px] text-slate-400">Multi-Process Service sharing 1x H100 among 4 isolated instances.</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeDiagram === 'er' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <h2 className="text-sm font-bold text-white flex items-center gap-2">
                      <Database className="w-4 h-4 text-indigo-400" />
                      Database Entity-Relationship (ER) Diagram
                    </h2>
                    <p className="text-xs text-slate-400">
                      PostgreSQL relational schema binding Models, Versions, Feature Groups, Datasets, and Audit Trails.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
                  {/* Entity 1 */}
                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <span className="font-bold text-indigo-300">registered_models</span>
                      <span className="text-[10px] text-slate-500">PK: id</span>
                    </div>
                    <ul className="text-[11px] text-slate-400 space-y-1">
                      <li>• id: uuid (PK)</li>
                      <li>• name: varchar(255)</li>
                      <li>• owner_id: uuid (FK)</li>
                      <li>• description: text</li>
                      <li>• created_at: timestamptz</li>
                    </ul>
                  </div>

                  {/* Entity 2 */}
                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <span className="font-bold text-indigo-300">model_versions</span>
                      <span className="text-[10px] text-slate-500">FK: model_id</span>
                    </div>
                    <ul className="text-[11px] text-slate-400 space-y-1">
                      <li>• version_id: uuid (PK)</li>
                      <li>• model_id: uuid (FK)</li>
                      <li>• version_tag: varchar(32)</li>
                      <li>• stage: varchar(32)</li>
                      <li>• artifact_uri: text</li>
                      <li>• f1_score: numeric(5,4)</li>
                    </ul>
                  </div>

                  {/* Entity 3 */}
                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <span className="font-bold text-emerald-300">audit_logs</span>
                      <span className="text-[10px] text-slate-500">Immutable</span>
                    </div>
                    <ul className="text-[11px] text-slate-400 space-y-1">
                      <li>• log_id: uuid (PK)</li>
                      <li>• timestamp: timestamptz</li>
                      <li>• user_email: varchar(255)</li>
                      <li>• action: varchar(128)</li>
                      <li>• target_resource: text</li>
                      <li>• sha256_hash: text</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {activeDiagram === 'sequence' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <h2 className="text-sm font-bold text-white flex items-center gap-2">
                      <GitBranch className="w-4 h-4 text-purple-400" />
                      Inference & Audit Sequence Lifecycle
                    </h2>
                    <p className="text-xs text-slate-400">
                      Step-by-step messaging flow between API Client, Auth Middleware, Triton Model Server, and Audit Vault.
                    </p>
                  </div>
                </div>

                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3 font-mono text-xs">
                  {[
                    { step: '01', from: 'Client App', to: 'API Gateway', msg: 'POST /api/v1/predict (JWT Header)', status: '200 Auth OK' },
                    { step: '02', from: 'API Gateway', to: 'Rate Limiter', msg: 'Check Token Bucket (1000 req/min)', status: 'Within Quota' },
                    { step: '03', from: 'API Gateway', to: 'Feast Feature Store', msg: 'Get Online Features (entity_id=8923)', status: '4.2ms Cache Hit' },
                    { step: '04', from: 'API Gateway', to: 'Triton Serving Engine', msg: 'Inference Request (Tensor Inputs)', status: '11.8ms Execution' },
                    { step: '05', from: 'Triton Serving Engine', to: 'Audit Vault & Kafka', msg: 'Emit Cryptographic Log Event', status: 'Async Ack' },
                    { step: '06', from: 'API Gateway', to: 'Client App', msg: 'Inference Output Payload + SLA Header', status: 'Completed (18ms Total)' },
                  ].map((seq) => (
                    <div key={seq.step} className="p-3 bg-slate-900 rounded-lg border border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center space-x-3">
                        <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold">{seq.step}</span>
                        <span className="text-slate-300">{seq.from}</span>
                        <ArrowRight className="w-3.5 h-3.5 text-slate-500" />
                        <span className="text-indigo-400 font-bold">{seq.to}</span>
                        <span className="text-slate-400 font-sans">"{seq.msg}"</span>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-bold text-[10px]">
                        {seq.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeDiagram === 'multicloud' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <h2 className="text-sm font-bold text-white flex items-center gap-2">
                      <Globe className="w-4 h-4 text-emerald-400" />
                      Multi-Cloud Topology & ArgoCD GitOps Deployment
                    </h2>
                    <p className="text-xs text-slate-400">
                      Cross-cloud failover infrastructure across AWS EKS, GCP Cloud Run, and Azure AKS synchronized via Terraform.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
                  <div className="p-4 bg-slate-950 rounded-xl border border-amber-500/40 space-y-2">
                    <span className="text-[10px] text-amber-400 uppercase font-bold">Primary Region</span>
                    <h3 className="font-bold text-white">AWS us-east-1 (EKS)</h3>
                    <p className="text-[11px] text-slate-400">Hosting GPU worker nodes, vLLM inference instances, and primary PostgreSQL DB.</p>
                  </div>

                  <div className="p-4 bg-slate-950 rounded-xl border border-blue-500/40 space-y-2">
                    <span className="text-[10px] text-blue-400 uppercase font-bold">Secondary Failover</span>
                    <h3 className="font-bold text-white">GCP europe-west1 (Cloud Run)</h3>
                    <p className="text-[11px] text-slate-400">Automated active-active failover endpoint running lightweight CPU model fallbacks.</p>
                  </div>

                  <div className="p-4 bg-slate-950 rounded-xl border border-indigo-500/40 space-y-2">
                    <span className="text-[10px] text-indigo-400 uppercase font-bold">GitOps Control</span>
                    <h3 className="font-bold text-white">ArgoCD & Terraform</h3>
                    <p className="text-[11px] text-slate-400">Continuous declarative deployment from GitHub main branch with automated canary rollout.</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        /* OpenAPI / Swagger Explorer View */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 font-mono">
          {/* Left Endpoint List (4 Cols) */}
          <div className="lg:col-span-4 bg-slate-900 p-4 rounded-2xl border border-slate-800 space-y-3">
            <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
              REST & gRPC Endpoints
            </h2>

            {[
              { ep: 'POST /api/eval-prompt', desc: 'Evaluate Gemini prompt benchmarks', tag: 'LLMOps' },
              { ep: 'GET /api/health', desc: 'Cluster health & telemetry status', tag: 'System' },
              { ep: 'POST /api/auth/login', desc: 'Authenticate user & issue JWT Token', tag: 'Security' },
              { ep: 'GET /api/models', desc: 'Query Registered Models from catalog', tag: 'Registry' },
              { ep: 'POST /api/serving/deploy', desc: 'Deploy canary endpoint with traffic split', tag: 'Serving' },
            ].map((item) => {
              const isSelected = selectedEndpoint === item.ep;
              return (
                <div
                  key={item.ep}
                  onClick={() => {
                    setSelectedEndpoint(item.ep);
                    if (item.ep.includes('/api/health')) {
                      setRequestBody('');
                    } else if (item.ep.includes('/api/auth/login')) {
                      setRequestBody(JSON.stringify({ email: "admin@nexusml.io", password: "••••••••" }, null, 2));
                    } else {
                      setRequestBody(
                        JSON.stringify(
                          {
                            promptText: "You are an AI financial auditor.",
                            sampleInput: "Company: Acme Corp",
                          },
                          null,
                          2
                        )
                      );
                    }
                  }}
                  className={`p-3 rounded-xl border cursor-pointer transition-all space-y-1 ${
                    isSelected
                      ? 'bg-indigo-950/60 border-indigo-500/80 ring-1 ring-indigo-500/30'
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        item.ep.startsWith('POST')
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : 'bg-cyan-500/20 text-cyan-300'
                      }`}
                    >
                      {item.ep.split(' ')[0]}
                    </span>
                    <span className="text-[10px] text-slate-500">{item.tag}</span>
                  </div>
                  <div className="text-xs font-bold text-white font-mono">{item.ep.split(' ')[1]}</div>
                  <p className="text-[11px] text-slate-400 font-sans">{item.desc}</p>
                </div>
              );
            })}
          </div>

          {/* Right Interactive Tester (8 Cols) */}
          <div className="lg:col-span-8 space-y-4">
            <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                <div>
                  <span className="text-[10px] font-mono text-indigo-400 uppercase font-bold">Interactive OpenAPI Sandbox</span>
                  <h3 className="text-sm font-bold text-white font-mono">{selectedEndpoint}</h3>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={handleCopyCurl}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-sans font-bold flex items-center space-x-1.5 transition-colors"
                  >
                    {copiedCurl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedCurl ? 'Copied cURL' : 'Copy cURL'}</span>
                  </button>

                  <button
                    onClick={handleTestApi}
                    disabled={isExecutingApi}
                    className="px-4 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs font-sans flex items-center space-x-2 shadow transition-all disabled:opacity-50"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>{isExecutingApi ? 'Executing API...' : 'Execute Request'}</span>
                  </button>
                </div>
              </div>

              {/* Request Payload Editor */}
              {selectedEndpoint.startsWith('POST') && (
                <div>
                  <label className="text-[11px] font-mono text-slate-400 uppercase font-bold block mb-1">
                    Request Payload (JSON)
                  </label>
                  <textarea
                    value={requestBody}
                    onChange={(e) => setRequestBody(e.target.value)}
                    rows={5}
                    className="w-full bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-xs text-indigo-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              )}

              {/* Response Output Console */}
              <div>
                <label className="text-[11px] font-mono text-slate-400 uppercase font-bold block mb-1">
                  Response Output
                </label>
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 min-h-[160px] text-xs text-emerald-400 overflow-x-auto">
                  {responseOutput ? (
                    <pre>{responseOutput}</pre>
                  ) : (
                    <span className="text-slate-600 italic">Click "Execute Request" above to test live endpoint.</span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
