import React, { useState } from 'react';
import {
  Brain,
  Sparkles,
  GitCompare,
  Zap,
  Box,
  Layers,
  Database,
  Trophy,
  CheckCircle2,
  DollarSign,
  Calculator,
  Info,
  Clock,
  Cpu,
  HelpCircle,
} from 'lucide-react';
import {
  MlflowExperimentRun,
  DatasetItem,
  FastApiEndpointConfig,
  DockerContainerConfig,
} from '../../types/mlops';
import { TrainingWizard } from './TrainingWizard';
import { MlflowExperimentTracker } from './MlflowExperimentTracker';
import { ModelComparisonDashboard } from './ModelComparisonDashboard';
import { FastApiGeneratorView } from './FastApiGeneratorView';
import { DockerContainerView } from './DockerContainerView';

interface InstanceOption {
  id: string;
  name: string;
  gpuSpec: string;
  hourlyRate: number;
  category: 'GPU High-Perf' | 'GPU Mid-Range' | 'TPU Accelerator' | 'CPU Compute';
}

const INSTANCE_CATALOG: InstanceOption[] = [
  { id: 'p5.48xlarge', name: 'NVIDIA H100 SXM5 (8x 80GB)', gpuSpec: '8x H100 (640GB VRAM)', hourlyRate: 98.32, category: 'GPU High-Perf' },
  { id: 'p4d.24xlarge', name: 'NVIDIA A100 SXM4 (8x 40GB)', gpuSpec: '8x A100 (320GB VRAM)', hourlyRate: 32.77, category: 'GPU High-Perf' },
  { id: 'g5.12xlarge', name: 'NVIDIA A10G (4x 24GB)', gpuSpec: '4x A10G (96GB VRAM)', hourlyRate: 5.67, category: 'GPU Mid-Range' },
  { id: 'g5.2xlarge', name: 'NVIDIA A10G (1x 24GB)', gpuSpec: '1x A10G (24GB VRAM)', hourlyRate: 1.212, category: 'GPU Mid-Range' },
  { id: 'tpu-v4-8', name: 'Google TPU v4 Pod Slice', gpuSpec: '8 TPU Cores (256GB HBM)', hourlyRate: 3.22, category: 'TPU Accelerator' },
  { id: 'c6i.8xlarge', name: 'Intel Xeon 32 vCPU', gpuSpec: 'CPU Only (64GB RAM)', hourlyRate: 1.36, category: 'CPU Compute' },
];

interface TrainingHubViewProps {
  datasets: DatasetItem[];
  runs: MlflowExperimentRun[];
  fastApiConfig: FastApiEndpointConfig;
  dockerConfig: DockerContainerConfig;
  onAddRun: (newRun: MlflowExperimentRun) => void;
  onRegisterRun: (run: MlflowExperimentRun) => void;
  onOpenCopilotWithContext?: (prompt: string) => void;
  userRole: string;
}

export const TrainingHubView: React.FC<TrainingHubViewProps> = ({
  datasets,
  runs,
  fastApiConfig,
  dockerConfig,
  onAddRun,
  onRegisterRun,
  onOpenCopilotWithContext,
  userRole,
}) => {
  const [activeTab, setActiveTab] = useState<'wizard' | 'experiments' | 'comparison' | 'fastapi' | 'docker'>('wizard');

  // Compute Cost Estimator state
  const [showCostEstimator, setShowCostEstimator] = useState<boolean>(false);
  const [selectedInstanceId, setSelectedInstanceId] = useState<string>('g5.2xlarge');
  const [durationHours, setDurationHours] = useState<number>(2.5);
  const [nodeCount, setNodeCount] = useState<number>(1);
  const [isSpotInstance, setIsSpotInstance] = useState<boolean>(true);

  const selectedInstance = INSTANCE_CATALOG.find((i) => i.id === selectedInstanceId) || INSTANCE_CATALOG[3];
  const effectiveHourlyRate = isSpotInstance ? selectedInstance.hourlyRate * 0.35 : selectedInstance.hourlyRate;
  const estimatedTotalCost = effectiveHourlyRate * durationHours * nodeCount;

  const topRun = runs.reduce((best, curr) => (curr.metrics.rocAuc > best.metrics.rocAuc ? curr : best), runs[0]);

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-6 text-slate-100">
      {/* Overview Stats Bar with Cost Estimator Tooltip Launcher */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-lg">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
            Total Logged Runs
          </span>
          <div className="text-2xl font-extrabold text-white font-mono mt-1">{runs.length} Runs</div>
          <span className="text-[11px] text-indigo-400 font-medium"> Across 6 ML Frameworks</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-lg">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
            Top Champion Model
          </span>
          <div className="text-lg font-bold text-emerald-400 font-mono mt-1 truncate">
            {topRun?.runName || 'XGBoost Optuna'}
          </div>
          <span className="text-[11px] text-slate-400 font-mono">
            ROC-AUC: <span className="text-emerald-400 font-bold">{topRun ? (topRun.metrics.rocAuc * 100).toFixed(1) : '98.9'}%</span>
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-lg">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
            Hyperparameter Optimization
          </span>
          <div className="text-lg font-bold text-amber-400 mt-1 font-mono">Optuna Bayesian</div>
          <span className="text-[11px] text-slate-400"> 5-Fold Stratified CV</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-lg">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
            Inference & Packaging
          </span>
          <div className="text-lg font-bold text-indigo-400 mt-1 font-mono">FastAPI + Docker</div>
          <span className="text-[11px] text-slate-400"> CUDA 12.1 Containerized</span>
        </div>

        {/* Cost Estimation Launcher Card */}
        <div
          onClick={() => setShowCostEstimator(!showCostEstimator)}
          className="bg-slate-900 hover:bg-slate-850 border border-emerald-500/30 hover:border-emerald-500/60 transition-all rounded-xl p-4 shadow-lg cursor-pointer group relative"
          title="Click to toggle Cost Estimator Tooltip"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider block flex items-center gap-1">
              <Calculator className="w-3.5 h-3.5" /> Est. Training Run Cost
            </span>
            <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              {isSpotInstance ? 'Spot -65%' : 'On-Demand'}
            </span>
          </div>

          <div className="text-xl font-extrabold text-emerald-300 font-mono mt-1">
            ${estimatedTotalCost.toFixed(2)}
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-0.5 flex items-center justify-between">
            <span>{selectedInstance.id} ({durationHours}h)</span>
            <span className="text-emerald-400 group-hover:underline text-[10px]">Configure &rarr;</span>
          </div>
        </div>
      </div>

      {/* Cloud Compute Cost Estimation Interactive Tooltip Panel */}
      {showCostEstimator && (
        <div className="bg-slate-900 border border-emerald-500/40 p-5 rounded-2xl shadow-2xl space-y-4 animate-fadeIn">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30">
                <Calculator className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
                  Cloud Compute Cost Estimator & Rate Calculator
                </h3>
                <p className="text-xs text-slate-400">
                  Calculates estimated training run cost based on instance type, runtime duration, cluster nodes, and spot discount.
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowCostEstimator(false)}
              className="text-xs text-slate-400 hover:text-white bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-700"
            >
              Close
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
            {/* Instance Selection */}
            <div className="space-y-1.5">
              <label className="text-slate-400 font-bold block flex items-center gap-1">
                <Cpu className="w-3.5 h-3.5 text-indigo-400" /> Instance Type
              </label>
              <select
                value={selectedInstanceId}
                onChange={(e) => setSelectedInstanceId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              >
                {INSTANCE_CATALOG.map((inst) => (
                  <option key={inst.id} value={inst.id}>
                    {inst.name} (${inst.hourlyRate}/hr)
                  </option>
                ))}
              </select>
              <span className="text-[10px] text-slate-400 block">{selectedInstance.gpuSpec}</span>
            </div>

            {/* Duration Input */}
            <div className="space-y-1.5">
              <label className="text-slate-400 font-bold block flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-400" /> Duration (Hours)
              </label>
              <input
                type="number"
                step="0.5"
                min="0.1"
                max="168"
                value={durationHours}
                onChange={(e) => setDurationHours(Math.max(0.1, parseFloat(e.target.value) || 0.1))}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
              <span className="text-[10px] text-slate-400 block">{(durationHours * 60).toFixed(0)} mins total runtime</span>
            </div>

            {/* Node Count & Pricing Mode */}
            <div className="space-y-1.5">
              <label className="text-slate-400 font-bold block flex items-center gap-1">
                <Layers className="w-3.5 h-3.5 text-cyan-400" /> Cluster Nodes
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="1"
                  max="64"
                  value={nodeCount}
                  onChange={(e) => setNodeCount(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-20 bg-slate-950 border border-slate-700 rounded-lg p-2 text-white font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setIsSpotInstance(!isSpotInstance)}
                  className={`flex-1 p-2 rounded-lg border text-center text-[11px] font-bold transition-all ${
                    isSpotInstance
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-300 border-slate-700'
                  }`}
                >
                  {isSpotInstance ? 'Spot (65% Off)' : 'On-Demand'}
                </button>
              </div>
              <span className="text-[10px] text-slate-400 block">
                Rate: ${effectiveHourlyRate.toFixed(3)}/hr/node
              </span>
            </div>

            {/* Total Result Tooltip Box */}
            <div className="bg-slate-950 p-3.5 rounded-xl border border-emerald-500/30 flex flex-col justify-between">
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Formula Calculation</span>
                <p className="text-[11px] text-slate-300 mt-1">
                  ${effectiveHourlyRate.toFixed(2)} &times; {durationHours}h &times; {nodeCount} node{nodeCount > 1 ? 's' : ''}
                </p>
              </div>

              <div className="mt-2 pt-2 border-t border-slate-800 flex items-baseline justify-between">
                <span className="text-slate-400 text-xs">Estimated Total:</span>
                <span className="text-lg font-extrabold text-emerald-400 font-mono">
                  ${estimatedTotalCost.toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Sub-Navigation Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-2 shadow-lg flex flex-wrap items-center gap-2">
        {[
          { id: 'wizard', label: 'Automated Training Studio', icon: Brain },
          { id: 'experiments', label: 'MLflow Experiments', icon: Sparkles },
          { id: 'comparison', label: 'Model Comparison Dashboard', icon: GitCompare },
          { id: 'fastapi', label: 'FastAPI Service Generator', icon: Zap },
          { id: 'docker', label: 'Docker Containerization', icon: Box },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* SUB-VIEW TAB RENDER */}
      {activeTab === 'wizard' && (
        <TrainingWizard
          datasets={datasets}
          onTrainingComplete={(newRun) => {
            onAddRun(newRun);
            setActiveTab('experiments');
          }}
          userRole={userRole}
        />
      )}

      {activeTab === 'experiments' && (
        <MlflowExperimentTracker
          runs={runs}
          onRegisterRun={onRegisterRun}
          onOpenCopilotWithContext={onOpenCopilotWithContext}
          userRole={userRole}
        />
      )}

      {activeTab === 'comparison' && <ModelComparisonDashboard runs={runs} />}

      {activeTab === 'fastapi' && <FastApiGeneratorView config={fastApiConfig} />}

      {activeTab === 'docker' && <DockerContainerView config={dockerConfig} />}
    </div>
  );
};
