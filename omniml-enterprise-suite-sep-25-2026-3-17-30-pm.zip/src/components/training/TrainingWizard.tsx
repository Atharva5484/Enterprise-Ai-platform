import React, { useState, useEffect } from 'react';
import {
  Brain,
  Cpu,
  Layers,
  Sparkles,
  Play,
  CheckCircle2,
  Sliders,
  Database,
  Check,
  RefreshCw,
  Gauge,
  Code,
  Terminal,
} from 'lucide-react';
import {
  TrainingFramework,
  TuningMethod,
  CrossValidationStrategy,
  MlflowExperimentRun,
  DatasetItem,
} from '../../types/mlops';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

interface TrainingWizardProps {
  datasets: DatasetItem[];
  onTrainingComplete: (newRun: MlflowExperimentRun) => void;
  userRole: string;
}

export const TrainingWizard: React.FC<TrainingWizardProps> = ({
  datasets,
  onTrainingComplete,
  userRole,
}) => {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [selectedFramework, setSelectedFramework] = useState<TrainingFramework>('XGBoost');
  const [selectedDatasetId, setSelectedDatasetId] = useState<string>(datasets[0]?.id || 'ds-fraud-01');
  const [taskType, setTaskType] = useState<'Binary Classification' | 'Multi-class Classification' | 'Regression'>('Binary Classification');
  const [tuningMethod, setTuningMethod] = useState<TuningMethod>('Bayesian Optimization (Optuna)');
  const [cvStrategy, setCvStrategy] = useState<CrossValidationStrategy>('Stratified 5-Fold');
  const [maxTrials, setMaxTrials] = useState<number>(20);
  const [runName, setRunName] = useState<string>('xgboost_fraud_optuna_v3');
  const [useGpu, setUseGpu] = useState<boolean>(true);

  // Live simulation states
  const [isTraining, setIsTraining] = useState<boolean>(false);
  const [currentEpoch, setCurrentEpoch] = useState<number>(0);
  const [totalEpochs] = useState<number>(100);
  const [logs, setLogs] = useState<string[]>([]);
  const [lossData, setLossData] = useState<{ epoch: number; trainLoss: number; valLoss: number; score: number }[]>([]);
  const [isComplete, setIsComplete] = useState<boolean>(false);
  const [generatedRun, setGeneratedRun] = useState<MlflowExperimentRun | null>(null);

  const isViewer = userRole === 'Viewer';

  const frameworkDescriptions: Record<TrainingFramework, { name: string; desc: string; icon: string; badge: string }> = {
    'XGBoost': {
      name: 'XGBoost (eXtreme Gradient Boosting)',
      desc: 'Optimized gradient boosted decision tree library. High execution speed and top tabular performance.',
      icon: '⚡',
      badge: 'GPU Acceleration Ready',
    },
    'LightGBM': {
      name: 'LightGBM (Microsoft)',
      desc: 'Fast, distributed gradient boosting tree framework using histogram-based algorithms and leaf-wise tree growth.',
      icon: '🍃',
      badge: 'Ultra Fast Memory Efficient',
    },
    'CatBoost': {
      name: 'CatBoost (Yandex)',
      desc: 'Gradient boosting algorithm designed for categorical datasets with automatic target encoding & minimal tuning.',
      icon: '🐱',
      badge: 'Native Categorical Features',
    },
    'Scikit-Learn': {
      name: 'Scikit-Learn',
      desc: 'Versatile Python library for classic ML algorithms including Random Forests, SVMs, Ridge/Lasso, and Logistic Regressions.',
      icon: '🐍',
      badge: 'Classic ML Baseline',
    },
    'PyTorch': {
      name: 'PyTorch 2.3+ (Meta)',
      desc: 'Deep learning framework for Tabular Transformers, ResNets, and custom neural network architectures with CUDA acceleration.',
      icon: '🔥',
      badge: 'Deep Learning & Neural Nets',
    },
    'TensorFlow': {
      name: 'TensorFlow / Keras 3',
      desc: 'Google enterprise framework for deep neural networks, saved_model artifacts, and TPU/GPU distribution.',
      icon: '🟧',
      badge: 'Enterprise Neural Networks',
    },
  };

  const handleStartTraining = () => {
    setStep(4);
    setIsTraining(true);
    setIsComplete(false);
    setCurrentEpoch(0);
    setLogs([]);
    setLossData([]);

    const initialLogs = [
      `[INFO] Initializing training environment for ${selectedFramework}...`,
      `[INFO] Target Dataset: ${datasets.find((d) => d.id === selectedDatasetId)?.name || 'Default Dataset'}`,
      `[INFO] Hardware allocation: ${useGpu ? 'NVIDIA H100 GPU (16GB VRAM)' : '16 CPU Cores'}`,
      `[INFO] Tuning Method: ${tuningMethod} with ${cvStrategy}`,
      `[INFO] Cross-Validation folds initialized. Starting Optuna study...`,
    ];
    setLogs(initialLogs);

    let progress = 0;
    const interval = setInterval(() => {
      progress += 5;
      setCurrentEpoch(progress);

      const simTrainLoss = Math.max(0.02, 0.5 * Math.exp(-progress / 20) + Math.random() * 0.02);
      const simValLoss = Math.max(0.04, 0.52 * Math.exp(-progress / 22) + Math.random() * 0.03);
      const simScore = Math.min(0.995, 0.82 + (0.17 * progress) / 100);

      setLossData((prev) => [
        ...prev,
        {
          epoch: progress,
          trainLoss: Number(simTrainLoss.toFixed(4)),
          valLoss: Number(simValLoss.toFixed(4)),
          score: Number(simScore.toFixed(4)),
        },
      ]);

      if (progress % 20 === 0) {
        setLogs((prev) => [
          ...prev,
          `[Optuna Trial #${progress / 5}] Val Loss: ${simValLoss.toFixed(4)} | ROC-AUC: ${simScore.toFixed(4)} (Fold ${(progress / 20) % 5 + 1} passed)`,
        ]);
      }

      if (progress >= 100) {
        clearInterval(interval);
        setIsTraining(false);
        setIsComplete(true);

        const newRun: MlflowExperimentRun = {
          id: `run-${selectedFramework.toLowerCase().replace(/[^a-z0-9]/g, '')}-${Date.now().toString().slice(-4)}`,
          runName: runName || `${selectedFramework.toLowerCase()}_auto_trial_${Date.now().toString().slice(-4)}`,
          experimentName: 'nexus_automl_training_suite',
          framework: selectedFramework,
          datasetName: datasets.find((d) => d.id === selectedDatasetId)?.name || 'global_transaction_fraud_v2',
          datasetVersion: 'v2.0.0-clean',
          taskType,
          status: 'FINISHED',
          startedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
          durationSec: 85,
          author: 'NexusML Automated Trainer',
          modelSizeMb: Number((15 + Math.random() * 30).toFixed(1)),
          isRegistered: false,
          artifactPath: `s3://nexusml-artifacts/${runName}/model.bin`,
          params: {
            tuning_method: tuningMethod,
            cross_val: cvStrategy,
            use_gpu: useGpu,
            trials: maxTrials,
            framework: selectedFramework,
          },
          metrics: {
            accuracy: 0.985,
            f1Score: 0.944,
            rocAuc: 0.991,
            precision: 0.941,
            recall: 0.948,
            trainingLoss: 0.039,
            validationLoss: 0.048,
            inferenceLatencyMs: Number((2.5 + Math.random() * 3).toFixed(1)),
          },
          crossValScores: [0.988, 0.992, 0.989, 0.991, 0.993],
          rocPoints: [
            { fpr: 0.0, tpr: 0.0, threshold: 1.0 },
            { fpr: 0.004, tpr: 0.90, threshold: 0.85 },
            { fpr: 0.010, tpr: 0.96, threshold: 0.60 },
            { fpr: 0.021, tpr: 0.99, threshold: 0.40 },
            { fpr: 1.0, tpr: 1.0, threshold: 0.0 },
          ],
          confusionMatrix: {
            tp: 1420,
            fp: 88,
            tn: 34215,
            fn: 77,
            labels: ['Non-Fraud', 'Fraud'],
          },
          featureImportances: [
            { feature: 'txn_velocity_1h', importance: 0.35 },
            { feature: 'txn_amount_log1p', importance: 0.29 },
            { feature: 'unique_device_ip_count_7d', importance: 0.21 },
            { feature: 'user_account_age_days', importance: 0.15 },
          ],
        };

        setGeneratedRun(newRun);
        setLogs((prev) => [
          ...prev,
          `[SUCCESS] Model training successfully completed in 85s!`,
          `[ARTIFACT] Saved model binary to ${newRun.artifactPath}`,
          `[MLFLOW] Logged run to experiment 'nexus_automl_training_suite' (Run ID: ${newRun.id})`,
        ]);
        onTrainingComplete(newRun);
      }
    }, 200);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl text-slate-100">
      {/* Top Wizard Steps Bar */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-6 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-indigo-400" />
            <h2 className="text-xl font-bold text-white">Automated Model Training & Tuning Studio</h2>
          </div>
          <p className="text-sm text-slate-400 mt-1">
            Train Scikit-Learn, XGBoost, LightGBM, CatBoost, TensorFlow, or PyTorch models with Optuna hyperparameter optimization.
          </p>
        </div>

        {/* Steps Navigation Badges */}
        <div className="flex items-center gap-2">
          {[
            { num: 1, label: 'Framework' },
            { num: 2, label: 'Dataset & Task' },
            { num: 3, label: 'Hyperparameters' },
            { num: 4, label: 'Execution & Output' },
          ].map((s) => (
            <div
              key={s.num}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                step === s.num
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : step > s.num
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}
            >
              {step > s.num ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <span>{s.num}.</span>}
              <span>{s.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* STEP 1: FRAMEWORK SELECTION */}
      {step === 1 && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-slate-200 flex items-center gap-2">
              <Brain className="w-5 h-5 text-indigo-400" /> Select Machine Learning Engine Framework
            </h3>
            <span className="text-xs text-slate-400">Step 1 of 4</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {(Object.keys(frameworkDescriptions) as TrainingFramework[]).map((fw) => {
              const info = frameworkDescriptions[fw];
              const isSelected = selectedFramework === fw;
              return (
                <button
                  key={fw}
                  type="button"
                  onClick={() => setSelectedFramework(fw)}
                  className={`text-left p-5 rounded-xl border transition-all relative group ${
                    isSelected
                      ? 'bg-indigo-950/60 border-indigo-500 shadow-lg shadow-indigo-500/10 ring-1 ring-indigo-500'
                      : 'bg-slate-800/60 border-slate-700/80 hover:border-slate-600 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <span className="text-2xl">{info.icon}</span>
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        isSelected ? 'bg-indigo-600 text-white' : 'bg-slate-700 text-slate-300'
                      }`}
                    >
                      {info.badge}
                    </span>
                  </div>
                  <h4 className="text-base font-bold text-white mt-3">{info.name}</h4>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2">{info.desc}</p>
                </button>
              );
            })}
          </div>

          <div className="flex justify-end pt-4 border-t border-slate-800">
            <button
              onClick={() => setStep(2)}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg text-sm transition-colors flex items-center gap-2"
            >
              Continue to Dataset Selection →
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: DATASET & TASK CONFIGURATION */}
      {step === 2 && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-slate-200 flex items-center gap-2">
              <Database className="w-5 h-5 text-indigo-400" /> Target Dataset & Task Type Setup
            </h3>
            <span className="text-xs text-slate-400">Step 2 of 4</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Run Experiment Name
                </label>
                <input
                  type="text"
                  value={runName}
                  onChange={(e) => setRunName(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="e.g. xgboost_fraud_optuna_v3"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Select Registered Dataset
                </label>
                <select
                  value={selectedDatasetId}
                  onChange={(e) => setSelectedDatasetId(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {datasets.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name} ({d.rowCount.toLocaleString()} rows, {d.columnCount} columns)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Task Objective
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    'Binary Classification',
                    'Multi-class Classification',
                    'Regression',
                  ].map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setTaskType(t as any)}
                      className={`px-3 py-2 text-xs rounded-lg border font-medium transition-colors ${
                        taskType === t
                          ? 'bg-indigo-600 border-indigo-500 text-white'
                          : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-600'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Selected Model & Hardware Config
              </h4>
              <div className="space-y-2 text-xs text-slate-300">
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Framework Engine:</span>
                  <span className="font-semibold text-indigo-400">{selectedFramework}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Hardware Acceleration:</span>
                  <span className="font-semibold text-emerald-400 flex items-center gap-1">
                    <Cpu className="w-3.5 h-3.5" /> {useGpu ? 'NVIDIA H100 GPU (16GB)' : 'CPU Multi-threading'}
                  </span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Train/Val/Test Split:</span>
                  <span className="font-mono text-white">70% / 15% / 15%</span>
                </div>
              </div>

              <div className="pt-2">
                <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                  <input
                    type="checkbox"
                    checked={useGpu}
                    onChange={(e) => setUseGpu(e.target.checked)}
                    className="rounded border-slate-700 text-indigo-600 focus:ring-indigo-500 bg-slate-800"
                  />
                  <span>Enable GPU Hardware Acceleration (CUDA 12.1)</span>
                </label>
              </div>
            </div>
          </div>

          <div className="flex justify-between pt-4 border-t border-slate-800">
            <button
              onClick={() => setStep(1)}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-lg text-sm"
            >
              ← Back
            </button>
            <button
              onClick={() => setStep(3)}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg text-sm transition-colors"
            >
              Configure Hyperparameter Tuning →
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: HYPERPARAMETER TUNING & CV */}
      {step === 3 && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-slate-200 flex items-center gap-2">
              <Sliders className="w-5 h-5 text-indigo-400" /> Hyperparameter Optimization & Cross-Validation
            </h3>
            <span className="text-xs text-slate-400">Step 3 of 4</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Hyperparameter Optimization Strategy
                </label>
                <div className="space-y-2">
                  {[
                    'Bayesian Optimization (Optuna)',
                    'Grid Search',
                    'Random Search',
                    'None (Default Params)',
                  ].map((m) => (
                    <label
                      key={m}
                      className={`flex items-center justify-between p-3 rounded-lg border text-xs cursor-pointer transition-colors ${
                        tuningMethod === m
                          ? 'bg-indigo-950/80 border-indigo-500 text-white'
                          : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <input
                          type="radio"
                          name="tuningMethod"
                          checked={tuningMethod === m}
                          onChange={() => setTuningMethod(m as any)}
                          className="text-indigo-600 focus:ring-indigo-500 bg-slate-900 border-slate-700"
                        />
                        <span className="font-medium">{m}</span>
                      </div>
                      {m.includes('Optuna') && (
                        <span className="text-[10px] font-bold text-amber-400 bg-amber-950/60 border border-amber-800 px-2 py-0.5 rounded-full">
                          Recommended
                        </span>
                      )}
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Cross-Validation Split Strategy
                </label>
                <select
                  value={cvStrategy}
                  onChange={(e) => setCvStrategy(e.target.value as any)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="Stratified 5-Fold">Stratified 5-Fold (Recommended for Imbalance)</option>
                  <option value="Stratified 10-Fold">Stratified 10-Fold (High Precision)</option>
                  <option value="K-Fold (5)">Standard K-Fold (5 Splits)</option>
                  <option value="TimeSeriesSplit">TimeSeriesSplit (Temporal Sequential)</option>
                </select>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Max Optuna Trial Budget: <span className="text-indigo-400 font-bold">{maxTrials} Trials</span>
                </label>
                <input
                  type="range"
                  min={5}
                  max={100}
                  step={5}
                  value={maxTrials}
                  onChange={(e) => setMaxTrials(Number(e.target.value))}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
              </div>

              <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Search Space Auto-Injected
                </h4>
                <div className="font-mono text-[11px] text-slate-400 bg-slate-900 p-2.5 rounded border border-slate-800 space-y-1">
                  {selectedFramework === 'XGBoost' && (
                    <>
                      <div>n_estimators: trial.suggest_int('n_estimators', 100, 1000)</div>
                      <div>max_depth: trial.suggest_int('max_depth', 3, 12)</div>
                      <div>learning_rate: trial.suggest_float('learning_rate', 1e-3, 0.2, log=True)</div>
                      <div>subsample: trial.suggest_float('subsample', 0.5, 1.0)</div>
                    </>
                  )}
                  {selectedFramework === 'PyTorch' && (
                    <>
                      <div>lr: trial.suggest_float('lr', 1e-5, 1e-2, log=True)</div>
                      <div>optimizer: trial.suggest_categorical('opt', ['AdamW', 'SGD'])</div>
                      <div>batch_size: trial.suggest_categorical('batch_size', [128, 256, 512])</div>
                    </>
                  )}
                  {selectedFramework !== 'XGBoost' && selectedFramework !== 'PyTorch' && (
                    <>
                      <div>learning_rate: trial.suggest_float('learning_rate', 0.01, 0.3)</div>
                      <div>n_estimators: trial.suggest_int('n_estimators', 50, 500)</div>
                      <div>regularization: trial.suggest_float('reg_alpha', 1e-8, 10.0, log=True)</div>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-between pt-4 border-t border-slate-800">
            <button
              onClick={() => setStep(2)}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-lg text-sm"
            >
              ← Back
            </button>
            <button
              onClick={handleStartTraining}
              disabled={isViewer}
              className={`px-6 py-2.5 font-medium rounded-lg text-sm transition-all flex items-center gap-2 shadow-lg ${
                isViewer
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30'
              }`}
            >
              <Play className="w-4 h-4 fill-current" /> Execute Automated Model Training
            </button>
          </div>
        </div>
      )}

      {/* STEP 4: EXECUTION & PROGRESS MONITOR */}
      {step === 4 && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-slate-200 flex items-center gap-2">
                {isTraining ? (
                  <RefreshCw className="w-5 h-5 text-indigo-400 animate-spin" />
                ) : (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                )}
                {isTraining ? 'Training in Progress...' : 'Training Run Completed Successfully'}
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Framework: <span className="font-semibold text-indigo-400">{selectedFramework}</span> | Experiment: <span className="font-mono text-white">{runName}</span>
              </p>
            </div>

            {isComplete && generatedRun && (
              <span className="text-xs font-bold text-emerald-400 bg-emerald-950 border border-emerald-800 px-3 py-1 rounded-full flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5" /> Logged to MLflow (ROC-AUC: {generatedRun.metrics.rocAuc})
              </span>
            )}
          </div>

          {/* Progress Bar */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
            <div className="flex justify-between text-xs text-slate-300 font-mono">
              <span>Trial Progress: {currentEpoch}%</span>
              <span>{isTraining ? 'Optuna Sampling Folds...' : 'Finished (85s)'}</span>
            </div>
            <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 transition-all duration-300"
                style={{ width: `${currentEpoch}%` }}
              />
            </div>
          </div>

          {/* Loss & Score Curves Chart */}
          {lossData.length > 0 && (
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <Gauge className="w-3.5 h-3.5 text-indigo-400" /> Real-time Loss & Evaluation Score Trajectory
              </h4>
              <div className="h-48 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={lossData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="epoch" stroke="#64748b" tick={{ fontSize: 10 }} />
                    <YAxis stroke="#64748b" tick={{ fontSize: 10 }} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '11px' }}
                    />
                    <Line type="monotone" dataKey="trainLoss" stroke="#6366f1" strokeWidth={2} name="Training Loss" dot={false} />
                    <Line type="monotone" dataKey="valLoss" stroke="#f43f5e" strokeWidth={2} name="Validation Loss" dot={false} />
                    <Line type="monotone" dataKey="score" stroke="#10b981" strokeWidth={2} name="ROC-AUC Score" dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Console Output Log */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs text-slate-300 max-h-40 overflow-y-auto space-y-1">
            <div className="text-slate-500 font-bold mb-1 flex items-center gap-1">
              <Terminal className="w-3.5 h-3.5" /> Execution Console Logs:
            </div>
            {logs.map((log, idx) => (
              <div key={idx} className="text-emerald-400/90">{log}</div>
            ))}
          </div>

          {/* Completion Actions */}
          {isComplete && (
            <div className="flex justify-between items-center pt-4 border-t border-slate-800">
              <button
                onClick={() => setStep(1)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-lg"
              >
                Start Another Experiment Run
              </button>
              <div className="flex items-center gap-3">
                <span className="text-xs text-slate-400">
                  Model logged to MLflow Experiment Hub!
                </span>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
