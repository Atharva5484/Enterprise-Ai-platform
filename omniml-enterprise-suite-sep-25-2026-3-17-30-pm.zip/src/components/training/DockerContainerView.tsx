import React, { useState } from 'react';
import {
  Box,
  Layers,
  Code,
  CheckCircle2,
  Play,
  Terminal,
  ShieldCheck,
  HardDrive,
  Copy,
  Check,
  Cpu,
  RefreshCw,
} from 'lucide-react';
import { DockerContainerConfig } from '../../types/mlops';

interface DockerContainerViewProps {
  config: DockerContainerConfig;
}

export const DockerContainerView: React.FC<DockerContainerViewProps> = ({ config }) => {
  const [activeTab, setActiveTab] = useState<'dockerfile' | 'compose' | 'nginx'>('dockerfile');
  const [isBuilding, setIsBuilding] = useState<boolean>(false);
  const [buildLogs, setBuildLogs] = useState<string[]>(config.buildLogs);
  const [copied, setCopied] = useState<boolean>(false);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRunDockerBuild = () => {
    setIsBuilding(true);
    setBuildLogs(['[INFO] Starting Docker image build process...']);

    const steps = [
      '[1/6] STEP 1/6: FROM nvidia/cuda:12.1.0-runtime-ubuntu22.04 as base',
      '[2/6] STEP 2/6: RUN apt-get update && apt-get install -y python3.11 python3-pip',
      '[3/6] STEP 3/6: COPY requirements.txt . && pip install -r requirements.txt (Cached)',
      '[4/6] STEP 4/6: COPY ./artifacts /app/artifacts (XGBoost model binary)',
      '[5/6] STEP 5/6: COPY ./server /app/server (FastAPI app entrypoint)',
      '[6/6] STEP 6/6: EXPOSE 8000',
      '[TRIVY] Scanning container filesystem image layers for CVEs...',
      '[TRIVY] Vulnerability Scan Passed! (0 Critical, 0 High vulnerabilities found)',
      `[SUCCESS] Image tagged as ${config.imageName}:${config.tag} (${config.imageSizeMb} MB)`,
    ];

    let index = 0;
    const interval = setInterval(() => {
      if (index < steps.length) {
        setBuildLogs((prev) => [...prev, steps[index]]);
        index++;
      } else {
        clearInterval(interval);
        setIsBuilding(false);
      }
    }, 400);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Box className="w-5 h-5 text-indigo-400" />
            <h3 className="text-lg font-bold text-white">Docker Containerization & Kubernetes Packaging</h3>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Production multi-stage OCI container image with GPU support, trivy vulnerability scanning, and docker-compose orchestration.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleRunDockerBuild}
            disabled={isBuilding}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs rounded-lg transition-colors flex items-center gap-1.5 shadow"
          >
            {isBuilding ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-white" />
            ) : (
              <Play className="w-3.5 h-3.5 fill-current" />
            )}
            {isBuilding ? 'Building Docker Image...' : 'Build Docker Image'}
          </button>
        </div>
      </div>

      {/* Container Spec Badges */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-900 border border-slate-800 p-3 rounded-xl">
          <span className="text-[10px] uppercase tracking-wider text-slate-500 font-bold block">
            Container Image Name
          </span>
          <span className="text-xs font-mono font-bold text-white truncate block mt-0.5">
            {config.imageName}:{config.tag}
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded-xl">
          <span className="text-[10px] uppercase tracking-wider text-slate-500 font-bold block">
            Image Size
          </span>
          <span className="text-xs font-mono font-bold text-indigo-400 block mt-0.5">
            {config.imageSizeMb} MB
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded-xl">
          <span className="text-[10px] uppercase tracking-wider text-slate-500 font-bold block">
            CUDA GPU Driver
          </span>
          <span className="text-xs font-mono font-bold text-emerald-400 flex items-center gap-1 mt-0.5">
            <Cpu className="w-3.5 h-3.5" /> CUDA 12.1
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded-xl">
          <span className="text-[10px] uppercase tracking-wider text-slate-500 font-bold block">
            Trivy CVE Scan
          </span>
          <span className="text-xs font-mono font-bold text-emerald-300 flex items-center gap-1 mt-0.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Passed (0 High)
          </span>
        </div>
      </div>

      {/* Code Tabs */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div className="border-b border-slate-800 bg-slate-950 px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('dockerfile')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                activeTab === 'dockerfile' ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400'
              }`}
            >
              Dockerfile
            </button>
            <button
              onClick={() => setActiveTab('compose')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                activeTab === 'compose' ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400'
              }`}
            >
              docker-compose.yml
            </button>
            <button
              onClick={() => setActiveTab('nginx')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                activeTab === 'nginx' ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400'
              }`}
            >
              nginx.conf
            </button>
          </div>

          <button
            onClick={() =>
              handleCopy(
                activeTab === 'dockerfile'
                  ? config.dockerfileContent
                  : activeTab === 'compose'
                  ? config.dockerComposeContent
                  : config.nginxConfContent
              )
            }
            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-lg transition-colors flex items-center gap-1"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'Copied!' : 'Copy File'}
          </button>
        </div>

        <div className="p-4 bg-slate-950 font-mono text-xs text-slate-300 overflow-x-auto max-h-[400px]">
          <pre className="text-indigo-300/90 whitespace-pre-wrap">
            {activeTab === 'dockerfile' && config.dockerfileContent}
            {activeTab === 'compose' && config.dockerComposeContent}
            {activeTab === 'nginx' && config.nginxConfContent}
          </pre>
        </div>
      </div>

      {/* Build Logs Terminal */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
          <Terminal className="w-3.5 h-3.5 text-indigo-400" /> Docker Image Build Console Logs
        </span>
        <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 font-mono text-xs text-emerald-400 space-y-1 max-h-48 overflow-y-auto">
          {buildLogs.map((log, idx) => (
            <div key={idx}>{log}</div>
          ))}
        </div>
      </div>
    </div>
  );
};
