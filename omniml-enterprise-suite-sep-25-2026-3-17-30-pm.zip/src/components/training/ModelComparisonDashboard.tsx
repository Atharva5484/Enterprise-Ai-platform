import React, { useState } from 'react';
import {
  GitCompare,
  Trophy,
  BarChart2,
  Sliders,
  CheckCircle2,
  Clock,
  HardDrive,
  Zap,
  TrendingUp,
  Award,
} from 'lucide-react';
import { MlflowExperimentRun } from '../../types/mlops';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  BarChart,
  Bar,
  Legend,
} from 'recharts';

interface ModelComparisonDashboardProps {
  runs: MlflowExperimentRun[];
}

export const ModelComparisonDashboard: React.FC<ModelComparisonDashboardProps> = ({ runs }) => {
  const [selectedRunIds, setSelectedRunIds] = useState<string[]>([
    runs[0]?.id || 'run-xgb-optuna-01',
    runs[1]?.id || 'run-lgb-fast-02',
    runs[2]?.id || 'run-catboost-03',
  ]);

  const toggleRunSelection = (id: string) => {
    if (selectedRunIds.includes(id)) {
      if (selectedRunIds.length <= 2) return; // keep at least 2 for comparison
      setSelectedRunIds(selectedRunIds.filter((r) => r !== id));
    } else {
      if (selectedRunIds.length >= 5) return; // max 5
      setSelectedRunIds([...selectedRunIds, id]);
    }
  };

  const selectedRuns = runs.filter((r) => selectedRunIds.includes(r.id));

  // Determine Winner Run based on ROC-AUC
  const winnerRun = selectedRuns.reduce((best, curr) => {
    return curr.metrics.rocAuc > best.metrics.rocAuc ? curr : best;
  }, selectedRuns[0] || runs[0]);

  // Chart data for metric comparison
  const metricComparisonData = [
    {
      metric: 'ROC-AUC (%)',
      ...selectedRuns.reduce((acc, r) => ({ ...acc, [r.runName]: Number((r.metrics.rocAuc * 100).toFixed(1)) }), {}),
    },
    {
      metric: 'F1 Score (%)',
      ...selectedRuns.reduce((acc, r) => ({ ...acc, [r.runName]: Number((r.metrics.f1Score * 100).toFixed(1)) }), {}),
    },
    {
      metric: 'Accuracy (%)',
      ...selectedRuns.reduce((acc, r) => ({ ...acc, [r.runName]: Number((r.metrics.accuracy * 100).toFixed(1)) }), {}),
    },
    {
      metric: 'Precision (%)',
      ...selectedRuns.reduce((acc, r) => ({ ...acc, [r.runName]: Number((r.metrics.precision * 100).toFixed(1)) }), {}),
    },
    {
      metric: 'Recall (%)',
      ...selectedRuns.reduce((acc, r) => ({ ...acc, [r.runName]: Number((r.metrics.recall * 100).toFixed(1)) }), {}),
    },
  ];

  // Colors for lines / bars
  const colors = ['#6366f1', '#10b981', '#f59e0b', '#ec4899', '#3b82f6'];

  return (
    <div className="space-y-6">
      {/* Header & Run Selector Badges */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="flex items-center gap-2">
              <GitCompare className="w-5 h-5 text-indigo-400" />
              <h3 className="text-lg font-bold text-white">Multi-Model Comparative Benchmarking Dashboard</h3>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Compare Scikit-Learn, XGBoost, LightGBM, CatBoost, TensorFlow & PyTorch experiment runs on ROC curves, confusion matrices, and latency.
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Comparing <span className="text-indigo-400 font-bold">{selectedRuns.length}</span> models
          </span>
        </div>

        {/* Model Chips Selector */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-800">
          <span className="text-xs font-semibold text-slate-400 mr-2">Select Models to Benchmark:</span>
          {runs.map((r) => {
            const isSelected = selectedRunIds.includes(r.id);
            return (
              <button
                key={r.id}
                type="button"
                onClick={() => toggleRunSelection(r.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 border ${
                  isSelected
                    ? 'bg-indigo-950 border-indigo-500 text-white shadow-md'
                    : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:bg-slate-800'
                }`}
              >
                <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-indigo-400' : 'bg-slate-600'}`} />
                <span>{r.runName}</span>
                <span className="text-[10px] text-slate-400 font-mono">({r.framework})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Recommended Winner Banner */}
      {winnerRun && (
        <div className="bg-gradient-to-r from-emerald-950/80 via-slate-900 to-indigo-950/80 border border-emerald-800/80 rounded-xl p-5 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-emerald-600/20 rounded-xl border border-emerald-500/30 text-emerald-400">
              <Award className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider bg-emerald-950 border border-emerald-800 px-2 py-0.5 rounded-full">
                  Recommended Model Winner
                </span>
                <span className="text-xs text-slate-400">Highest ROC-AUC Score</span>
              </div>
              <h4 className="text-lg font-bold text-white mt-1">
                {winnerRun.runName} <span className="text-sm font-normal text-slate-400">({winnerRun.framework})</span>
              </h4>
              <p className="text-xs text-slate-300 mt-0.5">
                Outperformed benchmark candidates with <span className="font-bold text-emerald-400">{(winnerRun.metrics.rocAuc * 100).toFixed(1)}% ROC-AUC</span>, {winnerRun.metrics.inferenceLatencyMs}ms latency, and F1-score of {winnerRun.metrics.f1Score}.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right font-mono text-xs text-slate-300 bg-slate-950/80 p-3 rounded-lg border border-slate-800">
              <div>ROC-AUC: <span className="text-emerald-400 font-bold">{(winnerRun.metrics.rocAuc * 100).toFixed(1)}%</span></div>
              <div>F1 Score: <span className="text-indigo-400 font-bold">{winnerRun.metrics.f1Score}</span></div>
            </div>
          </div>
        </div>
      )}

      {/* Side-by-Side Metrics Comparison Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-indigo-400" /> Side-by-Side Quantitative Matrix
          </h4>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase font-mono text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Evaluation Metric</th>
                {selectedRuns.map((r, i) => (
                  <th key={r.id} className="py-3 px-4 text-center font-bold">
                    <div style={{ color: colors[i % colors.length] }}>{r.runName}</div>
                    <div className="text-[10px] text-slate-500 font-normal">{r.framework}</div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 font-mono">
              <tr>
                <td className="py-3 px-4 font-sans font-semibold text-white">ROC-AUC Score</td>
                {selectedRuns.map((r) => (
                  <td key={r.id} className="py-3 px-4 text-center font-bold text-emerald-400">
                    {(r.metrics.rocAuc * 100).toFixed(2)}%
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-3 px-4 font-sans font-semibold text-white">F1 Score</td>
                {selectedRuns.map((r) => (
                  <td key={r.id} className="py-3 px-4 text-center text-indigo-300">
                    {r.metrics.f1Score.toFixed(3)}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-3 px-4 font-sans font-semibold text-white">Accuracy</td>
                {selectedRuns.map((r) => (
                  <td key={r.id} className="py-3 px-4 text-center text-slate-200">
                    {(r.metrics.accuracy * 100).toFixed(1)}%
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-3 px-4 font-sans font-semibold text-white">Inference Latency (P95)</td>
                {selectedRuns.map((r) => (
                  <td key={r.id} className="py-3 px-4 text-center text-amber-400">
                    {r.metrics.inferenceLatencyMs} ms
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-3 px-4 font-sans font-semibold text-white">Model Size</td>
                {selectedRuns.map((r) => (
                  <td key={r.id} className="py-3 px-4 text-center text-slate-400">
                    {r.modelSizeMb} MB
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Recharts Bar Comparison Chart */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
        <h4 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-indigo-400" /> Comparative Metrics Visualizer
        </h4>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={metricComparisonData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="metric" stroke="#64748b" tick={{ fontSize: 11 }} />
              <YAxis stroke="#64748b" tick={{ fontSize: 11 }} domain={[80, 100]} />
              <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155' }} />
              <Legend />
              {selectedRuns.map((r, i) => (
                <Bar key={r.id} dataKey={r.runName} fill={colors[i % colors.length]} radius={[4, 4, 0, 0]} />
              ))}
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Side-by-Side Confusion Matrices */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {selectedRuns.map((r, i) => (
          <div key={r.id} className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-lg">
            <div className="flex items-center justify-between mb-3">
              <h5 className="text-xs font-bold text-white truncate" style={{ color: colors[i % colors.length] }}>
                {r.runName}
              </h5>
              <span className="text-[10px] font-mono text-slate-400">{r.framework}</span>
            </div>

            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2">
              <span className="text-[10px] uppercase tracking-wider text-slate-500 font-bold block text-center">
                Confusion Matrix
              </span>
              <div className="grid grid-cols-2 gap-2 text-center text-xs font-mono">
                <div className="bg-emerald-950/60 border border-emerald-800 p-2 rounded">
                  <span className="text-[10px] text-slate-400 block">TP (Fraud)</span>
                  <span className="font-bold text-emerald-400">{r.confusionMatrix.tp}</span>
                </div>
                <div className="bg-rose-950/60 border border-rose-800 p-2 rounded">
                  <span className="text-[10px] text-slate-400 block">FP (False Alarm)</span>
                  <span className="font-bold text-rose-400">{r.confusionMatrix.fp}</span>
                </div>
                <div className="bg-rose-950/60 border border-rose-800 p-2 rounded">
                  <span className="text-[10px] text-slate-400 block">FN (Missed)</span>
                  <span className="font-bold text-rose-400">{r.confusionMatrix.fn}</span>
                </div>
                <div className="bg-emerald-950/60 border border-emerald-800 p-2 rounded">
                  <span className="text-[10px] text-slate-400 block">TN (Legit)</span>
                  <span className="font-bold text-emerald-400">{r.confusionMatrix.tn}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
