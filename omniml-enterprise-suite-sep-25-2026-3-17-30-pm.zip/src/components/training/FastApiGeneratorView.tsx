import React, { useState } from 'react';
import {
  Zap,
  Code,
  Play,
  Copy,
  Check,
  Server,
  Globe,
  Terminal,
  Activity,
  Layers,
  Sparkles,
} from 'lucide-react';
import { FastApiEndpointConfig } from '../../types/mlops';

interface FastApiGeneratorViewProps {
  config: FastApiEndpointConfig;
  onUpdateConfig?: (newConfig: FastApiEndpointConfig) => void;
}

export const FastApiGeneratorView: React.FC<FastApiGeneratorViewProps> = ({ config }) => {
  const [activeTab, setActiveTab] = useState<'code' | 'swagger' | 'pydantic'>('code');
  const [payloadJson, setPayloadJson] = useState<string>(
    JSON.stringify(config.samplePayload, null, 2)
  );
  const [copied, setCopied] = useState<boolean>(false);
  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const [responseOutput, setResponseOutput] = useState<any>(null);
  const [responseTimeMs, setResponseTimeMs] = useState<number>(0);

  const handleCopyCode = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExecutePredict = () => {
    setIsExecuting(true);
    setResponseOutput(null);

    const start = performance.now();
    setTimeout(() => {
      try {
        const parsed = JSON.parse(payloadJson);
        const amount = parsed.txn_amount || 100;
        const velocity = parsed.txn_velocity_1h || 1;
        const calcProb = Math.min(0.99, Math.max(0.01, 0.1 * velocity + (amount > 1000 ? 0.6 : 0.05)));
        const elapsed = (performance.now() - start).toFixed(2);

        setResponseTimeMs(Number(elapsed));
        setResponseOutput({
          transaction_id: `TXN-${Date.now().toString().slice(-6)}`,
          fraud_probability: Number(calcProb.toFixed(4)),
          is_fraud_flag: calcProb > 0.5,
          risk_level: calcProb > 0.8 ? 'CRITICAL' : calcProb > 0.5 ? 'HIGH' : 'LOW',
          inference_latency_ms: Number(elapsed) + 2.1,
          status: 'SUCCESS_200_OK',
        });
      } catch (err) {
        setResponseOutput({ error: 'Invalid JSON payload input format' });
      } finally {
        setIsExecuting(false);
      }
    }, 300);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-400" />
            <h3 className="text-lg font-bold text-white">FastAPI Production Inference Microservice</h3>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Auto-generated asynchronous Python FastAPI service with Pydantic typing, Gunicorn/Uvicorn workers, and Prometheus metrics.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-800 flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-emerald-400" /> OpenAPI 3.0 / Swagger Ready
          </span>
        </div>
      </div>

      {/* Code vs Swagger Tabs */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div className="border-b border-slate-800 bg-slate-950 px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('code')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                activeTab === 'code'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <Code className="w-3.5 h-3.5" /> main.py (FastAPI Code)
            </button>
            <button
              onClick={() => setActiveTab('swagger')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                activeTab === 'swagger'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <Globe className="w-3.5 h-3.5" /> Swagger / Interactive UI Tester
            </button>
            <button
              onClick={() => setActiveTab('pydantic')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                activeTab === 'pydantic'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" /> Pydantic Schemas
            </button>
          </div>

          <button
            onClick={() => handleCopyCode(activeTab === 'code' ? config.pythonCode : config.pydanticSchemaCode)}
            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-lg transition-colors flex items-center gap-1"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'Copied!' : 'Copy Code'}
          </button>
        </div>

        {/* TAB CONTENT 1: CODE */}
        {activeTab === 'code' && (
          <div className="p-4 bg-slate-950 font-mono text-xs text-slate-300 overflow-x-auto max-h-[500px]">
            <pre className="text-emerald-400/90 whitespace-pre-wrap">{config.pythonCode}</pre>
          </div>
        )}

        {/* TAB CONTENT 2: INTERACTIVE SWAGGER TESTER */}
        {activeTab === 'swagger' && (
          <div className="p-6 bg-slate-950 space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold font-mono text-emerald-400 bg-emerald-950 px-2.5 py-1 rounded border border-emerald-800">
                  POST /predict
                </span>
                <span className="text-xs text-slate-400">Content-Type: application/json</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  JSON Request Payload Body:
                </label>
                <textarea
                  rows={6}
                  value={payloadJson}
                  onChange={(e) => setPayloadJson(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 font-mono text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex justify-end">
                <button
                  onClick={handleExecutePredict}
                  disabled={isExecuting}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs rounded-lg transition-colors flex items-center gap-2 shadow-lg shadow-emerald-600/20"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  {isExecuting ? 'Executing Inference...' : 'Execute FastAPI Inference Test'}
                </button>
              </div>
            </div>

            {/* Response Output Box */}
            {responseOutput && (
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Terminal className="w-3.5 h-3.5 text-indigo-400" /> Response Output (HTTP 200 OK)
                  </span>
                  <span className="font-mono text-emerald-400 font-bold">
                    Latency: {responseTimeMs} ms
                  </span>
                </div>
                <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 font-mono text-xs text-slate-200 overflow-x-auto">
                  <pre>{JSON.stringify(responseOutput, null, 2)}</pre>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB CONTENT 3: PYDANTIC SCHEMAS */}
        {activeTab === 'pydantic' && (
          <div className="p-4 bg-slate-950 font-mono text-xs text-indigo-300 overflow-x-auto max-h-[500px]">
            <pre className="whitespace-pre-wrap">{config.pydanticSchemaCode}</pre>
          </div>
        )}
      </div>
    </div>
  );
};
