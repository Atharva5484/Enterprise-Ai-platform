import React, { useState } from 'react';
import {
  Sparkles,
  Layers,
  Search,
  Filter,
  CheckCircle2,
  ExternalLink,
  ChevronRight,
  Database,
  BarChart3,
  Clock,
  HardDrive,
  Cpu,
  BookmarkPlus,
  X,
  DollarSign,
  Calculator,
} from 'lucide-react';
import { MlflowExperimentRun, TrainingFramework } from '../../types/mlops';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

interface MlflowExperimentTrackerProps {
  runs: MlflowExperimentRun[];
  onRegisterRun: (run: MlflowExperimentRun) => void;
  onOpenCopilotWithContext?: (prompt: string) => void;
  userRole: string;
}

export const MlflowExperimentTracker: React.FC<MlflowExperimentTrackerProps> = ({
  runs,
  onRegisterRun,
  onOpenCopilotWithContext,
  userRole,
}) => {
  const [selectedFramework, setSelectedFramework] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeRunDetail, setActiveRunDetail] = useState<MlflowExperimentRun | null>(null);

  const frameworksList: string[] = ['ALL', 'Scikit-Learn', 'XGBoost', 'LightGBM', 'CatBoost', 'TensorFlow', 'PyTorch'];

  const filteredRuns = runs.filter((r) => {
    const matchesFw = selectedFramework === 'ALL' || r.framework === selectedFramework;
    const matchesSearch =
      r.runName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.experimentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.author.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFw && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Header & Filter Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-400" />
              <h3 className="text-lg font-bold text-white">MLflow Experiment Tracking & Runs Registry</h3>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Central tracking server logging parameters, cross-validation metrics, artifacts, and execution lineage.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search runs, authors..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* Framework Filter Buttons */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <span className="text-xs font-semibold text-slate-400 flex items-center gap-1 mr-1">
            <Filter className="w-3.5 h-3.5" /> Filter Framework:
          </span>
          {frameworksList.map((fw) => (
            <button
              key={fw}
              type="button"
              onClick={() => setSelectedFramework(fw)}
              className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
                selectedFramework === fw
                  ? 'bg-indigo-600 text-white font-semibold'
                  : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-slate-200'
              }`}
            >
              {fw}
            </button>
          ))}
        </div>
      </div>

      {/* Runs Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase font-mono text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Run Name & ID</th>
                <th className="py-3 px-4">Framework</th>
                <th className="py-3 px-4">Dataset</th>
                <th className="py-3 px-4 text-right">ROC-AUC</th>
                <th className="py-3 px-4 text-right">F1-Score</th>
                <th className="py-3 px-4 text-right">Accuracy</th>
                <th className="py-3 px-4 text-right">Est. Compute Cost</th>
                <th className="py-3 px-4">Registry Status</th>
                <th className="py-3 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredRuns.map((r) => {
                const isGpu = r.params.use_gpu ?? true;
                const rate = isGpu ? 1.212 : 0.68;
                const hours = (r.durationSec || 85) / 3600;
                const estCost = hours * rate;

                return (
                <tr key={r.id} className="hover:bg-slate-800/50 transition-colors group">
                  <td className="py-3 px-4 font-medium text-white">
                    <button
                      type="button"
                      onClick={() => setActiveRunDetail(r)}
                      className="text-left hover:text-indigo-400 font-semibold flex items-center gap-1.5"
                    >
                      <span className="w-2 h-2 rounded-full bg-emerald-400" />
                      {r.runName}
                    </button>
                    <div className="text-[10px] font-mono text-slate-500 mt-0.5">{r.id} • {r.startedAt}</div>
                  </td>

                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-indigo-300 font-medium">
                      {r.framework}
                    </span>
                  </td>

                  <td className="py-3 px-4">
                    <div className="text-slate-300 font-mono text-[11px]">{r.datasetName}</div>
                    <div className="text-[10px] text-slate-500">{r.datasetVersion}</div>
                  </td>

                  <td className="py-3 px-4 text-right font-mono font-bold text-emerald-400">
                    {(r.metrics.rocAuc * 100).toFixed(1)}%
                  </td>

                  <td className="py-3 px-4 text-right font-mono text-slate-200">
                    {r.metrics.f1Score.toFixed(3)}
                  </td>

                  <td className="py-3 px-4 text-right font-mono text-slate-300">
                    {(r.metrics.accuracy * 100).toFixed(1)}%
                  </td>

                  {/* Cost Estimation Tooltip Column */}
                  <td className="py-3 px-4 text-right font-mono">
                    <div className="relative group/cost inline-block">
                      <span className="text-emerald-300 font-bold hover:underline cursor-help flex items-center justify-end gap-1">
                        <DollarSign className="w-3 h-3 text-emerald-400" />
                        {estCost < 0.01 ? '<$0.01' : `$${estCost.toFixed(2)}`}
                      </span>
                      {/* Tooltip Hover Overlay */}
                      <div className="absolute right-0 bottom-full mb-2 hidden group-hover/cost:block w-56 p-2.5 bg-slate-950 border border-emerald-500/40 rounded-xl shadow-xl z-30 text-left text-[10px] font-mono text-slate-200 pointer-events-none">
                        <div className="font-bold text-emerald-400 border-b border-slate-800 pb-1 mb-1.5 flex items-center justify-between">
                          <span>Compute Cost Breakdown</span>
                          <span>{r.durationSec}s</span>
                        </div>
                        <div className="space-y-0.5 text-slate-300">
                          <div>Instance: <strong className="text-white">{isGpu ? 'NVIDIA A10G GPU' : 'CPU Xeon'}</strong></div>
                          <div>Hourly Rate: <strong className="text-white">${rate.toFixed(3)}/hr</strong></div>
                          <div>Duration: <strong className="text-white">{(hours * 60).toFixed(1)} mins</strong></div>
                          <div className="text-emerald-300 font-bold pt-1 border-t border-slate-800 mt-1">
                            Est. Run Cost: ${estCost < 0.01 ? '<$0.01' : `$${estCost.toFixed(4)}`}
                          </div>
                        </div>
                      </div>
                    </div>
                  </td>

                  <td className="py-3 px-4">
                    {r.isRegistered ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800 flex items-center gap-1 w-fit">
                        <CheckCircle2 className="w-3 h-3" /> {r.registeredModelVersion}
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-800 text-slate-400 border border-slate-700">
                        Unregistered
                      </span>
                    )}
                  </td>

                  <td className="py-3 px-4 text-center">
                    <div className="flex items-center justify-center gap-2">
                      <button
                        onClick={() => setActiveRunDetail(r)}
                        className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                        title="View Full Metrics & Artifacts"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>

                      {!r.isRegistered && userRole !== 'Viewer' && (
                        <button
                          onClick={() => onRegisterRun(r)}
                          className="px-2.5 py-1 rounded bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-[11px] transition-colors flex items-center gap-1 shadow"
                        >
                          <BookmarkPlus className="w-3 h-3" /> Register
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* RUN DETAIL MODAL */}
      {activeRunDetail && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-3xl p-6 shadow-2xl text-slate-100 max-h-[90vh] overflow-y-auto space-y-6">
            <div className="flex items-start justify-between border-b border-slate-800 pb-4">
              <div>
                <span className="text-xs font-mono text-indigo-400 font-bold uppercase">{activeRunDetail.framework} Run</span>
                <h3 className="text-xl font-bold text-white mt-0.5">{activeRunDetail.runName}</h3>
                <p className="text-xs text-slate-400 mt-1 font-mono">
                  ID: {activeRunDetail.id} • Author: {activeRunDetail.author} • Duration: {activeRunDetail.durationSec}s
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveRunDetail(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Metrics Overview Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">ROC-AUC Score</span>
                <div className="text-lg font-bold font-mono text-emerald-400">
                  {(activeRunDetail.metrics.rocAuc * 100).toFixed(2)}%
                </div>
              </div>

              <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">F1 Score</span>
                <div className="text-lg font-bold font-mono text-indigo-400">
                  {activeRunDetail.metrics.f1Score.toFixed(3)}
                </div>
              </div>

              <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Inference Latency</span>
                <div className="text-lg font-bold font-mono text-amber-400">
                  {activeRunDetail.metrics.inferenceLatencyMs} ms
                </div>
              </div>

              <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Model Artifact Size</span>
                <div className="text-lg font-bold font-mono text-slate-200">
                  {activeRunDetail.modelSizeMb} MB
                </div>
              </div>
            </div>

            {/* Hyperparameters Table */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Logged Hyperparameters
              </h4>
              <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 grid grid-cols-2 sm:grid-cols-3 gap-2 font-mono text-xs">
                {Object.entries(activeRunDetail.params).map(([k, v]) => (
                  <div key={k} className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-slate-500 text-[10px] block">{k}</span>
                    <span className="text-indigo-300 font-semibold">{String(v)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Feature Importances Chart */}
            {activeRunDetail.featureImportances && (
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Top Feature Importance Weights
                </h4>
                <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 h-44">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={activeRunDetail.featureImportances} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                      <XAxis type="number" stroke="#64748b" tick={{ fontSize: 10 }} />
                      <YAxis dataKey="feature" type="category" stroke="#94a3b8" tick={{ fontSize: 10 }} width={140} />
                      <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155' }} />
                      <Bar dataKey="importance" fill="#6366f1" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}

            {/* Artifact URI */}
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 flex items-center justify-between">
              <div className="truncate">
                <span className="text-[10px] text-slate-500 uppercase font-bold block">S3 Artifact Path</span>
                <span className="text-xs font-mono text-slate-300 truncate block">{activeRunDetail.artifactPath}</span>
              </div>
              <button
                onClick={() => navigator.clipboard.writeText(activeRunDetail.artifactPath)}
                className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-xs font-medium rounded text-slate-300 transition-colors"
              >
                Copy Path
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
