import React, { useState } from 'react';
import {
  Cpu,
  Server,
  Box,
  Layers,
  HardDrive,
  Activity,
  AlertTriangle,
  Gauge,
  CheckCircle2,
  ShieldAlert,
  Zap,
  TrendingUp,
} from 'lucide-react';
import { GpuClusterNode, K8sHpaConfig, HelmReleaseInfo } from '../../types/mlops';
import { K8sDeploymentStudio } from './K8sDeploymentStudio';
import { INITIAL_K8S_HPA_CONFIGS, INITIAL_HELM_RELEASE } from '../../data/mockOpsData';

interface NamespaceQuota {
  namespace: string;
  cpuUsed: number;
  cpuLimit: number;
  ramUsedGb: number;
  ramLimitGb: number;
  gpuUsed: number;
  gpuLimit: number;
  activePods: number;
  maxPods: number;
  status: 'Normal' | 'Warning' | 'Throttled';
}

const MOCK_NAMESPACE_QUOTAS: NamespaceQuota[] = [
  {
    namespace: 'ml-training-prod',
    cpuUsed: 192,
    cpuLimit: 256,
    ramUsedGb: 819,
    ramLimitGb: 1024,
    gpuUsed: 16,
    gpuLimit: 16,
    activePods: 32,
    maxPods: 40,
    status: 'Warning',
  },
  {
    namespace: 'model-serving-prod',
    cpuUsed: 120,
    cpuLimit: 128,
    ramUsedGb: 480,
    ramLimitGb: 512,
    gpuUsed: 8,
    gpuLimit: 8,
    activePods: 24,
    maxPods: 25,
    status: 'Throttled',
  },
  {
    namespace: 'llm-rag-experimental',
    cpuUsed: 40,
    cpuLimit: 64,
    ramUsedGb: 210,
    ramLimitGb: 256,
    gpuUsed: 4,
    gpuLimit: 4,
    activePods: 12,
    maxPods: 20,
    status: 'Normal',
  },
  {
    namespace: 'data-pipelines-etl',
    cpuUsed: 32,
    cpuLimit: 64,
    ramUsedGb: 129,
    ramLimitGb: 256,
    gpuUsed: 0,
    gpuLimit: 4,
    activePods: 16,
    maxPods: 30,
    status: 'Normal',
  },
];

interface ClusterViewProps {
  clusterNodes: GpuClusterNode[];
  onOpenCopilotWithContext?: (prompt: string) => void;
}

export const ClusterView: React.FC<ClusterViewProps> = ({ clusterNodes, onOpenCopilotWithContext }) => {
  const [activeTab, setActiveTab] = useState<'k8s' | 'gpu' | 'quotas'>('quotas');
  const [hpaConfigs] = useState<K8sHpaConfig[]>(INITIAL_K8S_HPA_CONFIGS);
  const [helmRelease] = useState<HelmReleaseInfo>(INITIAL_HELM_RELEASE);

  // Cluster aggregate totals
  const totalCpuLimit = 512;
  const totalCpuUsed = 384;
  const totalRamLimitGb = 2048;
  const totalRamUsedGb = 1638;
  const totalGpuLimit = 32;
  const totalGpuUsed = 28;

  return (
    <div className="p-6 space-y-6 text-slate-100 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 p-5 rounded-2xl border border-slate-800">
        <div>
          <h1 className="text-lg font-bold text-white flex items-center gap-2">
            <Cpu className="w-5 h-5 text-indigo-400" />
            Kubernetes Deployments, Resource Quotas & GPU Cluster Hub
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Monitor enterprise cluster resource quotas (CPU, RAM, GPU), HPA autoscaling, zero-downtime deployments, and Ray GPU nodes.
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex items-center space-x-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveTab('quotas')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'quotas'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Gauge className="w-3.5 h-3.5" />
            <span>Resource Quotas & Limits</span>
          </button>

          <button
            onClick={() => setActiveTab('k8s')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'k8s'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Box className="w-3.5 h-3.5" />
            <span>K8s & Helm Studio</span>
          </button>

          <button
            onClick={() => setActiveTab('gpu')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'gpu'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>GPU Topology ({clusterNodes.length} Nodes)</span>
          </button>
        </div>
      </div>

      {/* RESOURCE QUOTAS TAB */}
      {activeTab === 'quotas' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Cluster Quota Aggregate Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* CPU Quota Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 shadow-lg relative overflow-hidden">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-indigo-500/20 text-indigo-400 rounded-xl border border-indigo-500/30">
                    <Cpu className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-mono font-bold uppercase block">CPU Resource Quota</span>
                    <h3 className="text-sm font-bold text-white font-mono">Processor Cores</h3>
                  </div>
                </div>
                <span className="text-xs font-mono font-bold text-indigo-400 bg-indigo-500/10 border border-indigo-500/30 px-2 py-0.5 rounded">
                  {((totalCpuUsed / totalCpuLimit) * 100).toFixed(1)}% Used
                </span>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between items-baseline font-mono text-xs">
                  <span className="text-slate-400">Current / Max Limit:</span>
                  <span className="text-white font-extrabold text-base">
                    {totalCpuUsed} <span className="text-slate-500 text-xs">/ {totalCpuLimit} Cores</span>
                  </span>
                </div>
                <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden border border-slate-800">
                  <div
                    style={{ width: `${(totalCpuUsed / totalCpuLimit) * 100}%` }}
                    className="h-full bg-gradient-to-r from-indigo-500 to-cyan-400 rounded-full"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-2 border-t border-slate-800/80">
                <span>Reserved Requests: 448 Cores</span>
                <span className="text-emerald-400 font-bold">64 Cores Headroom</span>
              </div>
            </div>

            {/* RAM Memory Quota Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 shadow-lg relative overflow-hidden">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-cyan-500/20 text-cyan-400 rounded-xl border border-cyan-500/30">
                    <HardDrive className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-mono font-bold uppercase block">RAM Memory Quota</span>
                    <h3 className="text-sm font-bold text-white font-mono">System Memory</h3>
                  </div>
                </div>
                <span className="text-xs font-mono font-bold text-cyan-300 bg-cyan-500/10 border border-cyan-500/30 px-2 py-0.5 rounded">
                  {((totalRamUsedGb / totalRamLimitGb) * 100).toFixed(1)}% Used
                </span>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between items-baseline font-mono text-xs">
                  <span className="text-slate-400">Current / Max Limit:</span>
                  <span className="text-white font-extrabold text-base">
                    {totalRamUsedGb} GB <span className="text-slate-500 text-xs">/ {totalRamLimitGb} GB</span>
                  </span>
                </div>
                <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden border border-slate-800">
                  <div
                    style={{ width: `${(totalRamUsedGb / totalRamLimitGb) * 100}%` }}
                    className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-2 border-t border-slate-800/80">
                <span>Reserved Requests: 1,840 GB</span>
                <span className="text-amber-400 font-bold">208 GB Headroom</span>
              </div>
            </div>

            {/* GPU Accelerators Quota Card */}
            <div className="bg-slate-900 border border-amber-500/30 rounded-2xl p-5 space-y-3 shadow-lg relative overflow-hidden">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-amber-500/20 text-amber-400 rounded-xl border border-amber-500/30">
                    <Zap className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] text-amber-400 font-mono font-bold uppercase block">GPU Accelerators Quota</span>
                    <h3 className="text-sm font-bold text-white font-mono">H100 & A100 SXM5</h3>
                  </div>
                </div>
                <span className="text-xs font-mono font-bold text-amber-300 bg-amber-500/20 border border-amber-500/40 px-2 py-0.5 rounded">
                  {((totalGpuUsed / totalGpuLimit) * 100).toFixed(1)}% Allocated
                </span>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between items-baseline font-mono text-xs">
                  <span className="text-slate-400">Allocated / Max Quota:</span>
                  <span className="text-white font-extrabold text-base">
                    {totalGpuUsed} <span className="text-slate-500 text-xs">/ {totalGpuLimit} GPUs</span>
                  </span>
                </div>
                <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden border border-slate-800">
                  <div
                    style={{ width: `${(totalGpuUsed / totalGpuLimit) * 100}%` }}
                    className="h-full bg-gradient-to-r from-amber-500 to-orange-500 rounded-full"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-2 border-t border-slate-800/80">
                <span>VRAM Usage: 1,960 / 2,240 GB</span>
                <span className="text-rose-400 font-bold">4 GPUs Free</span>
              </div>
            </div>
          </div>

          {/* Namespace Quota Breakdown Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg space-y-4 p-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
                  <Layers className="w-4 h-4 text-indigo-400" />
                  Kubernetes Namespace Resource Quotas & LimitRanges
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Granular breakdown of hardware quotas allocated vs. consumed across project namespaces.
                </p>
              </div>

              <button
                onClick={() =>
                  onOpenCopilotWithContext?.(
                    'Analyze cluster resource quotas across namespaces and recommend node scaling rules.'
                  )
                }
                className="px-3.5 py-1.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 font-bold text-xs flex items-center gap-1.5 transition-all w-fit"
              >
                <Zap className="w-3.5 h-3.5 text-indigo-400" />
                <span>Optimize Quotas with AI</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[11px] border-b border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Namespace</th>
                    <th className="py-3 px-4">CPU Usage vs Limit</th>
                    <th className="py-3 px-4">RAM Usage vs Limit</th>
                    <th className="py-3 px-4">GPU Allocation</th>
                    <th className="py-3 px-4">Active Pods</th>
                    <th className="py-3 px-4">Quota Health</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {MOCK_NAMESPACE_QUOTAS.map((nq) => {
                    const cpuPct = (nq.cpuUsed / nq.cpuLimit) * 100;
                    const ramPct = (nq.ramUsedGb / nq.ramLimitGb) * 100;
                    const gpuPct = (nq.gpuUsed / nq.gpuLimit) * 100;

                    return (
                      <tr key={nq.namespace} className="hover:bg-slate-800/50 transition-colors">
                        <td className="py-3 px-4 font-bold text-white">
                          <div className="flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-indigo-400" />
                            {nq.namespace}
                          </div>
                        </td>

                        {/* CPU Bar */}
                        <td className="py-3 px-4">
                          <div className="space-y-1 w-36">
                            <div className="flex justify-between text-[10px]">
                              <span className="text-slate-300">{nq.cpuUsed} / {nq.cpuLimit} Cores</span>
                              <span className="text-slate-400">{cpuPct.toFixed(0)}%</span>
                            </div>
                            <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden border border-slate-800">
                              <div
                                style={{ width: `${cpuPct}%` }}
                                className={`h-full ${cpuPct > 90 ? 'bg-rose-500' : cpuPct > 75 ? 'bg-amber-400' : 'bg-indigo-400'}`}
                              />
                            </div>
                          </div>
                        </td>

                        {/* RAM Bar */}
                        <td className="py-3 px-4">
                          <div className="space-y-1 w-36">
                            <div className="flex justify-between text-[10px]">
                              <span className="text-slate-300">{nq.ramUsedGb} / {nq.ramLimitGb} GB</span>
                              <span className="text-slate-400">{ramPct.toFixed(0)}%</span>
                            </div>
                            <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden border border-slate-800">
                              <div
                                style={{ width: `${ramPct}%` }}
                                className={`h-full ${ramPct > 90 ? 'bg-rose-500' : ramPct > 75 ? 'bg-amber-400' : 'bg-cyan-400'}`}
                              />
                            </div>
                          </div>
                        </td>

                        {/* GPU Bar */}
                        <td className="py-3 px-4 font-bold">
                          <span className={gpuPct >= 100 ? 'text-amber-400' : 'text-emerald-400'}>
                            {nq.gpuUsed} / {nq.gpuLimit} GPUs ({gpuPct.toFixed(0)}%)
                          </span>
                        </td>

                        {/* Active Pods */}
                        <td className="py-3 px-4 text-slate-300">
                          {nq.activePods} / {nq.maxPods} pods
                        </td>

                        {/* Status */}
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              nq.status === 'Throttled'
                                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                                : nq.status === 'Warning'
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            }`}
                          >
                            {nq.status}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* KUBERNETES DEPLOYMENTS & HELM STUDIO TAB */}
      {activeTab === 'k8s' && (
        <K8sDeploymentStudio
          hpaConfigs={hpaConfigs}
          helmRelease={helmRelease}
          onOpenCopilotWithContext={onOpenCopilotWithContext}
        />
      )}

      {/* GPU TOPOLOGY TAB */}
      {activeTab === 'gpu' && (
        <div className="space-y-4 animate-fadeIn">
          <div className="flex justify-between items-center bg-slate-900 p-4 rounded-xl border border-slate-800 text-xs font-mono">
            <span className="text-slate-400">Total VRAM Allocation: <strong className="text-emerald-400">2,240 GB H100/A100 SXM5</strong></span>
            <span className="text-slate-400">Average Temperature: <strong className="text-cyan-400">58°C</strong></span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {clusterNodes.map((node) => (
              <div key={node.id} className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-mono text-indigo-400 uppercase font-bold">{node.gpuModel}</span>
                    <h3 className="text-xs font-bold text-white line-clamp-1">{node.nodeName}</h3>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    {node.status}
                  </span>
                </div>

                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">GPU Utilization</span>
                    <span className="text-white font-bold">{node.gpuUtilPercent}%</span>
                  </div>
                  <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                    <div
                      style={{ width: `${node.gpuUtilPercent}%` }}
                      className={`h-full ${
                        node.gpuUtilPercent > 85 ? 'bg-amber-400' : 'bg-gradient-to-r from-indigo-500 to-cyan-400'
                      }`}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px] font-mono bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                  <div>
                    <span className="text-slate-500 block text-[9px]">Temp / Power</span>
                    <span className="text-slate-200 font-bold">{node.temperatureC}°C / {node.powerWatts}W</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[9px]">Allocated Pods</span>
                    <span className="text-cyan-300 font-bold">{node.allocatedPods} pods</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
