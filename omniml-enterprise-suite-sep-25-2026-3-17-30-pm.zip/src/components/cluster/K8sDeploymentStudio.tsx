import React, { useState } from 'react';
import {
  Box,
  Cpu,
  Layers,
  ArrowUpRight,
  TrendingUp,
  RefreshCw,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  Download,
  Terminal,
  Zap,
  Sliders,
  ShieldAlert,
} from 'lucide-react';
import { K8sHpaConfig, HelmReleaseInfo } from '../../types/mlops';

interface K8sDeploymentStudioProps {
  hpaConfigs: K8sHpaConfig[];
  helmRelease: HelmReleaseInfo;
  onUpdateHpa?: (newConfigs: K8sHpaConfig[]) => void;
  onOpenCopilotWithContext?: (prompt: string) => void;
}

export const K8sDeploymentStudio: React.FC<K8sDeploymentStudioProps> = ({
  hpaConfigs: initialHpaConfigs,
  helmRelease: initialHelmRelease,
  onOpenCopilotWithContext,
}) => {
  const [activeTab, setActiveTab] = useState<'autoscaling' | 'rolling' | 'helm'>('autoscaling');
  const [hpaConfigs, setHpaConfigs] = useState<K8sHpaConfig[]>(initialHpaConfigs);
  const [helmRelease, setHelmRelease] = useState<HelmReleaseInfo>(initialHelmRelease);
  const [activeHelmFile, setActiveHelmFile] = useState<'values' | 'deployment' | 'hpa' | 'service'>('values');
  const [copiedYaml, setCopiedYaml] = useState(false);
  const [isDeploying, setIsDeploying] = useState(false);
  const [rolloutStep, setRolloutStep] = useState<number>(100); // 100% complete
  const [simulationLoad, setSimulationLoad] = useState<'Normal' | 'Peak' | 'Spike'>('Normal');

  const selectedHpa = hpaConfigs[0];

  const handleSimulateLoadSpike = (level: 'Normal' | 'Peak' | 'Spike') => {
    setSimulationLoad(level);
    setHpaConfigs((prev) =>
      prev.map((c, i) => {
        if (i === 0) {
          if (level === 'Spike') {
            return { ...c, currentCpuUtilization: 94, currentGpuUtilization: 96, currentReplicas: 24 };
          } else if (level === 'Peak') {
            return { ...c, currentCpuUtilization: 82, currentGpuUtilization: 85, currentReplicas: 14 };
          } else {
            return { ...c, currentCpuUtilization: 68, currentGpuUtilization: 72, currentReplicas: 8 };
          }
        }
        return c;
      })
    );
  };

  const handleTriggerRollingUpdate = () => {
    setIsDeploying(true);
    setRolloutStep(0);
    const interval = setInterval(() => {
      setRolloutStep((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsDeploying(false);
          setHelmRelease((r) => ({ ...r, revision: r.revision + 1, updatedAt: new Date().toISOString() }));
          return 100;
        }
        return prev + 25;
      });
    }, 700);
  };

  const handleCopyYaml = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedYaml(true);
    setTimeout(() => setCopiedYaml(false), 2000);
  };

  const getHelmYamlContent = () => {
    if (activeHelmFile === 'values') return helmRelease.valuesYaml;
    if (activeHelmFile === 'deployment') {
      return `apiVersion: apps/v1
kind: Deployment
metadata:
  name: ${selectedHpa.deploymentName}
  namespace: ${selectedHpa.namespace}
  labels:
    app.kubernetes.io/name: fraud-scoring
    app.kubernetes.io/managed-by: Helm
spec:
  replicas: ${selectedHpa.currentReplicas}
  strategy:
    type: ${selectedHpa.rollingStrategy}
    rollingUpdate:
      maxSurge: ${selectedHpa.maxSurge}
      maxUnavailable: ${selectedHpa.maxUnavailable}
  selector:
    matchLabels:
      app: fraud-scoring
  template:
    metadata:
      labels:
        app: fraud-scoring
    spec:
      containers:
        - name: inference-engine
          image: 844883108369.dkr.ecr.us-east-1.amazonaws.com/mlops/fraud-scoring:v2.1.0-champion
          ports:
            - containerPort: 3000
          resources:
            limits:
              nvidia.com/gpu: 1
              cpu: "8.0"
              memory: "32Gi"
`;
    }
    if (activeHelmFile === 'hpa') {
      return `apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: ${selectedHpa.deploymentName}-hpa
  namespace: ${selectedHpa.namespace}
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: ${selectedHpa.deploymentName}
  minReplicas: ${selectedHpa.minReplicas}
  maxReplicas: ${selectedHpa.maxReplicas}
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: ${selectedHpa.targetCpuUtilization}
    - type: External
      external:
        metric:
          name: container_gpu_utilization
        target:
          type: Value
          averageValue: "${selectedHpa.targetGpuUtilization}%"
`;
    }
    return `apiVersion: v1
kind: Service
metadata:
  name: ${selectedHpa.deploymentName}-svc
  namespace: ${selectedHpa.namespace}
spec:
  type: ClusterIP
  ports:
    - port: 80
      targetPort: 3000
      protocol: TCP
      name: http
  selector:
    app: fraud-scoring
`;
  };

  return (
    <div className="space-y-6">
      {/* Sub-Navigation */}
      <div className="flex items-center justify-between bg-slate-900 border border-slate-800 rounded-xl p-2 shadow-lg">
        <div className="flex items-center space-x-2">
          {[
            { id: 'autoscaling', label: 'HPA Autoscaling & Load Control', icon: TrendingUp },
            { id: 'rolling', label: 'Rolling Update & Zero-Downtime Rollout', icon: RotateCcw },
            { id: 'helm', label: 'Helm Chart Studio & Manifests', icon: Box },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                    : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        <button
          onClick={() =>
            onOpenCopilotWithContext?.(
              `Analyze Kubernetes deployment configuration for '${selectedHpa.deploymentName}'. Min replicas: ${selectedHpa.minReplicas}, Max: ${selectedHpa.maxReplicas}, Current CPU Target: ${selectedHpa.targetCpuUtilization}%. Recommend optimal GPU scaling thresholds.`
            )
          }
          className="text-xs font-semibold text-yellow-300 hover:text-yellow-200 bg-yellow-500/10 border border-yellow-500/30 px-3 py-1.5 rounded-lg flex items-center gap-1.5"
        >
          <Zap className="w-3.5 h-3.5" />
          <span>Copilot K8s Tuning</span>
        </button>
      </div>

      {/* TAB 1: HPA AUTOSCALING */}
      {activeTab === 'autoscaling' && (
        <div className="space-y-6">
          {/* Top Control Bar & Load Simulation */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                  Horizontal Pod Autoscaler (HPA v2) Live Controller
                </h3>
                <p className="text-xs text-slate-400">
                  Dynamic replica scaling based on real-time CPU and NVIDIA GPU telemetry thresholds.
                </p>
              </div>

              {/* Load simulation buttons */}
              <div className="flex items-center space-x-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
                <span className="text-[10px] uppercase text-slate-500 font-bold px-2">Simulate Load:</span>
                {(['Normal', 'Peak', 'Spike'] as const).map((level) => (
                  <button
                    key={level}
                    onClick={() => handleSimulateLoadSpike(level)}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                      simulationLoad === level
                        ? level === 'Spike'
                          ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30'
                          : level === 'Peak'
                          ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30'
                          : 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>

            {/* Active Deployments Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
              {hpaConfigs.map((cfg) => {
                const isSelected = cfg.deploymentName === selectedHpa.deploymentName;
                const cpuRatio = (cfg.currentCpuUtilization / cfg.targetCpuUtilization) * 100;
                const gpuRatio = (cfg.currentGpuUtilization / cfg.targetGpuUtilization) * 100;

                return (
                  <div
                    key={cfg.deploymentName}
                    className={`p-4 rounded-xl border transition-all space-y-3 ${
                      isSelected
                        ? 'bg-slate-900 border-indigo-500 ring-1 ring-indigo-500/30 shadow-lg'
                        : 'bg-slate-950/60 border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-[10px] font-mono text-slate-400 uppercase font-bold">{cfg.namespace}</span>
                        <h4 className="text-xs font-bold text-white font-mono">{cfg.deploymentName}</h4>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                        {cfg.currentReplicas} / {cfg.maxReplicas} Pods
                      </span>
                    </div>

                    {/* Progress bars */}
                    <div className="space-y-2 text-[11px] font-mono">
                      <div>
                        <div className="flex justify-between text-slate-400">
                          <span>CPU Load</span>
                          <span className={cfg.currentCpuUtilization > cfg.targetCpuUtilization ? 'text-amber-400 font-bold' : 'text-slate-200'}>
                            {cfg.currentCpuUtilization}% / {cfg.targetCpuUtilization}%
                          </span>
                        </div>
                        <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden border border-slate-800 mt-1">
                          <div
                            style={{ width: `${Math.min(100, cpuRatio)}%` }}
                            className={`h-full ${cfg.currentCpuUtilization > cfg.targetCpuUtilization ? 'bg-amber-400' : 'bg-emerald-400'}`}
                          />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-slate-400">
                          <span>GPU Load (CUDA)</span>
                          <span className={cfg.currentGpuUtilization > cfg.targetGpuUtilization ? 'text-rose-400 font-bold' : 'text-slate-200'}>
                            {cfg.currentGpuUtilization}% / {cfg.targetGpuUtilization}%
                          </span>
                        </div>
                        <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden border border-slate-800 mt-1">
                          <div
                            style={{ width: `${Math.min(100, gpuRatio)}%` }}
                            className={`h-full ${cfg.currentGpuUtilization > cfg.targetGpuUtilization ? 'bg-rose-400' : 'bg-indigo-400'}`}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400 font-mono">
                      <span>Min: {cfg.minReplicas} | Max: {cfg.maxReplicas}</span>
                      <span className="text-emerald-400">Strategy: {cfg.rollingStrategy}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Pod Mesh Live Visualization */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">
              Active Kubernetes Pod Mesh ({selectedHpa.currentReplicas} Running Containers across GKE Nodes)
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3">
              {Array.from({ length: selectedHpa.currentReplicas }).map((_, idx) => (
                <div
                  key={idx}
                  className="bg-slate-950 border border-slate-800 p-3 rounded-xl flex flex-col items-center justify-center space-y-1.5 text-center transition-all hover:border-indigo-500/50"
                >
                  <Box className="w-5 h-5 text-indigo-400 animate-pulse" />
                  <span className="text-[10px] font-mono text-slate-200 font-bold">
                    pod-{idx + 1}
                  </span>
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Running
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: ROLLING UPDATE & ZERO DOWNTIME */}
      {activeTab === 'rolling' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <RotateCcw className="w-4 h-4 text-indigo-400" />
                  Zero-Downtime Rolling Update Controller
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Configure maxSurge ({selectedHpa.maxSurge}) and maxUnavailable ({selectedHpa.maxUnavailable}) to guarantee continuous inference availability.
                </p>
              </div>

              <button
                onClick={handleTriggerRollingUpdate}
                disabled={isDeploying}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-bold text-xs flex items-center space-x-2 shadow-lg shadow-indigo-600/20 transition-all border border-indigo-400/30 disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isDeploying ? 'animate-spin' : ''}`} />
                <span>{isDeploying ? 'Deploying Rolling Update...' : 'Execute Rolling Update to Revision ' + (helmRelease.revision + 1)}</span>
              </button>
            </div>

            {/* Live Progress Bar */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">Rollout Status</span>
                <span className="text-indigo-400 font-bold">{rolloutStep}% Complete</span>
              </div>
              <div className="w-full bg-slate-900 h-2.5 rounded-full overflow-hidden border border-slate-800">
                <div
                  style={{ width: `${rolloutStep}%` }}
                  className="h-full bg-gradient-to-r from-indigo-500 via-cyan-400 to-emerald-400 transition-all duration-500"
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono pt-1">
                <span>Active Revision: <strong>rev-{helmRelease.revision}</strong></span>
                <span>Strategy: <strong>maxSurge=25%, maxUnavailable=0%</strong></span>
              </div>
            </div>

            {/* Revision History Log Table */}
            <div className="border border-slate-800 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 uppercase font-mono text-[10px]">
                  <tr>
                    <th className="p-3">Revision</th>
                    <th className="p-3">Image Tag</th>
                    <th className="p-3">Deployed At</th>
                    <th className="p-3">Status</th>
                    <th className="p-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 font-mono">
                  <tr className="bg-indigo-950/20">
                    <td className="p-3 font-bold text-indigo-300">v{helmRelease.revision} (Current)</td>
                    <td className="p-3 text-slate-200">v2.1.0-champion</td>
                    <td className="p-3 text-slate-400">{helmRelease.updatedAt.substring(0, 19)}</td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        Active
                      </span>
                    </td>
                    <td className="p-3 text-right text-slate-500">N/A</td>
                  </tr>

                  <tr className="hover:bg-slate-800/40">
                    <td className="p-3 text-slate-400">v{helmRelease.revision - 1}</td>
                    <td className="p-3 text-slate-300">v2.0.4-staging</td>
                    <td className="p-3 text-slate-500">2026-07-30 11:20:00</td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                        Superseded
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <button
                        onClick={() => alert('Initiating 1-click rollback to revision v' + (helmRelease.revision - 1))}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 text-[10px] font-bold border border-slate-700"
                      >
                        Rollback
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: HELM CHART STUDIO */}
      {activeTab === 'helm' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Box className="w-4 h-4 text-cyan-400" />
                  Helm Chart Spec & Manifest Studio
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Packaging model deployments as parameterized Kubernetes Helm charts for automated GitOps CD.
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => handleCopyYaml(getHelmYamlContent())}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700"
                >
                  {copiedYaml ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedYaml ? 'Copied YAML!' : 'Copy Manifest'}</span>
                </button>
              </div>
            </div>

            {/* Manifest File Selector */}
            <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
              {[
                { id: 'values', label: 'values.yaml' },
                { id: 'deployment', label: 'templates/deployment.yaml' },
                { id: 'hpa', label: 'templates/hpa.yaml' },
                { id: 'service', label: 'templates/service.yaml' },
              ].map((f) => (
                <button
                  key={f.id}
                  onClick={() => setActiveHelmFile(f.id as any)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all ${
                    activeHelmFile === f.id
                      ? 'bg-cyan-600 text-white font-bold'
                      : 'text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            {/* Code Mirror / YAML Display */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs text-slate-200 overflow-x-auto max-h-[450px]">
              <pre>{getHelmYamlContent()}</pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
