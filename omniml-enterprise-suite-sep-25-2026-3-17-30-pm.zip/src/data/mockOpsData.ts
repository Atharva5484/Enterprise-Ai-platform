import {
  K8sHpaConfig,
  HelmReleaseInfo,
  NotificationChannelConfig,
  AutoRetrainPolicy,
} from '../types/mlops';

export const INITIAL_K8S_HPA_CONFIGS: K8sHpaConfig[] = [
  {
    deploymentName: 'prod-fraud-scoring-v3',
    namespace: 'ml-serving',
    minReplicas: 4,
    maxReplicas: 32,
    currentReplicas: 8,
    targetCpuUtilization: 75,
    currentCpuUtilization: 68,
    targetGpuUtilization: 80,
    currentGpuUtilization: 72,
    maxSurge: '25%',
    maxUnavailable: '0%',
    rollingStrategy: 'RollingUpdate',
  },
  {
    deploymentName: 'churn-predictor-v1',
    namespace: 'ml-serving',
    minReplicas: 2,
    maxReplicas: 12,
    currentReplicas: 3,
    targetCpuUtilization: 80,
    currentCpuUtilization: 42,
    targetGpuUtilization: 75,
    currentGpuUtilization: 38,
    maxSurge: '50%',
    maxUnavailable: '0%',
    rollingStrategy: 'RollingUpdate',
  },
  {
    deploymentName: 'llm-copilot-fine-tuned',
    namespace: 'genai-inference',
    minReplicas: 2,
    maxReplicas: 16,
    currentReplicas: 4,
    targetCpuUtilization: 70,
    currentCpuUtilization: 55,
    targetGpuUtilization: 85,
    currentGpuUtilization: 81,
    maxSurge: '1',
    maxUnavailable: '0',
    rollingStrategy: 'Canary',
  },
];

export const INITIAL_HELM_RELEASE: HelmReleaseInfo = {
  releaseName: 'fraud-model-service',
  namespace: 'ml-serving',
  chartVersion: 'v2.4.1',
  appVersion: 'v2.1.0-champion',
  status: 'Deployed',
  revision: 14,
  updatedAt: '2026-08-02 14:32:00 UTC',
  valuesYaml: `# Helm Chart Values for MLOps Serving Endpoint
replicaCount: 8

image:
  repository: 844883108369.dkr.ecr.us-east-1.amazonaws.com/mlops/fraud-scoring
  tag: v2.1.0-champion
  pullPolicy: IfNotPresent

resources:
  limits:
    cpu: "8.0"
    memory: "32Gi"
    nvidia.com/gpu: "1"
  requests:
    cpu: "4.0"
    memory: "16Gi"
    nvidia.com/gpu: "1"

autoscaling:
  enabled: true
  minReplicas: 4
  maxReplicas: 32
  targetCPUUtilizationPercentage: 75
  targetGPUUtilizationPercentage: 80

rollingUpdate:
  maxSurge: 25%
  maxUnavailable: 0%

env:
  - name: MODEL_ARTIFACT_PATH
    value: "s3://mlops-models-registry/fraud_xgboost_v2.1.tar.gz"
  - name: PROMETHEUS_METRICS_ENABLED
    value: "true"
  - name: LOG_LEVEL
    value: "INFO"

ingress:
  enabled: true
  className: "nginx"
  annotations:
    cert-manager.io/cluster-issuer: "letsencrypt-prod"
  hosts:
    - host: fraud-api.mlops.enterprise.ai
      paths:
        - path: /api/v1/predict
          pathType: Prefix
`,
};

export const INITIAL_NOTIFICATION_CHANNELS: NotificationChannelConfig[] = [
  {
    id: 'chan-slack',
    type: 'slack',
    name: 'Slack #mlops-critical-alerts',
    destination: 'https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXX',
    enabled: true,
    alertOnCriticalDrift: true,
    alertOnPipelineFailure: true,
    alertOnAutoscaling: false,
    lastTestStatus: 'Success',
    lastTestTime: '2026-08-03 04:15:00',
  },
  {
    id: 'chan-teams',
    type: 'teams',
    name: 'MS Teams MLOps On-Call',
    destination: 'https://outlook.office.com/webhook/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx',
    enabled: true,
    alertOnCriticalDrift: true,
    alertOnPipelineFailure: true,
    alertOnAutoscaling: true,
    lastTestStatus: 'Success',
    lastTestTime: '2026-08-03 04:15:00',
  },
  {
    id: 'chan-email',
    type: 'email',
    name: 'Email SMTP On-Call Group',
    destination: 'mlops-oncall@enterprise.ai, lead-ds@enterprise.ai',
    enabled: true,
    alertOnCriticalDrift: true,
    alertOnPipelineFailure: true,
    alertOnAutoscaling: false,
    lastTestStatus: 'Success',
    lastTestTime: '2026-08-03 04:15:00',
  },
];

export const INITIAL_AUTO_RETRAIN_POLICIES: AutoRetrainPolicy[] = [
  {
    id: 'policy-01',
    modelName: 'Fraud Scoring Model (XGBoost)',
    enabled: true,
    psiThreshold: 0.25,
    accuracyDropThreshold: 0.05,
    conceptDriftPValue: 0.01,
    cooldownPeriodHours: 12,
    targetPipelineId: 'pipe-01',
    notifyChannels: ['slack', 'teams', 'email'],
    lastTriggeredAt: '2026-08-01 10:20:00',
    totalTriggersCount: 3,
  },
  {
    id: 'policy-02',
    modelName: 'Customer Churn Predictor',
    enabled: true,
    psiThreshold: 0.20,
    accuracyDropThreshold: 0.04,
    conceptDriftPValue: 0.05,
    cooldownPeriodHours: 24,
    targetPipelineId: 'pipe-02',
    notifyChannels: ['slack', 'email'],
    lastTriggeredAt: '2026-07-28 16:45:00',
    totalTriggersCount: 1,
  },
];
