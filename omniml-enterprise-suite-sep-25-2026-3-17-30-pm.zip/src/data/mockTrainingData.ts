import {
  MlflowExperimentRun,
  FastApiEndpointConfig,
  DockerContainerConfig,
} from '../types/mlops';

export const INITIAL_MLFLOW_RUNS: MlflowExperimentRun[] = [
  {
    id: 'run-xgb-optuna-01',
    runName: 'xgboost_fraud_optuna_trial_42',
    experimentName: 'global_transaction_fraud_v2_exp',
    framework: 'XGBoost',
    datasetName: 'global_transaction_fraud_v2',
    datasetVersion: 'v2.0.0-clean',
    taskType: 'Binary Classification',
    status: 'FINISHED',
    startedAt: '2026-08-03 02:15:20',
    durationSec: 148,
    author: 'Dr. Marcus Vance',
    modelSizeMb: 24.5,
    isRegistered: true,
    registeredModelVersion: 'v2.1.0-prod',
    artifactPath: 's3://nexusml-mlflow-artifacts/experiments/3 font/run-xgb-optuna-01/artifacts/model.xgb',
    params: {
      n_estimators: 850,
      max_depth: 8,
      learning_rate: 0.032,
      subsample: 0.85,
      colsample_bytree: 0.78,
      gamma: 0.2,
      scale_pos_weight: 4.5,
      tree_method: 'hist',
      device: 'cuda:0',
    },
    metrics: {
      accuracy: 0.984,
      f1Score: 0.942,
      rocAuc: 0.989,
      precision: 0.938,
      recall: 0.946,
      trainingLoss: 0.042,
      validationLoss: 0.051,
      inferenceLatencyMs: 4.2,
    },
    crossValScores: [0.988, 0.991, 0.987, 0.989, 0.990],
    trials: [
      { trialId: 1, params: { learning_rate: 0.1, max_depth: 4 }, score: 0.952, valLoss: 0.12, durationSec: 12, status: 'Completed' },
      { trialId: 12, params: { learning_rate: 0.05, max_depth: 6 }, score: 0.971, valLoss: 0.08, durationSec: 18, status: 'Completed' },
      { trialId: 28, params: { learning_rate: 0.03, max_depth: 12 }, score: 0.965, valLoss: 0.09, durationSec: 24, status: 'Pruned' },
      { trialId: 42, params: { learning_rate: 0.032, max_depth: 8 }, score: 0.989, valLoss: 0.051, durationSec: 22, status: 'Completed' },
    ],
    rocPoints: [
      { fpr: 0.0, tpr: 0.0, threshold: 1.0 },
      { fpr: 0.005, tpr: 0.88, threshold: 0.85 },
      { fpr: 0.012, tpr: 0.95, threshold: 0.60 },
      { fpr: 0.025, tpr: 0.98, threshold: 0.40 },
      { fpr: 0.08, tpr: 0.995, threshold: 0.15 },
      { fpr: 1.0, tpr: 1.0, threshold: 0.0 },
    ],
    confusionMatrix: {
      tp: 1419,
      fp: 94,
      tn: 34210,
      fn: 81,
      labels: ['Non-Fraud (0)', 'Fraud (1)'],
    },
    featureImportances: [
      { feature: 'txn_velocity_1h', importance: 0.32 },
      { feature: 'txn_amount_log1p', importance: 0.28 },
      { feature: 'unique_device_ip_count_7d', importance: 0.19 },
      { feature: 'merchant_category_code_MCC-7995', importance: 0.12 },
      { feature: 'user_account_age_days', importance: 0.09 },
    ],
  },
  {
    id: 'run-lgb-fast-02',
    runName: 'lightgbm_churn_leaf_tune_05',
    experimentName: 'global_transaction_fraud_v2_exp',
    framework: 'LightGBM',
    datasetName: 'global_transaction_fraud_v2',
    datasetVersion: 'v2.0.0-clean',
    taskType: 'Binary Classification',
    status: 'FINISHED',
    startedAt: '2026-08-03 01:40:00',
    durationSec: 62,
    author: 'Alex Rivera',
    modelSizeMb: 12.8,
    isRegistered: false,
    artifactPath: 's3://nexusml-mlflow-artifacts/experiments/3/run-lgb-fast-02/artifacts/model.lgb',
    params: {
      num_leaves: 128,
      max_depth: -1,
      learning_rate: 0.045,
      n_estimators: 600,
      min_child_samples: 30,
      boosting_type: 'gbdt',
      objective: 'binary',
    },
    metrics: {
      accuracy: 0.981,
      f1Score: 0.935,
      rocAuc: 0.985,
      precision: 0.929,
      recall: 0.941,
      trainingLoss: 0.048,
      validationLoss: 0.058,
      inferenceLatencyMs: 1.8,
    },
    crossValScores: [0.984, 0.986, 0.985, 0.983, 0.987],
    rocPoints: [
      { fpr: 0.0, tpr: 0.0, threshold: 1.0 },
      { fpr: 0.008, tpr: 0.85, threshold: 0.85 },
      { fpr: 0.018, tpr: 0.93, threshold: 0.60 },
      { fpr: 0.035, tpr: 0.97, threshold: 0.40 },
      { fpr: 1.0, tpr: 1.0, threshold: 0.0 },
    ],
    confusionMatrix: {
      tp: 1400,
      fp: 108,
      tn: 34196,
      fn: 100,
      labels: ['Non-Fraud (0)', 'Fraud (1)'],
    },
    featureImportances: [
      { feature: 'txn_velocity_1h', importance: 0.35 },
      { feature: 'txn_amount_log1p', importance: 0.25 },
      { feature: 'unique_device_ip_count_7d', importance: 0.22 },
      { feature: 'user_account_age_days', importance: 0.18 },
    ],
  },
  {
    id: 'run-catboost-03',
    runName: 'catboost_categorical_trees_01',
    experimentName: 'global_transaction_fraud_v2_exp',
    framework: 'CatBoost',
    datasetName: 'global_transaction_fraud_v2',
    datasetVersion: 'v2.0.0-clean',
    taskType: 'Binary Classification',
    status: 'FINISHED',
    startedAt: '2026-08-02 23:10:00',
    durationSec: 210,
    author: 'Sarah Chen',
    modelSizeMb: 38.2,
    isRegistered: true,
    registeredModelVersion: 'v1.4.0-staging',
    artifactPath: 's3://nexusml-mlflow-artifacts/experiments/3/run-catboost-03/artifacts/model.cbm',
    params: {
      iterations: 1200,
      depth: 7,
      learning_rate: 0.028,
      l2_leaf_reg: 3.0,
      loss_function: 'Logloss',
      eval_metric: 'AUC',
    },
    metrics: {
      accuracy: 0.986,
      f1Score: 0.948,
      rocAuc: 0.992,
      precision: 0.945,
      recall: 0.951,
      trainingLoss: 0.038,
      validationLoss: 0.046,
      inferenceLatencyMs: 3.5,
    },
    crossValScores: [0.991, 0.993, 0.990, 0.992, 0.994],
    rocPoints: [
      { fpr: 0.0, tpr: 0.0, threshold: 1.0 },
      { fpr: 0.003, tpr: 0.91, threshold: 0.85 },
      { fpr: 0.009, tpr: 0.97, threshold: 0.60 },
      { fpr: 0.018, tpr: 0.99, threshold: 0.40 },
      { fpr: 1.0, tpr: 1.0, threshold: 0.0 },
    ],
    confusionMatrix: {
      tp: 1426,
      fp: 82,
      tn: 34222,
      fn: 74,
      labels: ['Non-Fraud (0)', 'Fraud (1)'],
    },
    featureImportances: [
      { feature: 'txn_velocity_1h', importance: 0.38 },
      { feature: 'merchant_category_code', importance: 0.26 },
      { feature: 'txn_amount_log1p', importance: 0.21 },
      { feature: 'unique_device_ip_count_7d', importance: 0.15 },
    ],
  },
  {
    id: 'run-pytorch-04',
    runName: 'pytorch_resnet_tabular_v1',
    experimentName: 'global_transaction_fraud_v2_exp',
    framework: 'PyTorch',
    datasetName: 'global_transaction_fraud_v2',
    datasetVersion: 'v2.0.0-clean',
    taskType: 'Binary Classification',
    status: 'FINISHED',
    startedAt: '2026-08-02 20:00:00',
    durationSec: 420,
    author: 'Dr. Marcus Vance',
    modelSizeMb: 112.4,
    isRegistered: false,
    artifactPath: 's3://nexusml-mlflow-artifacts/experiments/3/run-pytorch-04/artifacts/model.pt',
    params: {
      batch_size: 512,
      learning_rate: 0.0008,
      optimizer: 'AdamW',
      weight_decay: 0.01,
      epochs: 50,
      layer_sizes: '[256, 128, 64]',
      dropout: 0.2,
      scheduler: 'CosineAnnealingLR',
    },
    metrics: {
      accuracy: 0.982,
      f1Score: 0.938,
      rocAuc: 0.988,
      precision: 0.931,
      recall: 0.945,
      trainingLoss: 0.045,
      validationLoss: 0.054,
      inferenceLatencyMs: 6.8,
    },
    crossValScores: [0.986, 0.988, 0.987, 0.989, 0.988],
    rocPoints: [
      { fpr: 0.0, tpr: 0.0, threshold: 1.0 },
      { fpr: 0.006, tpr: 0.87, threshold: 0.85 },
      { fpr: 0.015, tpr: 0.94, threshold: 0.60 },
      { fpr: 0.028, tpr: 0.98, threshold: 0.40 },
      { fpr: 1.0, tpr: 1.0, threshold: 0.0 },
    ],
    confusionMatrix: {
      tp: 1410,
      fp: 102,
      tn: 34202,
      fn: 90,
      labels: ['Non-Fraud (0)', 'Fraud (1)'],
    },
    featureImportances: [
      { feature: 'txn_amount_log1p', importance: 0.31 },
      { feature: 'txn_velocity_1h', importance: 0.29 },
      { feature: 'unique_device_ip_count_7d', importance: 0.22 },
      { feature: 'merchant_category_code_MCC-7995', importance: 0.18 },
    ],
  },
  {
    id: 'run-tf-keras-05',
    runName: 'tf_keras_deep_tabular_02',
    experimentName: 'global_transaction_fraud_v2_exp',
    framework: 'TensorFlow',
    datasetName: 'global_transaction_fraud_v2',
    datasetVersion: 'v2.0.0-clean',
    taskType: 'Binary Classification',
    status: 'FINISHED',
    startedAt: '2026-08-02 18:30:00',
    durationSec: 380,
    author: 'Elena Rostova',
    modelSizeMb: 88.0,
    isRegistered: false,
    artifactPath: 's3://nexusml-mlflow-artifacts/experiments/3/run-tf-keras-05/artifacts/saved_model/',
    params: {
      batch_size: 256,
      learning_rate: 0.001,
      optimizer: 'Adam',
      epochs: 40,
      hidden_units: '[128, 64, 32]',
      activation: 'swish',
    },
    metrics: {
      accuracy: 0.978,
      f1Score: 0.924,
      rocAuc: 0.979,
      precision: 0.915,
      recall: 0.933,
      trainingLoss: 0.055,
      validationLoss: 0.068,
      inferenceLatencyMs: 8.5,
    },
    crossValScores: [0.978, 0.980, 0.979, 0.977, 0.981],
    rocPoints: [
      { fpr: 0.0, tpr: 0.0, threshold: 1.0 },
      { fpr: 0.01, tpr: 0.82, threshold: 0.85 },
      { fpr: 0.022, tpr: 0.91, threshold: 0.60 },
      { fpr: 0.045, tpr: 0.95, threshold: 0.40 },
      { fpr: 1.0, tpr: 1.0, threshold: 0.0 },
    ],
    confusionMatrix: {
      tp: 1380,
      fp: 125,
      tn: 34179,
      fn: 120,
      labels: ['Non-Fraud (0)', 'Fraud (1)'],
    },
    featureImportances: [
      { feature: 'txn_velocity_1h', importance: 0.33 },
      { feature: 'txn_amount_log1p', importance: 0.27 },
      { feature: 'unique_device_ip_count_7d', importance: 0.24 },
      { feature: 'merchant_category_code_MCC-7995', importance: 0.16 },
    ],
  },
  {
    id: 'run-sklearn-rf-06',
    runName: 'sklearn_random_forest_baseline',
    experimentName: 'global_transaction_fraud_v2_exp',
    framework: 'Scikit-Learn',
    datasetName: 'global_transaction_fraud_v2',
    datasetVersion: 'v2.0.0-clean',
    taskType: 'Binary Classification',
    status: 'FINISHED',
    startedAt: '2026-08-02 16:10:00',
    durationSec: 45,
    author: 'Alex Rivera',
    modelSizeMb: 18.2,
    isRegistered: false,
    artifactPath: 's3://nexusml-mlflow-artifacts/experiments/3/run-sklearn-rf-06/artifacts/model.joblib',
    params: {
      n_estimators: 200,
      max_depth: 15,
      min_samples_split: 5,
      class_weight: 'balanced',
      n_jobs: -1,
    },
    metrics: {
      accuracy: 0.971,
      f1Score: 0.912,
      rocAuc: 0.968,
      precision: 0.902,
      recall: 0.922,
      trainingLoss: 0.072,
      validationLoss: 0.084,
      inferenceLatencyMs: 12.0,
    },
    crossValScores: [0.965, 0.970, 0.968, 0.967, 0.971],
    rocPoints: [
      { fpr: 0.0, tpr: 0.0, threshold: 1.0 },
      { fpr: 0.015, tpr: 0.78, threshold: 0.85 },
      { fpr: 0.035, tpr: 0.88, threshold: 0.60 },
      { fpr: 0.062, tpr: 0.93, threshold: 0.40 },
      { fpr: 1.0, tpr: 1.0, threshold: 0.0 },
    ],
    confusionMatrix: {
      tp: 1350,
      fp: 145,
      tn: 34159,
      fn: 150,
      labels: ['Non-Fraud (0)', 'Fraud (1)'],
    },
    featureImportances: [
      { feature: 'txn_velocity_1h', importance: 0.36 },
      { feature: 'txn_amount_log1p', importance: 0.28 },
      { feature: 'unique_device_ip_count_7d', importance: 0.20 },
      { feature: 'merchant_category_code_MCC-7995', importance: 0.16 },
    ],
  },
];

export const INITIAL_FASTAPI_CONFIG: FastApiEndpointConfig = {
  serviceName: 'nexus_fraud_prediction_service',
  modelRunId: 'run-xgb-optuna-01',
  version: 'v2.1.0-prod',
  port: 8000,
  workers: 4,
  pythonCode: `from fastapi import FastAPI, HTTPException, Security, Depends
from fastapi.security.api_key import APIKeyHeader
from pydantic import BaseModel, Field
import xgboost as xgb
import numpy as np
import time
import os

app = FastAPI(
    title="NexusML Fraud Detection Service",
    description="High-Throughput Real-Time XGBoost Fraud Inference API",
    version="2.1.0"
)

API_KEY = os.getenv("NEXUS_API_KEY", "nexus-secret-key-2026")
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)

class FraudInferenceRequest(BaseModel):
    user_id: int = Field(..., example=10042)
    txn_amount: float = Field(..., example=2450.0)
    txn_velocity_1h: int = Field(..., example=4)
    unique_device_ip_count_7d: int = Field(..., example=5)
    merchant_category_code: str = Field(..., example="MCC-7995")

class FraudInferenceResponse(BaseModel):
    transaction_id: str
    fraud_probability: float
    is_fraud_flag: bool
    risk_level: str
    inference_latency_ms: float

@app.get("/health")
def health_check():
    return {"status": "HEALTHY", "model_loaded": True, "engine": "XGBoost 2.0.3"}

@app.post("/predict", response_model=FraudInferenceResponse)
def predict_fraud(req: FraudInferenceRequest):
    start = time.perf_counter()
    
    # Feature vector preparation
    log_amt = np.log1p(req.txn_amount)
    prob = 1.0 / (1.0 + np.exp(-(0.8 * req.txn_velocity_1h + 0.5 * log_amt + 0.3 * req.unique_device_ip_count_7d - 4.5)))
    
    latency = (time.perf_counter() - start) * 1000.0
    return FraudInferenceResponse(
        transaction_id=f"TXN-{int(time.time()*1000)}",
        fraud_probability=round(float(prob), 4),
        is_fraud_flag=prob > 0.65,
        risk_level="CRITICAL" if prob > 0.85 else "HIGH" if prob > 0.65 else "LOW",
        inference_latency_ms=round(latency, 2)
    )
`,
  pydanticSchemaCode: `class FraudInferenceRequest(BaseModel):
    user_id: int
    txn_amount: float
    txn_velocity_1h: int
    unique_device_ip_count_7d: int
    merchant_category_code: str`,
  openApiSchemaJson: {
    openapi: "3.0.2",
    info: {
      title: "NexusML Fraud Detection Service",
      version: "2.1.0"
    },
    paths: {
      "/health": {
        get: {
          summary: "Health Check",
          responses: { "200": { description: "Service status OK" } }
        }
      },
      "/predict": {
        post: {
          summary: "Run XGBoost Fraud Probability Inference",
          requestBody: {
            content: {
              "application/json": {
                schema: { "$ref": "#/components/schemas/FraudInferenceRequest" }
              }
            }
          },
          responses: { "200": { description: "Inference successful" } }
        }
      }
    }
  },
  samplePayload: {
    user_id: 10042,
    txn_amount: 2450.0,
    txn_velocity_1h: 4,
    unique_device_ip_count_7d: 5,
    merchant_category_code: "MCC-7995"
  }
};

export const INITIAL_DOCKER_CONFIG: DockerContainerConfig = {
  imageName: 'nexusml/fraud-detection-service',
  tag: 'v2.1.0-cuda',
  baseImage: 'nvidia/cuda:12.1.0-runtime-ubuntu22.04',
  cudaEnabled: true,
  imageSizeMb: 412.5,
  vulnerabilityScan: 'Passed (0 High/Critical)',
  buildLogs: [
    '[1/6] FROM nvidia/cuda:12.1.0-runtime-ubuntu22.04 as base',
    '[2/6] RUN apt-get update && apt-get install -y python3-pip python3-dev libgomp1',
    '[3/6] COPY requirements.txt . && PIP_NO_CACHE_DIR=1 pip install -r requirements.txt',
    '[4/6] COPY ./model_artifacts /app/model_artifacts',
    '[5/6] COPY ./service /app/service',
    '[6/6] EXPOSE 8000',
    'Successfully built image nexusml/fraud-detection-service:v2.1.0-cuda (412.5MB)'
  ],
  dockerfileContent: `# Multi-stage Dockerfile for NexusML FastAPI Serving Image
FROM nvidia/cuda:12.1.0-runtime-ubuntu22.04 as base

WORKDIR /app

ENV PYTHONUNBUFFERED=1 \\
    PYTHONDONTWRITEBYTECODE=1 \\
    PIP_NO_CACHE_DIR=1

RUN apt-get update && apt-get install -y --no-install-recommends \\
    python3.11 \\
    python3-pip \\
    libgomp1 \\
    curl \\
    && rm -rf /var/lib/apt/lists/*

COPY requirements.txt .
RUN pip3 install --upgrade pip && pip3 install -r requirements.txt

COPY ./artifacts /app/artifacts
COPY ./server /app/server

EXPOSE 8000

HEALTHCHECK --interval=10s --timeout=3s --retries=3 \\
  CMD curl -f http://localhost:8000/health || exit 1

CMD ["uvicorn", "server.main:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "4"]
`,
  dockerComposeContent: `version: '3.8'

services:
  fraud-inference-api:
    image: nexusml/fraud-detection-service:v2.1.0-cuda
    container_name: nexus_fraud_service
    restart: always
    ports:
      - "8000:8000"
    environment:
      - NEXUS_API_KEY=nexus-secret-key-2026
      - MODEL_ARTIFACT_URI=s3://nexusml-mlflow-artifacts/experiments/3/run-xgb-optuna-01/artifacts/model.xgb
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 10s
      timeout: 5s
      retries: 3
`,
  nginxConfContent: `server {
    listen 80;
    server_name api.nexusml.io;

    location / {
        proxy_pass http://fraud-inference-api:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}`
};
