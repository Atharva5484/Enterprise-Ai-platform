import React, { useState, useEffect } from 'react';
import { Header } from './components/common/Header';
import { Sidebar, NavTab } from './components/common/Sidebar';
import { OverviewDashboard } from './components/dashboard/OverviewDashboard';
import { ModelRegistryView } from './components/registry/ModelRegistryView';
import { FeatureStoreView } from './components/featurestore/FeatureStoreView';
import { PipelineView } from './components/pipelines/PipelineView';
import { ModelServingView } from './components/serving/ModelServingView';
import { MonitoringView } from './components/monitoring/MonitoringView';
import { LLMOpsView } from './components/llmops/LLMOpsView';
import { ClusterView } from './components/cluster/ClusterView';
import { GovernanceView } from './components/governance/GovernanceView';
import { MLOpsCopilotModal } from './components/copilot/MLOpsCopilotModal';
import { DatasetHubView } from './components/datasets/DatasetHubView';
import { TrainingHubView } from './components/training/TrainingHubView';
import { InfrastructureStorageView } from './components/storage/InfrastructureStorageView';
import { UserManagementView } from './components/users/UserManagementView';
import { ArchitectureDocView } from './components/docs/ArchitectureDocView';
import { AuthModal } from './components/auth/AuthModal';
import { ExportDataModal } from './components/common/ExportDataModal';
import {
  AlertCenterProvider,
  useAlertCenter,
  FloatingToastContainer,
  AlertCenterDrawer,
} from './context/AlertCenterContext';

import {
  Environment,
  UserRole,
  ModelStage,
  RegisteredModel,
  MlPipelineRun,
  ServingEndpoint,
  AuditLogItem,
  DatasetItem,
  FeatureEnginePipeline,
  AuthUser,
  MlflowExperimentRun,
  FastApiEndpointConfig,
  DockerContainerConfig,
} from './types/mlops';

import {
  INITIAL_REGISTERED_MODELS,
  INITIAL_FEATURE_VIEWS,
  INITIAL_PIPELINE_RUNS,
  INITIAL_SERVING_ENDPOINTS,
  INITIAL_DRIFT_METRICS,
  INITIAL_PROMPT_TEMPLATES,
  INITIAL_CLUSTER_NODES,
  INITIAL_AUDIT_LOGS,
} from './data/mockMlopsData';

import {
  INITIAL_DATASETS,
  INITIAL_FEATURE_PIPELINES,
  PRESET_USERS,
} from './data/mockDatasetsData';

import {
  INITIAL_MLFLOW_RUNS,
  INITIAL_FASTAPI_CONFIG,
  INITIAL_DOCKER_CONFIG,
} from './data/mockTrainingData';

function MainAppContent() {
  const { setIsAlertCenterOpen, unreadCount } = useAlertCenter();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const [environment, setEnvironment] = useState<Environment>('production');
  const [userRole, setUserRole] = useState<UserRole>('Admin');
  const [currentUser, setCurrentUser] = useState<AuthUser>(PRESET_USERS[0]);
  const [jwtToken, setJwtToken] = useState<string>(
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1c3ItYWRtaW4iLCJlbWFpbCI6ImFkbWluQG5leHVzbWwuaW8iLCJuYW1lIjoiU2FyYWggQ2hlbiIsInJvbGUiOiJBZG1pbiIsImlhdCI6MTc4Njk0MjAwMCwiZXhwIjoxNzg3MDI4NDAwLCJwZXJtaXNzaW9ucyI6WyIqIl19.nexus-secret-signature'
  );
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [exportModalContext, setExportModalContext] = useState<string>('agent_orchestration');

  const handleOpenExportModal = (context = 'agent_orchestration') => {
    setExportModalContext(context);
    setIsExportModalOpen(true);
  };

  const [activeTab, setActiveTab] = useState<NavTab>('overview');

  const [models, setModels] = useState<RegisteredModel[]>(INITIAL_REGISTERED_MODELS);
  const [datasets, setDatasets] = useState<DatasetItem[]>(INITIAL_DATASETS);
  const [featurePipelines, setFeaturePipelines] = useState<FeatureEnginePipeline[]>(INITIAL_FEATURE_PIPELINES);
  const [mlflowRuns, setMlflowRuns] = useState<MlflowExperimentRun[]>(INITIAL_MLFLOW_RUNS);
  const [fastApiConfig, setFastApiConfig] = useState<FastApiEndpointConfig>(INITIAL_FASTAPI_CONFIG);
  const [dockerConfig, setDockerConfig] = useState<DockerContainerConfig>(INITIAL_DOCKER_CONFIG);

  const [featureViews] = useState(INITIAL_FEATURE_VIEWS);
  const [pipelines, setPipelines] = useState<MlPipelineRun[]>(INITIAL_PIPELINE_RUNS);
  const [endpoints, setEndpoints] = useState<ServingEndpoint[]>(INITIAL_SERVING_ENDPOINTS);
  const [driftMetrics] = useState(INITIAL_DRIFT_METRICS);
  const [promptTemplates] = useState(INITIAL_PROMPT_TEMPLATES);
  const [clusterNodes] = useState(INITIAL_CLUSTER_NODES);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>(INITIAL_AUDIT_LOGS);

  const [isCopilotOpen, setIsCopilotOpen] = useState(false);
  const [copilotContextPrompt, setCopilotContextPrompt] = useState('');

  // Handle Login & JWT Token Update
  const handleLoginSuccess = (user: AuthUser, token: string) => {
    setCurrentUser(user);
    setJwtToken(token);
    setUserRole(user.role);
    setIsAuthModalOpen(false);

    // Audit log
    const newAudit: AuditLogItem = {
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      user: user.email,
      role: user.role,
      action: 'JWT_AUTH_LOGIN',
      targetResource: `User Identity: ${user.name}`,
      status: 'Success',
      details: `Authenticated user via JWT Token with permissions granted for role ${user.role}.`,
      ipAddress: '10.128.0.42',
    };
    setAuditLogs((prev) => [newAudit, ...prev]);
  };

  // Training Handlers
  const handleAddTrainingRun = (newRun: MlflowExperimentRun) => {
    setMlflowRuns((prev) => [newRun, ...prev]);
    const newAudit: AuditLogItem = {
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      user: currentUser.email,
      role: userRole,
      action: 'AUTOMATED_TRAINING_RUN',
      targetResource: `Run ID: ${newRun.id} (${newRun.framework})`,
      status: 'Success',
      details: `Completed automated training run with ${newRun.framework}. ROC-AUC: ${(newRun.metrics.rocAuc * 100).toFixed(1)}%.`,
      ipAddress: '10.128.0.42',
    };
    setAuditLogs((prev) => [newAudit, ...prev]);
  };

  const handleRegisterRunToModelRegistry = (run: MlflowExperimentRun) => {
    setMlflowRuns((prev) =>
      prev.map((r) => (r.id === run.id ? { ...r, isRegistered: true, registeredModelVersion: 'v2.2.0-staging' } : r))
    );

    // Register new version in RegisteredModel
    setModels((prevModels) =>
      prevModels.map((m) => {
        if (m.name.toLowerCase().includes('fraud') || m.id === 'reg-mod-01') {
          return {
            ...m,
            lastUpdated: 'Just now',
            versions: [
              {
                id: `v-reg-${Date.now().toString().slice(-4)}`,
                version: 'v2.2.0-staging',
                stage: 'Staging',
                framework: run.framework as any,
                accuracy: run.metrics.accuracy,
                f1Score: run.metrics.f1Score,
                latencyMs: run.metrics.inferenceLatencyMs,
                throughputQps: 450,
                sizeMb: run.modelSizeMb,
                createdAt: new Date().toISOString().replace('T', ' ').substring(0, 10),
                createdBy: currentUser.email,
                artifactUri: run.artifactPath,
                approvalStatus: 'Approved',
                vulnerabilityScan: 'Passed',
                vulnerabilitiesCount: 0,
                driftStatus: 'Healthy',
                psiScore: 0.02,
                description: `Registered from MLflow experiment run ${run.runName} (${run.framework}).`,
              },
              ...m.versions,
            ],
          };
        }
        return m;
      })
    );

    const newAudit: AuditLogItem = {
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      user: currentUser.email,
      role: userRole,
      action: 'REGISTER_MLFLOW_RUN',
      targetResource: `Run ID: ${run.id} -> Model Registry Staging`,
      status: 'Success',
      details: `Promoted MLflow run ${run.runName} to Model Registry staging version v2.2.0-staging.`,
      ipAddress: '10.128.0.42',
    };
    setAuditLogs((prev) => [newAudit, ...prev]);
  };

  // Dataset Handlers
  const handleAddDataset = (newDataset: DatasetItem) => {
    setDatasets((prev) => [newDataset, ...prev]);
    const newAudit: AuditLogItem = {
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      user: currentUser.email,
      role: userRole,
      action: 'INGEST_DATASET',
      targetResource: `Dataset: ${newDataset.name}`,
      status: 'Success',
      details: `Registered new dataset asset format ${newDataset.format} tagged ${newDataset.gitTag}.`,
      ipAddress: '10.128.0.42',
    };
    setAuditLogs((prev) => [newAudit, ...prev]);
  };

  const handleUpdateDataset = (updated: DatasetItem) => {
    setDatasets((prev) => prev.map((d) => (d.id === updated.id ? updated : d)));
  };

  const handleUpdatePipeline = (updated: FeatureEnginePipeline) => {
    setFeaturePipelines((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
  };

  const handleExecuteFeaturePipeline = (pipelineId: string) => {
    setFeaturePipelines((prev) =>
      prev.map((p) => {
        if (p.id !== pipelineId) return p;
        return {
          ...p,
          status: 'Completed',
          lastRunAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
          executedRowCount: 1450000,
        };
      })
    );

    const newAudit: AuditLogItem = {
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      user: currentUser.email,
      role: userRole,
      action: 'EXECUTE_FEATURE_PIPELINE',
      targetResource: `Feature Pipeline ID: ${pipelineId}`,
      status: 'Success',
      details: 'Executed feature pipeline transformation nodes and populated Feature Store.',
      ipAddress: '10.128.0.42',
    };
    setAuditLogs((prev) => [newAudit, ...prev]);
  };

  // Open Copilot with contextual prompt
  const handleOpenCopilotWithContext = (prompt: string) => {
    setCopilotContextPrompt(prompt);
    setIsCopilotOpen(true);
  };

  // Promote Model Stage with RBAC audit entry
  const handlePromoteVersion = (modelId: string, versionId: string, newStage: ModelStage) => {
    if (userRole === 'Viewer') return;

    setModels((prevModels) =>
      prevModels.map((m) => {
        if (m.id !== modelId) return m;
        return {
          ...m,
          versions: m.versions.map((v) => {
            if (v.id !== versionId) return v;
            return {
              ...v,
              stage: newStage,
              approvalStatus: newStage === 'Production' ? 'Approved' : v.approvalStatus,
            };
          }),
        };
      })
    );

    // Append to audit log
    const newAudit: AuditLogItem = {
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      user: currentUser.email,
      role: userRole,
      action: 'PROMOTE_MODEL_STAGE',
      targetResource: `Model ID: ${modelId} Version ID: ${versionId} -> ${newStage}`,
      status: 'Success',
      details: `User promoted model version to ${newStage} in ${environment} environment.`,
      ipAddress: '10.128.0.42',
    };

    setAuditLogs((prev) => [newAudit, ...prev]);
  };

  // Update Serving Endpoint Canary Traffic
  const handleUpdateTraffic = (endpointId: string, canaryPercent: number) => {
    if (userRole === 'Viewer') return;

    setEndpoints((prev) =>
      prev.map((ep) => {
        if (ep.id !== endpointId) return ep;
        return {
          ...ep,
          canaryTrafficPercent: canaryPercent,
        };
      })
    );

    const newAudit: AuditLogItem = {
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      user: currentUser.email,
      role: userRole,
      action: 'UPDATE_CANARY_TRAFFIC',
      targetResource: `Endpoint ID: ${endpointId} Canary Allocation -> ${canaryPercent}%`,
      status: 'Success',
      details: `Adjusted traffic split for endpoint ${endpointId}.`,
      ipAddress: '10.128.0.42',
    };

    setAuditLogs((prev) => [newAudit, ...prev]);
  };

  // Trigger New Pipeline Execution Run
  const handleTriggerPipeline = () => {
    if (userRole === 'Viewer') return;

    const newRun: MlPipelineRun = {
      id: `run-${Math.floor(Math.random() * 9000) + 1000}`,
      pipelineName: 'CI-CD-Manual-Retrain-Pipeline',
      triggerType: 'Manual',
      startedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      durationSec: 12,
      status: 'running',
      initiatedBy: currentUser.email,
      gitCommitHash: Math.random().toString(16).substring(2, 10),
      steps: [
        { id: 's1', name: 'Extract Data Snapshot', type: 'data_ingest', status: 'succeeded', durationSec: 12 },
        { id: 's2', name: 'Data Validation', type: 'validation', status: 'running', durationSec: 5, logs: ['[INFO] Running Great Expectations data suite...'] },
        { id: 's3', name: 'Distributed Ray Training', type: 'training', status: 'pending' },
        { id: 's4', name: 'Model Evaluation', type: 'evaluation', status: 'pending' },
        { id: 's5', name: 'K8s Canary Deployment', type: 'deploy', status: 'pending' },
      ],
    };

    setPipelines((prev) => [newRun, ...prev]);

    const newAudit: AuditLogItem = {
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      user: currentUser.email,
      role: userRole,
      action: 'TRIGGER_MANUAL_PIPELINE',
      targetResource: newRun.pipelineName,
      status: 'Success',
      details: 'Manual pipeline run triggered from UI.',
      ipAddress: '10.128.0.42',
    };

    setAuditLogs((prev) => [newAudit, ...prev]);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col antialiased selection:bg-indigo-500 selection:text-white">
      {/* Header Bar */}
      <Header
        environment={environment}
        setEnvironment={setEnvironment}
        userRole={userRole}
        setUserRole={setUserRole}
        onOpenCopilot={() => {
          setCopilotContextPrompt('');
          setIsCopilotOpen(true);
        }}
        onOpenExportModal={() => handleOpenExportModal('agent_orchestration')}
        onOpenAlertCenter={() => setIsAlertCenterOpen(true)}
        unreadAuditCount={unreadCount > 0 ? unreadCount : auditLogs.filter((l) => l.status === 'Denied').length}
        currentUser={currentUser}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        jwtToken={jwtToken}
        isMobileMenuOpen={isMobileMenuOpen}
        setIsMobileMenuOpen={setIsMobileMenuOpen}
      />

      {/* Main Body with Sidebar + Tab Content */}
      <div className="flex-1 flex overflow-hidden relative">
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          modelsCount={models.length}
          pipelinesCount={pipelines.filter((p) => p.status === 'running').length}
          endpointsCount={endpoints.length}
          driftAlertsCount={driftMetrics.filter((d) => d.status === 'Critical').length}
          datasetsCount={datasets.length}
          isMobileOpen={isMobileMenuOpen}
          onCloseMobile={() => setIsMobileMenuOpen(false)}
        />

        <main className="flex-1 overflow-y-auto p-3 sm:p-5 lg:p-6 transition-colors duration-200">
          {activeTab === 'overview' && (
            <OverviewDashboard
              models={models}
              pipelines={pipelines}
              endpoints={endpoints}
              driftMetrics={driftMetrics}
              auditLogs={auditLogs}
              onNavigateTab={setActiveTab}
              onOpenCopilot={() => setIsCopilotOpen(true)}
            />
          )}

          {activeTab === 'datasets' && (
            <DatasetHubView
              datasets={datasets}
              featurePipelines={featurePipelines}
              onAddDataset={handleAddDataset}
              onUpdateDataset={handleUpdateDataset}
              onUpdatePipeline={handleUpdatePipeline}
              onExecutePipeline={handleExecuteFeaturePipeline}
              onOpenCopilotWithContext={handleOpenCopilotWithContext}
              userRole={userRole}
            />
          )}

          {activeTab === 'training' && (
            <TrainingHubView
              datasets={datasets}
              runs={mlflowRuns}
              fastApiConfig={fastApiConfig}
              dockerConfig={dockerConfig}
              onAddRun={handleAddTrainingRun}
              onRegisterRun={handleRegisterRunToModelRegistry}
              onOpenCopilotWithContext={handleOpenCopilotWithContext}
              userRole={userRole}
            />
          )}

          {activeTab === 'registry' && (
            <ModelRegistryView
              models={models}
              onPromoteVersion={handlePromoteVersion}
              userRole={userRole}
              onOpenCopilotWithContext={handleOpenCopilotWithContext}
              onOpenExportModal={() => handleOpenExportModal('model_registry')}
            />
          )}

          {activeTab === 'featurestore' && (
            <FeatureStoreView
              featureViews={featureViews}
              onOpenCopilotWithContext={handleOpenCopilotWithContext}
            />
          )}

          {activeTab === 'pipelines' && (
            <PipelineView
              pipelineRuns={pipelines}
              onTriggerPipeline={handleTriggerPipeline}
              onOpenCopilotWithContext={handleOpenCopilotWithContext}
              onOpenExportModal={() => handleOpenExportModal('pipeline_runs')}
            />
          )}

          {activeTab === 'serving' && (
            <ModelServingView
              endpoints={endpoints}
              onUpdateTraffic={handleUpdateTraffic}
              onOpenCopilotWithContext={handleOpenCopilotWithContext}
            />
          )}

          {activeTab === 'monitoring' && (
            <MonitoringView
              driftMetrics={driftMetrics}
              onOpenCopilotWithContext={handleOpenCopilotWithContext}
              onTriggerPipeline={handleTriggerPipeline}
              onOpenExportModal={() => handleOpenExportModal('monitoring_metrics')}
            />
          )}

          {activeTab === 'llmops' && (
            <LLMOpsView
              promptTemplates={promptTemplates}
              onOpenCopilotWithContext={handleOpenCopilotWithContext}
              onOpenExportModal={() => handleOpenExportModal('agent_orchestration')}
            />
          )}

          {activeTab === 'cluster' && (
            <ClusterView
              clusterNodes={clusterNodes}
              onOpenCopilotWithContext={handleOpenCopilotWithContext}
            />
          )}

          {activeTab === 'storage' && <InfrastructureStorageView />}

          {activeTab === 'users' && <UserManagementView />}

          {activeTab === 'governance' && (
            <GovernanceView
              auditLogs={auditLogs}
              userRole={userRole}
              onOpenCopilotWithContext={handleOpenCopilotWithContext}
            />
          )}

          {activeTab === 'docs' && <ArchitectureDocView />}
        </main>
      </div>

      {/* Embedded MLOps Gemini Copilot Slide-over Modal */}
      <MLOpsCopilotModal
        isOpen={isCopilotOpen}
        onClose={() => setIsCopilotOpen(false)}
        initialPrompt={copilotContextPrompt}
      />

      {/* JWT Authentication & RBAC Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentUser={currentUser}
        onLoginSuccess={handleLoginSuccess}
        jwtToken={jwtToken}
      />

      {/* Data Export Center Modal */}
      <ExportDataModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        activeModuleContext={exportModalContext}
      />

      {/* Global Alert Center & Floating Toasts */}
      <FloatingToastContainer />
      <AlertCenterDrawer />
    </div>
  );
}

export default function App() {
  return (
    <AlertCenterProvider>
      <MainAppContent />
    </AlertCenterProvider>
  );
}

