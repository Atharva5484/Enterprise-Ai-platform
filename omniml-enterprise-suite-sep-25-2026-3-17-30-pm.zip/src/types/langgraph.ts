export type LangGraphNodeType =
  | 'trigger'
  | 'agent'
  | 'router'
  | 'tool'
  | 'evaluator'
  | 'retrain_trigger'
  | 'approval'
  | 'memory';

export interface LangGraphNodeConfig {
  model?: string;
  prompt?: string;
  condition?: string;
  toolName?: string;
  maxRetries?: number;
  approvalRole?: string;
  timeoutSec?: number;
  stateSchemaKey?: string;
  targetMetric?: string;
  metricThreshold?: number;
}

export interface LangGraphNode {
  id: string;
  type: LangGraphNodeType;
  label: string;
  description: string;
  position: { x: number; y: number };
  config: LangGraphNodeConfig;
  status?: 'idle' | 'running' | 'completed' | 'failed';
  outputState?: Record<string, any>;
  logs?: string[];
}

export interface LangGraphEdge {
  id: string;
  source: string;
  target: string;
  label?: string;
  condition?: string;
  animated?: boolean;
}

export interface LangGraphWorkflow {
  id: string;
  name: string;
  description: string;
  category: 'Retraining & Validation' | 'RAG Maintenance' | 'Multi-Agent Safety' | 'Custom';
  nodes: LangGraphNode[];
  edges: LangGraphEdge[];
  stateSchema: Record<string, string>; // e.g. { driftScore: "float", datasetUri: "string", retrainApproved: "boolean" }
  status: 'draft' | 'running' | 'succeeded' | 'failed';
  lastExecutionTime?: string;
  executionLogs?: string[];
}

export type CostProvider = 'Google Gemini' | 'OpenAI' | 'Anthropic' | 'vLLM (Local)';

export interface ProjectCostItem {
  id: string;
  project: string;
  model: string;
  provider: CostProvider;
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
  requestCount: number;
  avgLatencyMs: number;
  estimatedCostUSD: number;
  trendPercent: number;
}

export interface CostDailyTrend {
  date: string;
  costUSD: number;
  tokens: number;
  requests: number;
  geminiCost: number;
  openaiCost: number;
  anthropicCost: number;
}

export interface CostOptimizationInsight {
  id: string;
  title: string;
  type: 'SAVINGS' | 'LATENCY' | 'PROVIDER_REDUNDANCY' | 'CACHE_HIT';
  estimatedSavingsMonthlyUSD: number;
  description: string;
  recommendedAction: string;
  affectedProject: string;
  impactScore: 'HIGH' | 'MEDIUM' | 'LOW';
}

export interface RagasRetrievedChunk {
  id: string;
  chunkIndex: number;
  documentTitle: string;
  content: string;
  relevanceScore?: number;
  isRelevant?: boolean;
}

export interface RagasEvaluationMetric {
  faithfulness: number; // 0.00 - 1.00
  answerRelevance: number; // 0.00 - 1.00
  contextPrecision: number; // 0.00 - 1.00
  contextRecall?: number; // 0.00 - 1.00
  overallRagasScore: number; // 0.00 - 1.00
}

export interface RagasReasoning {
  faithfulnessReasoning: string;
  answerRelevanceReasoning: string;
  contextPrecisionReasoning: string;
  extractedStatements: string[];
  supportedStatementsCount: number;
  totalStatementsCount: number;
}

export interface RagasTestCase {
  id: string;
  documentName: string;
  userQuery: string;
  retrievedContexts: RagasRetrievedChunk[];
  generatedAnswer: string;
  groundTruth?: string;
  metrics?: RagasEvaluationMetric;
  reasoning?: RagasReasoning;
  status: 'pending' | 'evaluating' | 'completed' | 'failed';
  evaluatedAt?: string;
}

export interface AgentNodeDetail {
  id: string;
  name: string;
  role: string;
  framework: 'LangGraph' | 'AutoGen' | 'CrewAI' | 'MCP Server';
  model: string;
  status: 'idle' | 'running' | 'completed' | 'waiting' | 'failed';
  systemPrompt: string;
  memoryBuffer: Array<{ role: 'user' | 'assistant' | 'tool' | 'system'; content: string; timestamp: string }>;
  stateVariables: Record<string, any>;
  tools: string[];
  tokensUsed: number;
  latencyMs: number;
}

export interface AgentCommunicationMessage {
  id: string;
  workflowId: string;
  timestamp: string;
  sender: string;
  senderFramework: 'LangGraph' | 'AutoGen' | 'CrewAI' | 'MCP Server';
  receiver: string;
  messageType: 'TASK_DELEGATION' | 'TOOL_CALL' | 'TOOL_RESULT' | 'PLAN_VERIFICATION' | 'STATE_UPDATE' | 'HUMAN_APPROVAL';
  summary: string;
  payload?: Record<string, any>;
  tokensUsed: number;
  latencyMs: number;
}

export interface AgentScheduledTask {
  id: string;
  workflowId: string;
  workflowName: string;
  framework: 'LangGraph' | 'AutoGen' | 'CrewAI' | 'MCP Server';
  scheduleType: 'MANUAL' | 'CRON';
  cronExpression?: string;
  promptGoal: string;
  status: 'SCHEDULED' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'PAUSED';
  nextRunAt?: string;
  lastRunAt?: string;
  maxTurns: number;
  priority: 'HIGH' | 'NORMAL' | 'LOW';
  createdByName: string;
}

