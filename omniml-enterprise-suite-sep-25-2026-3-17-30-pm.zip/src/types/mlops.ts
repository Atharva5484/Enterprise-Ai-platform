export type Environment = 'production' | 'staging' | 'development';
export type UserRole = 'MLOps Admin' | 'Lead Data Scientist' | 'ML Engineer' | 'Compliance Officer' | 'Admin' | 'Data Scientist' | 'Viewer';

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  avatarUrl?: string;
  department: string;
  jwtToken?: string;
}

export interface JwtTokenPayload {
  sub: string;
  email: string;
  name: string;
  role: UserRole;
  iat: number;
  exp: number;
  permissions: string[];
}

export type DatasetFormat = 'CSV' | 'Excel' | 'JSON' | 'Parquet' | 'S3 Connection';

export interface DatasetColumnProfile {
  columnName: string;
  dataType: 'INTEGER' | 'FLOAT' | 'STRING' | 'BOOLEAN' | 'DATETIME' | 'CATEGORICAL';
  nullCount: number;
  nullPercentage: number;
  distinctCount: number;
  min?: number | string;
  max?: number | string;
  mean?: number;
  stdDev?: number;
  skewness?: number;
  sampleValues: (string | number | boolean)[];
  hasOutliers?: boolean;
}

export interface DatasetQualityGate {
  ruleName: string;
  description: string;
  severity: 'ERROR' | 'WARNING' | 'INFO';
  status: 'PASSED' | 'FAILED' | 'WARN';
  metric: string;
  value: string | number;
}

export interface DatasetProfile {
  totalRows: number;
  totalColumns: number;
  memorySizeMb: number;
  missingCellsPercent: number;
  duplicateRows: number;
  columns: DatasetColumnProfile[];
  qualityGates: DatasetQualityGate[];
  driftScore?: number;
  recommendedActions: string[];
}

export interface DatasetVersion {
  versionTag: string; // e.g. v1.0.0
  dvcHash: string; // md5 hash
  gitCommitHash: string;
  createdAt: string;
  createdBy: string;
  rowCount: number;
  sizeMb: number;
  commitMessage: string;
  isLatest?: boolean;
}

export interface DatasetItem {
  id: string;
  name: string;
  description: string;
  format: DatasetFormat;
  sizeMb: number;
  rowCount: number;
  columnCount: number;
  source: string; // File name or s3://uri
  dvcHash: string;
  gitTag: string;
  versions: DatasetVersion[];
  profile: DatasetProfile;
  previewData: Record<string, any>[];
  createdAt: string;
  updatedAt: string;
  owner: string;
  s3Config?: {
    bucket: string;
    region: string;
    accessKeyId: string;
    uri: string;
  };
}

export interface PreprocessingConfig {
  imputationStrategy: 'Mean' | 'Median' | 'Mode' | 'Drop Rows' | 'Constant 0';
  scalingMethod: 'StandardScaler' | 'MinMaxScaler' | 'RobustScaler' | 'None';
  encodingMethod: 'OneHotEncoder' | 'OrdinalEncoder' | 'TargetEncoder' | 'None';
  removeOutliers: boolean;
  iqrMultiplier: number;
}

export interface FeatureEngineStep {
  id: string;
  stepName: string;
  type: 'IMPUTER' | 'SCALER' | 'ENCODER' | 'POLYNOMIAL' | 'VECTORIZER' | 'PCA' | 'INTERACTION';
  inputColumns: string[];
  outputColumns: string[];
  parameters: Record<string, any>;
  enabled: boolean;
}

export interface FeatureEnginePipeline {
  id: string;
  name: string;
  description: string;
  targetDatasetId: string;
  steps: FeatureEngineStep[];
  outputFeatureViewName: string;
  status: 'Draft' | 'Compiled' | 'Executing' | 'Completed';
  lastRunAt?: string;
  executedRowCount?: number;
  outputFeaturesCount?: number;
}

export type ModelStage = 'Development' | 'Staging' | 'Production' | 'Archived';
export type TrainingFramework = 'Scikit-Learn' | 'XGBoost' | 'LightGBM' | 'CatBoost' | 'TensorFlow' | 'PyTorch';
export type TuningMethod = 'Bayesian Optimization (Optuna)' | 'Grid Search' | 'Random Search' | 'None (Default Params)';
export type CrossValidationStrategy = 'Stratified 5-Fold' | 'Stratified 10-Fold' | 'K-Fold (5)' | 'TimeSeriesSplit';

export interface HyperparameterTrial {
  trialId: number;
  params: Record<string, number | string | boolean>;
  score: number; // evaluation metric value e.g. ROC-AUC or F1
  valLoss: number;
  durationSec: number;
  status: 'Completed' | 'Pruned' | 'Running';
}

export interface RocCurvePoint {
  fpr: number;
  tpr: number;
  threshold: number;
}

export interface ConfusionMatrixData {
  tp: number;
  fp: number;
  tn: number;
  fn: number;
  labels: [string, string];
}

export interface FeatureImportanceItem {
  feature: string;
  importance: number;
}

export interface MlflowExperimentRun {
  id: string;
  runName: string;
  experimentName: string;
  framework: TrainingFramework;
  datasetName: string;
  datasetVersion: string;
  taskType: 'Binary Classification' | 'Multi-class Classification' | 'Regression' | 'Time Series Forecasting';
  status: 'FINISHED' | 'RUNNING' | 'FAILED';
  startedAt: string;
  durationSec: number;
  params: Record<string, string | number | boolean>;
  metrics: {
    accuracy: number;
    f1Score: number;
    rocAuc: number;
    precision: number;
    recall: number;
    trainingLoss: number;
    validationLoss: number;
    inferenceLatencyMs: number;
  };
  crossValScores: number[];
  trials?: HyperparameterTrial[];
  rocPoints: RocCurvePoint[];
  confusionMatrix: ConfusionMatrixData;
  featureImportances: FeatureImportanceItem[];
  artifactPath: string;
  modelSizeMb: number;
  isRegistered?: boolean;
  registeredModelVersion?: string;
  author: string;
}

export interface FastApiEndpointConfig {
  serviceName: string;
  modelRunId: string;
  version: string;
  port: number;
  workers: number;
  pythonCode: string;
  pydanticSchemaCode: string;
  openApiSchemaJson: Record<string, any>;
  samplePayload: Record<string, any>;
  lastTestedAt?: string;
}

export interface DockerContainerConfig {
  imageName: string;
  tag: string;
  baseImage: string;
  cudaEnabled: boolean;
  dockerfileContent: string;
  dockerComposeContent: string;
  nginxConfContent: string;
  imageSizeMb: number;
  vulnerabilityScan: 'Passed (0 High/Critical)' | 'Warning' | 'Critical';
  buildLogs: string[];
}

export type ModelFramework = 'PyTorch' | 'TensorFlow' | 'XGBoost' | 'Scikit-Learn' | 'HuggingFace' | 'JAX' | 'Gemini / LLM';

export interface ModelVersion {
  id: string;
  version: string;
  stage: ModelStage;
  framework: ModelFramework;
  accuracy: number;
  f1Score: number;
  latencyMs: number;
  throughputQps: number;
  sizeMb: number;
  createdAt: string;
  createdBy: string;
  artifactUri: string;
  approvalStatus: 'Approved' | 'Pending Review' | 'Rejected';
  approvedBy?: string;
  vulnerabilityScan: 'Passed' | 'Warning' | 'Critical';
  vulnerabilitiesCount: number;
  driftStatus: 'Healthy' | 'Moderate Drift' | 'Severe Drift';
  psiScore: number;
  description: string;
}

export interface RegisteredModel {
  id: string;
  name: string;
  slug: string;
  ownerTeam: string;
  taskType: 'Classification' | 'Regression' | 'Computer Vision' | 'LLM / GenAI' | 'Recommendation' | 'NLP';
  description: string;
  currentProductionVersion?: string;
  versions: ModelVersion[];
  tags: string[];
  complianceTags: ('GDPR' | 'EU AI Act' | 'HIPAA' | 'SOC2')[];
  lastUpdated: string;
}

export interface FeatureItem {
  name: string;
  dataType: 'STRING' | 'INT64' | 'FLOAT64' | 'BOOLEAN' | 'VECTOR';
  description: string;
  freshnessSec: number;
  nullRatio: number;
  driftScore: number; // PSI score
  onlineServingLatencyMs: number;
}

export interface FeatureView {
  id: string;
  name: string;
  entity: string;
  owner: string;
  onlineStoreType: 'Redis' | 'Bigtable' | 'DynamoDB' | 'Milvus';
  offlineStoreType: 'Snowflake' | 'BigQuery' | 'Delta Lake';
  featuresCount: number;
  readQps: number;
  features: FeatureItem[];
  lastSyncedAt: string;
  status: 'Active' | 'Syncing' | 'Degraded';
}

export type PipelineStepStatus = 'pending' | 'running' | 'succeeded' | 'failed' | 'skipped';

export interface PipelineStep {
  id: string;
  name: string;
  type: 'data_ingest' | 'validation' | 'preprocess' | 'training' | 'tuning' | 'evaluation' | 'quality_gate' | 'deploy';
  status: PipelineStepStatus;
  durationSec?: number;
  logs?: string[];
  inputs?: string[];
  outputs?: string[];
}

export interface MlPipelineRun {
  id: string;
  pipelineName: string;
  triggerType: 'Scheduled' | 'Manual' | 'Auto-Drift Trigger' | 'Git Commit';
  startedAt: string;
  durationSec: number;
  status: PipelineStepStatus;
  initiatedBy: string;
  gitCommitHash: string;
  steps: PipelineStep[];
}

export interface ServingEndpoint {
  id: string;
  name: string;
  modelName: string;
  currentVersion: string;
  targetVersion?: string;
  strategy: 'Single' | 'Canary' | 'Blue-Green' | 'Shadow' | 'A/B Test';
  canaryTrafficPercent: number; // e.g., 20% to canary
  status: 'Healthy' | 'Deploying' | 'Degraded' | 'Stopped';
  replicas: number;
  minReplicas: number;
  maxReplicas: number;
  hardware: '4x NVIDIA H100 80GB' | '2x NVIDIA A100 40GB' | '8x TPU v5e' | '16 Core CPU / 64GB';
  qps: number;
  p50LatencyMs: number;
  p90LatencyMs: number;
  p99LatencyMs: number;
  errorRatePercent: number;
  region: string;
}

export interface DriftMetric {
  featureName: string;
  metricName: 'PSI' | 'KS-Test' | 'Wasserstein' | 'Jensen-Shannon';
  baselineValue: number;
  currentValue: number;
  threshold: number;
  status: 'Normal' | 'Warning' | 'Critical';
  distributionData: { bin: string; baseline: number; production: number }[];
}

export interface PromptTemplate {
  id: string;
  title: string;
  category: 'Summarization' | 'RAG Extraction' | 'Code Generation' | 'Sentiment Analysis' | 'Classification';
  template: string;
  variables: string[];
  version: string;
  faithfulnessScore: number; // 0 - 100
  hallucinationRate: number; // %
  latencyMs: number;
  costPer1kTokensUSD: number;
  lastTestedAt: string;
}

export interface GpuClusterNode {
  id: string;
  nodeName: string;
  gpuModel: string;
  gpuCount: number;
  gpuUtilPercent: number;
  memoryUtilPercent: number;
  temperatureC: number;
  powerWatts: number;
  allocatedPods: number;
  status: 'Ready' | 'Busy' | 'Draining' | 'Maintenance';
}

export interface AuditLogItem {
  id: string;
  timestamp: string;
  user: string;
  role: UserRole;
  action: string;
  targetResource: string;
  status: 'Success' | 'Denied' | 'Warning';
  details: string;
  ipAddress: string;
}

export interface CopilotMessage {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: string;
  codeSnippet?: string;
  actionSuggestion?: {
    label: string;
    actionType: 'TRIGGER_PIPELINE' | 'PROMOTE_MODEL' | 'ADJUST_TRAFFIC' | 'DISMISS_ALERT';
    payload?: Record<string, unknown>;
  };
}

export interface K8sHpaConfig {
  deploymentName: string;
  namespace: string;
  minReplicas: number;
  maxReplicas: number;
  currentReplicas: number;
  targetCpuUtilization: number; // e.g. 75%
  currentCpuUtilization: number;
  targetGpuUtilization: number; // e.g. 80%
  currentGpuUtilization: number;
  maxSurge: string; // e.g. "25%"
  maxUnavailable: string; // e.g. "0%"
  rollingStrategy: 'RollingUpdate' | 'Recreate' | 'Canary' | 'Blue-Green';
}

export interface HelmReleaseInfo {
  releaseName: string;
  namespace: string;
  chartVersion: string;
  appVersion: string;
  status: 'Deployed' | 'Superseded' | 'Pending-Upgrade' | 'Failed';
  revision: number;
  updatedAt: string;
  valuesYaml: string;
}

export interface NotificationChannelConfig {
  id: string;
  type: 'slack' | 'teams' | 'email';
  name: string;
  destination: string; // channel or webhook or recipient list
  enabled: boolean;
  alertOnCriticalDrift: boolean;
  alertOnPipelineFailure: boolean;
  alertOnAutoscaling: boolean;
  lastTestStatus?: 'Success' | 'Failed' | 'Untested';
  lastTestTime?: string;
}

export interface AutoRetrainPolicy {
  id: string;
  modelName: string;
  enabled: boolean;
  psiThreshold: number; // e.g. 0.25
  accuracyDropThreshold: number; // e.g. 0.05 (5%)
  conceptDriftPValue: number; // e.g. 0.01
  cooldownPeriodHours: number;
  targetPipelineId: string;
  notifyChannels: ('slack' | 'teams' | 'email')[];
  lastTriggeredAt?: string;
  totalTriggersCount: number;
}

