variable "aws_region" {
  type        = string
  default     = "us-east-1"
  description = "AWS Region for deployment"
}

variable "environment" {
  type        = string
  default     = "production"
  description = "Target deployment environment (production, staging, dev)"
}

variable "db_password" {
  type        = string
  sensitive   = true
  default     = "NexusML_SecurePass_2026!"
  description = "Master password for PostgreSQL RDS"
}
