# NexusML Enterprise AI Platform - Terraform Infrastructure Definition
terraform {
  required_version = ">= 1.6.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.30"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.25"
    }
  }
}

provider "aws" {
  region = var.aws_region
  default_tags {
    tags = {
      Environment = var.environment
      Project     = "NexusML-Enterprise-AI-Platform"
      ManagedBy   = "Terraform"
    }
  }
}

# 1. Virtual Private Cloud (VPC)
resource "aws_vpc" "nexusml_vpc" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = {
    Name = "nexusml-vpc-${var.environment}"
  }
}

# Subnets
resource "aws_subnet" "public_subnet_1" {
  vpc_id                  = aws_vpc.nexusml_vpc.id
  cidr_block              = "10.0.1.0/24"
  availability_zone       = "${var.aws_region}a"
  map_public_ip_on_launch = true

  tags = {
    Name = "nexusml-public-subnet-1"
    "kubernetes.io/role/elb" = "1"
  }
}

resource "aws_subnet" "private_subnet_1" {
  vpc_id            = aws_vpc.nexusml_vpc.id
  cidr_block        = "10.0.10.0/24"
  availability_zone = "${var.aws_region}a"

  tags = {
    Name = "nexusml-private-subnet-1"
    "kubernetes.io/role/internal-elb" = "1"
  }
}

# 2. Amazon ECR Container Registry
resource "aws_ecr_repository" "nexusml_repo" {
  name                 = "nexusml/platform"
  image_tag_mutability = "MUTABLE"

  image_scanning_configuration {
    scan_on_push = true
  }
}

# 3. Amazon S3 Artifact & Feast Feature Store Bucket
resource "aws_s3_bucket" "artifacts_bucket" {
  bucket = "nexusml-enterprise-artifacts-${var.environment}"

  tags = {
    Name = "NexusML Artifacts and Feature Store Storage"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "s3_encryption" {
  bucket = aws_s3_bucket.artifacts_bucket.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

# 4. Amazon EKS Kubernetes Cluster
resource "aws_iam_role" "eks_cluster_role" {
  name = "nexusml-eks-cluster-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "eks.amazonaws.com"
        }
      }
    ]
  })
}

resource "aws_eks_cluster" "nexusml_eks" {
  name     = "nexusml-prod-eks"
  role_arn = aws_iam_role.eks_cluster_role.arn
  version  = "1.29"

  vpc_config {
    subnet_ids = [aws_subnet.public_subnet_1.id, aws_subnet.private_subnet_1.id]
  }
}

# Node Group (GPU & CPU Worker Nodes)
resource "aws_iam_role" "eks_node_role" {
  name = "nexusml-eks-node-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "ec2.amazonaws.com"
        }
      }
    ]
  })
}

resource "aws_eks_node_group" "gpu_node_group" {
  cluster_name    = aws_eks_cluster.nexusml_eks.name
  node_group_name = "nexusml-gpu-h100-pool"
  node_role_arn   = aws_iam_role.eks_node_role.arn
  subnet_ids      = [aws_subnet.private_subnet_1.id]
  instance_types  = ["g5.2xlarge"]

  scaling_config {
    desired_size = 2
    max_size     = 10
    min_size     = 1
  }
}

# 5. RDS PostgreSQL Multi-AZ Database for Metadata
resource "aws_db_instance" "nexusml_postgres" {
  allocated_storage       = 100
  max_allocated_storage   = 500
  engine                  = "postgres"
  engine_version          = "16.1"
  instance_class          = "db.r6g.xlarge"
  db_name                 = "nexusml_db"
  username                = "nexusadmin"
  password                = var.db_password
  multi_az                = true
  skip_final_snapshot     = true
  storage_encrypted       = true

  tags = {
    Name = "NexusML Enterprise RDS PostgreSQL"
  }
}

output "eks_cluster_endpoint" {
  value = aws_eks_cluster.nexusml_eks.endpoint
}

output "ecr_repository_url" {
  value = aws_ecr_repository.nexusml_repo.repository_url
}

output "s3_bucket_name" {
  value = aws_s3_bucket.artifacts_bucket.id
}
